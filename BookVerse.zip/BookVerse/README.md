# BookVerse

Aplicação Android para escrever, editar, desenhar capas, organizar, pré-visualizar, exportar (PDF, EPUB, DOCX, TXT) e partilhar livros digitais. **Sem inteligência artificial e sem anúncios.**

- Kotlin nativo + WebView local (HTML5, CSS3, JavaScript puro, sem frameworks)
- Room/SQLite, local-first: escrever, exportar e partilhar funcionam totalmente offline
- Firebase (Auth: email, Google, GitHub; Firestore + Storage) só para conta e sincronização
- Storage Access Framework, FileProvider/Sharesheet, Android Print Framework (PDF)

## Compilar
Requisitos: JDK 17, Android SDK 34, Gradle 8.7.

    gradle assembleDebug        # APK em app/build/outputs/apk/debug/

O workflow `.github/workflows/android.yml` compila o APK a cada push e envia-o como artefacto.
Em *Actions → Android CI → Run workflow* pode marcar "release" para publicar o APK numa GitHub Release.

> Nota: o código Kotlin foi escrito sem acesso a um compilador. Execute o workflow para validar; pequenos
> ajustes de compilação podem ser necessários na primeira execução.

## Configurar o Firebase (opcional, só para contas e sincronização)
1. Crie um projeto em https://console.firebase.google.com.
2. Adicione uma app Android com o pacote `com.bookverse.app` e a impressão digital SHA-1 da sua chave.
3. Substitua `app/google-services.json` pelo ficheiro descarregado (o atual é um marcador sem credenciais).
4. Em Authentication ative Email/Palavra-passe, Google e GitHub (GitHub requer uma OAuth App com o callback do Firebase).
5. Copie o *Web client ID* para `bv_web_client_id` em `app/src/main/res/values/firebase_config.xml`.
6. Crie Firestore e Storage e publique as regras: `firebase deploy --only firestore:rules,storage` (ficheiros `firestore.rules`, `storage.rules`). Cada utilizador só acede a `users/{uid}/**`.

Sem configuração, a app funciona normalmente em modo local e indica que a sincronização não está ativa.

## Sincronização
Estados: sincronizado / pendente / erro. Repetição automática com recuo exponencial (WorkManager). Em conflito, ambas as versões são mantidas e a local fica recuperável no histórico. Falhas de rede nunca apagam dados locais.

## Idiomas
Interface em português; a tradução para inglês é parcial.

## Segurança
Sem credenciais no código; sessão em EncryptedSharedPreferences; WebView sem acesso a ficheiros arbitrários; partilha via FileProvider.

## Assinar uma release
Crie um keystore, defina `signingConfigs` via variáveis de ambiente/`local.properties` (nunca no repositório) e execute `gradle assembleRelease`.
