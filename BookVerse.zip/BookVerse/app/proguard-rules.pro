-keepclassmembers class com.bookverse.app.bridge.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*
