package com.bookverse.app.export

import com.bookverse.app.data.MediaManager
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Entities
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Gera EPUB 3 válido (com nav.xhtml e toc.ncx de compatibilidade), capa, metadados,
 * capítulos em XHTML, imagens e folha de estilos.
 */
class EpubExporter(private val media: MediaManager) {

    private class Item(val id: String, val href: String, val mime: String, val props: String = "")

    fun export(req: ExportRequest, out: File) {
        val manifest = mutableListOf<Item>()
        val spine = mutableListOf<String>()
        val images = LinkedHashMap<String, ImageBytes>() // href -> bytes
        val files = LinkedHashMap<String, ByteArray>()    // path in zip -> content
        val sectionFile = HashMap<String, String>()

        val uuid = "urn:uuid:" + (req.bookId.ifEmpty { java.util.UUID.randomUUID().toString() })

        // CSS
        files["OEBPS/styles.css"] = css(req).toByteArray()
        manifest.add(Item("css", "styles.css", "text/css"))

        // Capa
        var coverHref: String? = null
        ImageResolver.decodeDataUrl(req.coverFront)?.let {
            coverHref = "images/cover.${it.ext}"
            images[coverHref!!] = it
            files["OEBPS/cover.xhtml"] = xhtml(req.title, "<div class=\"cover\"><img src=\"$coverHref\" alt=\"Capa\"/></div>", "cover").toByteArray()
            manifest.add(Item("cover-page", "cover.xhtml", "application/xhtml+xml"))
            spine.add("cover-page")
        }

        // Secções
        var imgCounter = 0
        val bodySections = req.sections.filter { it.type != "cover" && it.type != "backcover" && it.type != "toc" }
        for ((idx, s) in bodySections.withIndex()) {
            val doc = Jsoup.parseBodyFragment(s.html)
            for (el in doc.select("script,style,iframe,object,embed")) el.remove()
            for (el in doc.getAllElements()) {
                for (a in el.attributes().asList().map { it.key }) {
                    if (a == "contenteditable" || a.startsWith("on") || a.startsWith("data-")) el.removeAttr(a)
                }
            }
            for (img in doc.select("img")) {
                val src = img.attr("src")
                val ib = ImageResolver.resolve(src, media)
                if (ib == null) { img.remove(); continue }
                val href = "images/img_${++imgCounter}.${ib.ext}"
                images[href] = ib
                img.attr("src", href)
                if (!img.hasAttr("alt")) img.attr("alt", "")
                img.removeAttr("width"); img.removeAttr("height")
            }
            for (pb in doc.select("div.pagebreak")) pb.attr("style", "page-break-after: always; break-after: page;")
            val name = "s${idx + 1}.xhtml"
            sectionFile[s.id] = name
            val heading = if (s.title.isNotBlank() && doc.select("h1,h2").isEmpty() && s.type == "chapter")
                "<h1>${esc(s.title)}</h1>" else ""
            val inner = serialize(doc)
            files["OEBPS/$name"] = xhtml(s.title.ifBlank { req.title }, heading + inner, s.type).toByteArray()
            manifest.add(Item("sec${idx + 1}", name, "application/xhtml+xml"))
            spine.add("sec${idx + 1}")
        }

        // Página de índice visível (após a página de rosto/direitos, no fim da frente — simplificado: antes dos capítulos)
        val tocSection = req.sections.firstOrNull { it.type == "toc" }
        if (tocSection != null && req.toc.isNotEmpty()) {
            val html = StringBuilder("<h1>${esc(tocSection.title.ifBlank { "Índice" })}</h1><nav class=\"toc-list\"><ul>")
            for (t in req.toc) {
                val f = sectionFile[t.sectionId] ?: continue
                html.append("<li class=\"l${t.level.coerceIn(1, 3)}\"><a href=\"$f\">${esc(t.title)}</a></li>")
            }
            html.append("</ul></nav>")
            files["OEBPS/contents.xhtml"] = xhtml(tocSection.title.ifBlank { "Índice" }, html.toString(), "toc").toByteArray()
            manifest.add(Item("contents", "contents.xhtml", "application/xhtml+xml"))
            // insere antes do primeiro capítulo/introdução
            val firstChapter = bodySections.indexOfFirst { it.type == "intro" || it.type == "chapter" || it.type == "preface" }
            val at = if (firstChapter >= 0) spine.indexOf("sec${firstChapter + 1}") else spine.size
            spine.add(if (at >= 0) at else spine.size, "contents")
        }

        // Contracapa
        if (req.includeBackCover) {
            ImageResolver.decodeDataUrl(req.coverBack)?.let {
                val href = "images/backcover.${it.ext}"
                images[href] = it
                files["OEBPS/backcover.xhtml"] = xhtml(req.title, "<div class=\"cover\"><img src=\"$href\" alt=\"Contracapa\"/></div>", "backcover").toByteArray()
                manifest.add(Item("backcover", "backcover.xhtml", "application/xhtml+xml"))
                spine.add("backcover")
            }
        }

        // Imagens
        var i = 0
        for ((href, ib) in images) {
            i++
            val id = if (href == coverHref) "cover-image" else "img$i"
            manifest.add(Item(id, href, ib.mime, if (href == coverHref) "cover-image" else ""))
            files["OEBPS/$href"] = ib.bytes
        }

        // nav.xhtml
        val nav = StringBuilder()
        nav.append("<nav epub:type=\"toc\" id=\"toc\"><h1>${esc(tocSection?.title?.ifBlank { null } ?: "Índice")}</h1><ol>")
        var navCount = 0
        for (t in req.toc) {
            val f = sectionFile[t.sectionId] ?: continue
            nav.append("<li><a href=\"$f\">${esc(t.title)}</a></li>"); navCount++
        }
        if (navCount == 0) {
            val first = spine.firstOrNull { it != "cover-page" && it != "backcover" } ?: spine.first()
            val href = manifest.first { it.id == first }.href
            nav.append("<li><a href=\"$href\">${esc(req.title)}</a></li>")
        }
        nav.append("</ol></nav>")
        files["OEBPS/nav.xhtml"] = xhtml(req.title, nav.toString(), "nav", navDoc = true).toByteArray()
        manifest.add(Item("nav", "nav.xhtml", "application/xhtml+xml", "nav"))

        // toc.ncx (compatibilidade com leitores EPUB 2)
        val ncx = StringBuilder()
        ncx.append("""<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head><meta name="dtb:uid" content="${esc(uuid)}"/><meta name="dtb:depth" content="1"/><meta name="dtb:totalPageCount" content="0"/><meta name="dtb:maxPageNumber" content="0"/></head><docTitle><text>${esc(req.title)}</text></docTitle><navMap>""")
        var play = 0
        for (t in req.toc) {
            val f = sectionFile[t.sectionId] ?: continue
            play++
            ncx.append("<navPoint id=\"n$play\" playOrder=\"$play\"><navLabel><text>${esc(t.title)}</text></navLabel><content src=\"$f\"/></navPoint>")
        }
        if (play == 0) ncx.append("<navPoint id=\"n1\" playOrder=\"1\"><navLabel><text>${esc(req.title)}</text></navLabel><content src=\"${manifest.first { it.id == spine.first() }.href}\"/></navPoint>")
        ncx.append("</navMap></ncx>")
        files["OEBPS/toc.ncx"] = ncx.toString().toByteArray()
        manifest.add(Item("ncx", "toc.ncx", "application/x-dtbncx+xml"))

        // content.opf
        val modified = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        val opf = StringBuilder()
        opf.append("""<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" xml:lang="${esc(req.language)}">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="bookid">${esc(uuid)}</dc:identifier>
<dc:title>${esc(req.title + if (req.subtitle.isNotBlank()) ": " + req.subtitle else "")}</dc:title>
<dc:language>${esc(req.language)}</dc:language>
""")
        if (req.author.isNotBlank()) opf.append("<dc:creator>${esc(req.author)}</dc:creator>\n")
        if (req.publisher.isNotBlank()) opf.append("<dc:publisher>${esc(req.publisher)}</dc:publisher>\n")
        if (req.year.isNotBlank()) opf.append("<dc:date>${esc(req.year)}</dc:date>\n")
        if (req.copyright.isNotBlank()) opf.append("<dc:rights>${esc(req.copyright)}</dc:rights>\n")
        if (req.description.isNotBlank()) opf.append("<dc:description>${esc(req.description)}</dc:description>\n")
        if (req.isbn.isNotBlank()) opf.append("<dc:identifier>urn:isbn:${esc(req.isbn)}</dc:identifier>\n")
        opf.append("<meta property=\"dcterms:modified\">$modified</meta>\n")
        if (coverHref != null) opf.append("<meta name=\"cover\" content=\"cover-image\"/>\n")
        opf.append("</metadata>\n<manifest>\n")
        for (m in manifest) {
            opf.append("<item id=\"${m.id}\" href=\"${m.href}\" media-type=\"${m.mime}\"")
            if (m.props.isNotEmpty()) opf.append(" properties=\"${m.props}\"")
            opf.append("/>\n")
        }
        opf.append("</manifest>\n<spine toc=\"ncx\">\n")
        for (id in spine) opf.append("<itemref idref=\"$id\"/>\n")
        opf.append("</spine>\n<guide>")
        if (coverHref != null) opf.append("<reference type=\"cover\" title=\"Capa\" href=\"cover.xhtml\"/>")
        opf.append("</guide>\n</package>")
        files["OEBPS/content.opf"] = opf.toString().toByteArray()

        files["META-INF/container.xml"] = """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>""".toByteArray()

        // Escrita do ZIP: "mimetype" primeiro e sem compressão (exigido pelo EPUB)
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            val mt = "application/epub+zip".toByteArray()
            val e = ZipEntry("mimetype").apply {
                method = ZipEntry.STORED; size = mt.size.toLong(); compressedSize = mt.size.toLong()
                crc = CRC32().also { it.update(mt) }.value
            }
            zip.putNextEntry(e); zip.write(mt); zip.closeEntry()
            for ((path, bytes) in files) {
                zip.putNextEntry(ZipEntry(path)); zip.write(bytes); zip.closeEntry()
            }
        }
    }

    private fun serialize(doc: Document): String {
        doc.outputSettings()
            .syntax(Document.OutputSettings.Syntax.xml)
            .escapeMode(Entities.EscapeMode.xhtml)
            .charset(Charsets.UTF_8)
            .prettyPrint(false)
        return doc.body().html()
    }

    private fun xhtml(title: String, body: String, epubType: String, navDoc: Boolean = false): String = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><meta charset="utf-8"/><title>${esc(title)}</title><link rel="stylesheet" type="text/css" href="styles.css"/></head>
<body class="t-$epubType">${if (navDoc) body else "<section>$body</section>"}</body>
</html>"""

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun css(req: ExportRequest): String = """
body { font-family: ${req.fontFamily}, serif; line-height: ${req.lineHeight}; margin: 5%; }
h1, h2, h3 { font-family: sans-serif; line-height: 1.25; page-break-after: avoid; }
h1 { font-size: 1.8em; margin: 1.2em 0 0.8em; }
h2 { font-size: 1.4em; } h3 { font-size: 1.15em; }
p { margin: 0 0 0.8em; }
blockquote { margin: 1em 1.5em; padding-left: 1em; border-left: 3px solid #888; font-style: italic; }
img { max-width: 100%; height: auto; }
table { border-collapse: collapse; width: 100%; margin: 1em 0; }
td, th { border: 1px solid #999; padding: 0.3em 0.5em; }
hr { border: none; border-top: 1px solid #999; margin: 1.5em 20%; }
.cover { text-align: center; margin: 0; padding: 0; } .cover img { max-height: 100%; }
.pagebreak { page-break-after: always; }
.toc-list ul { list-style: none; padding: 0; } .toc-list li { margin: 0.4em 0; } .toc-list li.l2 { margin-left: 1.2em; } .toc-list li.l3 { margin-left: 2.4em; }
.t-title, .t-dedication { text-align: center; }
"""
}
