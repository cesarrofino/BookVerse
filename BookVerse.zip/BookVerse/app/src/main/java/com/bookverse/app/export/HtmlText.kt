package com.bookverse.app.export

import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode

/** Conversão de HTML do editor para texto simples (usada no TXT). */
object HtmlText {

    private val blockTags = setOf(
        "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "ul", "ol", "li",
        "table", "tr", "section", "figure", "figcaption", "pre", "hr"
    )

    fun toPlain(html: String): String {
        val body = Jsoup.parseBodyFragment(html).body()
        val sb = StringBuilder()
        walk(body, sb, listCounter = IntArray(1), ordered = false)
        return sb.toString()
            .replace(Regex("[ \\t]+\\n"), "\n")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private fun walk(node: Node, sb: StringBuilder, listCounter: IntArray, ordered: Boolean) {
        when (node) {
            is TextNode -> {
                val t = node.wholeText.replace(' ', ' ')
                if (t.isNotBlank() || (sb.isNotEmpty() && !sb.endsWith("\n") && t.isNotEmpty())) {
                    sb.append(if (sb.endsWith("\n") || sb.isEmpty()) t.trimStart('\n', '\r') else t.replace(Regex("[\\r\\n]+"), " "))
                }
            }
            is Element -> {
                val tag = node.tagName().lowercase()
                if (tag == "script" || tag == "style") return
                if (tag == "br") { sb.append('\n'); return }
                if (tag == "hr") { ensureBlankLine(sb); sb.append("* * *"); sb.append("\n\n"); return }
                if (tag == "img") {
                    val alt = node.attr("alt")
                    ensureNewline(sb); sb.append("[Imagem").append(if (alt.isNotBlank()) ": $alt" else "").append("]\n"); return
                }
                if (node.hasClass("pagebreak") || node.attr("style").contains("page-break")) {
                    ensureBlankLine(sb); sb.append("\u000C\n"); return
                }
                val isBlock = tag in blockTags
                if (isBlock && tag != "li" && tag != "tr") ensureBlankLine(sb) else if (isBlock) ensureNewline(sb)
                when (tag) {
                    "ul", "ol" -> {
                        val counter = IntArray(1)
                        for (c in node.childNodes()) walk(c, sb, counter, tag == "ol")
                        ensureBlankLine(sb)
                        return
                    }
                    "li" -> {
                        listCounter[0]++
                        sb.append(if (ordered) "${listCounter[0]}. " else "• ")
                    }
                    "blockquote" -> sb.append("    ")
                    "td", "th" -> if (sb.isNotEmpty() && !sb.endsWith("\n")) sb.append(" | ")
                }
                for (c in node.childNodes()) walk(c, sb, listCounter, ordered)
                if (isBlock) {
                    if (tag == "li" || tag == "tr") ensureNewline(sb) else ensureBlankLine(sb)
                }
            }
        }
    }

    private fun ensureNewline(sb: StringBuilder) { if (sb.isNotEmpty() && !sb.endsWith("\n")) sb.append('\n') }
    private fun ensureBlankLine(sb: StringBuilder) {
        if (sb.isEmpty()) return
        if (!sb.endsWith("\n")) sb.append('\n')
        if (!sb.endsWith("\n\n")) sb.append('\n')
    }
}
