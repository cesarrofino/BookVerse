package com.bookverse.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import com.bookverse.app.bridge.ActivityHost
import com.bookverse.app.bridge.NativeBridge
import kotlinx.coroutines.CompletableDeferred
import java.io.File

/**
 * Única Activity: hospeda a interface web (HTML/CSS/JS) servida localmente por WebViewAssetLoader
 * (sem acesso a ficheiros arbitrários) e liga-a ao código nativo através de [NativeBridge].
 */
class MainActivity : AppCompatActivity(), ActivityHost {

    override val activity: Activity get() = this
    private lateinit var webView: WebView
    private lateinit var bridge: NativeBridge

    private var imageDeferred: CompletableDeferred<Uri?>? = null
    private var createDeferred: CompletableDeferred<Uri?>? = null
    private var openDeferred: CompletableDeferred<Uri?>? = null
    private var resultDeferred: CompletableDeferred<Intent?>? = null
    private var cameraUri: Uri? = null

    private val pickGallery = registerForActivityResult(ActivityResultContracts.GetContent()) { imageDeferred?.complete(it) }
    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        imageDeferred?.complete(if (ok) cameraUri else null)
    }
    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { createDeferred?.complete(it) }
    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { openDeferred?.complete(it) }
    private val genericResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        resultDeferred?.complete(r.data)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        val app = application as BookVerseApp
        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.TRANSPARENT)
            overScrollMode = WebView.OVER_SCROLL_NEVER
        }
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            setSupportZoom(false)
            textZoom = 100
        }

        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/media/", WebViewAssetLoader.InternalStoragePathHandler(this, app.repository.media.root))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // só o conteúdo local é carregado na WebView; links externos abrem no navegador do sistema
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                return true
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (BuildConfig.DEBUG) android.util.Log.d("BookVerseJS", "${m.message()} (${m.sourceId()}:${m.lineNumber()})")
                return true
            }
        }

        bridge = NativeBridge(app, this, webView)
        webView.addJavascriptInterface(bridge, "Android")
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("(window.bvBack ? window.bvBack() : false)") { handled ->
                    if (handled != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    override fun onPause() {
        // pede ao editor que grave imediatamente: nada se perde ao sair da aplicação
        webView.evaluateJavascript("window.bvFlush && window.bvFlush()", null)
        super.onPause()
    }

    override fun onDestroy() {
        bridge.destroy()
        webView.destroy()
        super.onDestroy()
    }

    // ---------- ActivityHost ----------

    override suspend fun pickImage(fromCamera: Boolean): Uri? {
        val d = CompletableDeferred<Uri?>()
        imageDeferred = d
        if (fromCamera) {
            val dir = File(cacheDir, "share").also { it.mkdirs() }
            val f = File(dir, "camera_${System.currentTimeMillis()}.jpg")
            cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            takePhoto.launch(cameraUri!!)
        } else {
            pickGallery.launch("image/*")
        }
        return d.await()
    }

    override suspend fun createDocument(suggestedName: String, mime: String): Uri? {
        val d = CompletableDeferred<Uri?>()
        createDeferred = d
        createDoc.launch(suggestedName)
        return d.await()
    }

    override suspend fun openDocument(mimes: Array<String>): Uri? {
        val d = CompletableDeferred<Uri?>()
        openDeferred = d
        openDoc.launch(mimes)
        return d.await()
    }

    override suspend fun launchForResult(intent: Intent): Intent? {
        val d = CompletableDeferred<Intent?>()
        resultDeferred = d
        genericResult.launch(intent)
        return d.await()
    }

    override fun setSystemBars(colorHex: String, darkIcons: Boolean) {
        val c = try { Color.parseColor(colorHex) } catch (_: Exception) { return }
        window.statusBarColor = c
        window.navigationBarColor = c
        window.decorView.setBackgroundColor(c)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = darkIcons
            isAppearanceLightNavigationBars = darkIcons
        }
    }
}
