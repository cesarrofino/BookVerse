package com.bookverse.app.sync

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.bookverse.app.BookVerseApp
import java.util.concurrent.TimeUnit

/**
 * Executa a sincronização quando há rede. Em caso de falha devolve retry(), com recuo exponencial:
 * é assim que as operações falhadas são repetidas automaticamente.
 */
class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as BookVerseApp
        val auth = app.auth
        if (!auth.isConfigured) return Result.success()
        val uid = auth.currentUid()
        if (uid.isEmpty()) return Result.success()
        if (auth.currentUser() == null) return Result.retry() // sessão ainda a ser restaurada
        val report = SyncManager(applicationContext, app.repository).syncAll(uid)
        return if (report.errors > 0 && runAttemptCount < 8) Result.retry() else Result.success()
    }

    companion object {
        private const val NAME = "bookverse_sync"

        fun enqueue(context: Context, delaySeconds: Long = 0, wifiOnly: Boolean = false) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                .build()
            val req = OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(constraints)
                .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()
            // REPLACE com atraso agrupa várias gravações seguidas numa só sincronização
            WorkManager.getInstance(context).enqueueUniqueWork(NAME, ExistingWorkPolicy.REPLACE, req)
        }
    }
}
