package com.bookverse.app.sync

import android.content.Context
import com.bookverse.app.data.BookEntity
import com.bookverse.app.data.BookRepository
import com.bookverse.app.data.BookVersionEntity
import com.bookverse.app.data.AppDatabase
import com.bookverse.app.data.MediaEntity
import com.bookverse.app.data.SyncState
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

/**
 * Sincronização local-primeiro com Firestore + Storage.
 *
 *  users/{uid}/books/{bookId}      metadados + conteúdo (docJson) + remoteRev
 *  Storage users/{uid}/books/{bookId}/doc.json   conteúdo quando excede o limite do Firestore
 *  Storage users/{uid}/books/{bookId}/media/{ficheiro}   imagens e capas
 *
 * Conflito = a nuvem avançou (remoteRev > syncedRev) enquanto o livro local também foi alterado.
 * Nesse caso AMBAS as versões são mantidas: a que "perde" fica guardada como versão recuperável.
 * Uma falha de rede nunca apaga ou altera conteúdo local válido.
 */
class SyncManager(private val context: Context, private val repo: BookRepository) {

    data class Report(val pushed: Int = 0, val pulled: Int = 0, val conflicts: Int = 0, val errors: Int = 0, val message: String = "")

    companion object {
        private val mutex = Mutex()
        private const val INLINE_LIMIT = 600_000
        private const val TIMEOUT_MS = 60_000L
        @Volatile var lastReport: Report = Report()
        @Volatile var lastSyncAt: Long = 0L
        @Volatile var running: Boolean = false
    }

    private val fs get() = FirebaseFirestore.getInstance()
    private val storage get() = FirebaseStorage.getInstance()
    private val db = AppDatabase.get(context)

    suspend fun syncAll(uid: String): Report {
        if (uid.isEmpty()) return Report(message = "Sem sessão")
        if (!mutex.tryLock()) return lastReport
        running = true
        try {
            repo.claimLocalBooks(uid)
            var pushed = 0; var pulled = 0; var conflicts = 0; var errors = 0
            var message = ""

            // 1) enviar alterações locais
            for (b in repo.pending(uid)) {
                try {
                    val r = withTimeout(TIMEOUT_MS * 3) { push(uid, b) }
                    if (r == PushResult.CONFLICT) conflicts++
                    pushed++
                } catch (e: Exception) {
                    errors++
                    message = e.message ?: "Erro de sincronização"
                    repo.setSyncResult(b.id, SyncState.ERROR, message.take(200), b.syncedRev)
                }
            }

            // 2) descarregar novidades
            try {
                val snap = withTimeout(TIMEOUT_MS) { fs.collection("users").document(uid).collection("books").get().await() }
                for (d in snap.documents) {
                    try {
                        if (pull(uid, d)) pulled++
                    } catch (e: Exception) {
                        errors++; message = e.message ?: "Erro ao descarregar"
                    }
                }
            } catch (e: Exception) {
                errors++; message = e.message ?: "Sem ligação"
            }

            lastReport = Report(pushed, pulled, conflicts, errors, message)
            if (errors == 0) lastSyncAt = System.currentTimeMillis()
            return lastReport
        } finally {
            running = false
            mutex.unlock()
        }
    }

    private enum class PushResult { OK, CONFLICT }

    private suspend fun push(uid: String, local: BookEntity): PushResult {
        val ref = fs.collection("users").document(uid).collection("books").document(local.id)
        val remote = ref.get().await()
        val remoteRev = remote.getLong("remoteRev") ?: 0L
        var conflict = false

        // Eliminação local
        if (local.deleted) {
            ref.set(mapOf("deleted" to true, "updatedAt" to local.updatedAt, "remoteRev" to remoteRev + 1,
                "title" to local.title), com.google.firebase.firestore.SetOptions.merge()).await()
            repo.hardDelete(local.id)
            return PushResult.OK
        }

        // Deteção de conflito: a nuvem avançou desde a última sincronização
        if (remote.exists() && remoteRev > local.syncedRev && remote.getBoolean("deleted") != true) {
            val remoteDoc = readRemoteDoc(uid, local.id, remote)
            val remoteUpdated = remote.getLong("updatedAt") ?: 0L
            if (remoteDoc != null && remoteDoc != local.docJson) {
                conflict = true
                if (remoteUpdated > local.updatedAt) {
                    // a nuvem é mais recente: guarda a cópia local como versão e aplica a da nuvem
                    db.versions().insert(BookVersionEntity(bookId = local.id, createdAt = System.currentTimeMillis(),
                        label = "Conflito: versão deste dispositivo", title = local.title, wordCount = local.wordCount, docJson = local.docJson))
                    applyRemote(uid, local, remote, remoteDoc)
                    return PushResult.CONFLICT
                } else {
                    // local mais recente: guarda a versão da nuvem localmente antes de a substituir
                    db.versions().insert(BookVersionEntity(bookId = local.id, createdAt = System.currentTimeMillis(),
                        label = "Conflito: versão da nuvem", title = remote.getString("title") ?: local.title,
                        wordCount = (remote.getLong("wordCount") ?: 0L).toInt(), docJson = remoteDoc))
                }
            }
        }

        // Media (imagens e capa) antes do documento
        val mediaNames = uploadMedia(uid, local)

        val docJson = local.docJson
        val data = hashMapOf<String, Any?>(
            "title" to local.title, "subtitle" to local.subtitle, "author" to local.author,
            "description" to local.description, "category" to local.category, "language" to local.language,
            "publisher" to local.publisher, "year" to local.year, "copyright" to local.copyright, "isbn" to local.isbn,
            "status" to local.status, "favorite" to local.favorite, "archived" to local.archived,
            "progress" to local.progress, "wordCount" to local.wordCount,
            "createdAt" to local.createdAt, "updatedAt" to local.updatedAt,
            "coverPath" to local.coverPath, "mediaFiles" to mediaNames, "deleted" to false,
            "remoteRev" to remoteRev + 1
        )
        if (docJson.length <= INLINE_LIMIT) {
            data["docJson"] = docJson
            data["docInStorage"] = false
        } else {
            storage.reference.child("users/$uid/books/${local.id}/doc.json")
                .putBytes(docJson.toByteArray(Charsets.UTF_8)).await()
            data["docJson"] = ""
            data["docInStorage"] = true
        }
        ref.set(data).await()

        // só marca como sincronizado se o livro não foi editado entretanto
        val now = repo.raw(local.id)
        if (now != null && now.rev == local.rev) repo.setSyncResult(local.id, SyncState.SYNCED, "", remoteRev + 1)
        else if (now != null) repo.setSyncResult(local.id, SyncState.PENDING, "", remoteRev + 1)
        return if (conflict) PushResult.CONFLICT else PushResult.OK
    }

    private suspend fun uploadMedia(uid: String, b: BookEntity): List<String> {
        val names = mutableListOf<String>()
        val dir = repo.media.bookDir(b.id)
        val known = repo.mediaDao().forBook(b.id).associateBy { it.fileName }
        for (f in dir.listFiles()?.filter { it.isFile } ?: emptyList()) {
            names.add(f.name)
            if (known[f.name]?.uploaded == true) continue
            storage.reference.child("users/$uid/books/${b.id}/media/${f.name}").putFile(android.net.Uri.fromFile(f)).await()
            repo.mediaDao().upsert(MediaEntity(b.id, f.name, f.length(), true))
        }
        return names
    }

    private suspend fun readRemoteDoc(uid: String, id: String, d: DocumentSnapshot): String? =
        if (d.getBoolean("docInStorage") == true) {
            val bytes = storage.reference.child("users/$uid/books/$id/doc.json").getBytes(30L * 1024 * 1024).await()
            String(bytes, Charsets.UTF_8)
        } else d.getString("docJson")

    /** @return true se o livro local foi criado/atualizado. */
    private suspend fun pull(uid: String, d: DocumentSnapshot): Boolean {
        val id = d.id
        val remoteRev = d.getLong("remoteRev") ?: 0L
        val local = repo.raw(id)

        if (d.getBoolean("deleted") == true) {
            // eliminado noutro dispositivo: só remove localmente se não houver alterações locais por enviar
            if (local != null && local.syncState != SyncState.PENDING && local.syncState != SyncState.ERROR && local.syncedRev < remoteRev) {
                repo.hardDelete(id); return true
            }
            return false
        }
        if (local != null && (local.syncedRev >= remoteRev || local.syncState == SyncState.PENDING || local.syncState == SyncState.ERROR)) return false

        val doc = readRemoteDoc(uid, id, d) ?: return false
        runCatching { JSONObject(doc) }.getOrNull() ?: return false

        // imagens em falta
        val names = (d.get("mediaFiles") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        for (n in names) {
            val f = repo.media.file(id, n)
            if (!f.exists()) {
                storage.reference.child("users/$uid/books/$id/media/$n").getFile(f).await()
            }
            repo.mediaDao().upsert(MediaEntity(id, n, f.length(), true))
        }
        if (local != null) {
            // preserva a versão local anterior como recuperável
            db.versions().insert(BookVersionEntity(bookId = id, createdAt = System.currentTimeMillis(), label = "Antes de atualizar da nuvem",
                title = local.title, wordCount = local.wordCount, docJson = local.docJson))
        }
        val now = System.currentTimeMillis()
        val e = BookEntity(
            id = id, ownerUid = uid, title = d.getString("title") ?: "Sem título", subtitle = d.getString("subtitle") ?: "",
            author = d.getString("author") ?: "", description = d.getString("description") ?: "",
            category = d.getString("category") ?: "Outros", language = d.getString("language") ?: "pt",
            publisher = d.getString("publisher") ?: "", year = d.getString("year") ?: "",
            copyright = d.getString("copyright") ?: "", isbn = d.getString("isbn") ?: "",
            status = d.getString("status") ?: "draft", favorite = d.getBoolean("favorite") ?: false,
            archived = d.getBoolean("archived") ?: false, exported = local?.exported ?: false,
            progress = (d.getLong("progress") ?: 0L).toInt(), wordCount = (d.getLong("wordCount") ?: 0L).toInt(),
            createdAt = d.getLong("createdAt") ?: now, updatedAt = d.getLong("updatedAt") ?: now,
            rev = (local?.rev ?: 0L) + 1, syncedRev = remoteRev, syncState = SyncState.SYNCED,
            coverPath = d.getString("coverPath") ?: "", docJson = doc
        )
        repo.putRaw(e)
        return true
    }

    private suspend fun applyRemote(uid: String, local: BookEntity, d: DocumentSnapshot, doc: String) {
        val names = (d.get("mediaFiles") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        for (n in names) {
            val f = repo.media.file(local.id, n)
            if (!f.exists()) storage.reference.child("users/$uid/books/${local.id}/media/$n").getFile(f).await()
            repo.mediaDao().upsert(MediaEntity(local.id, n, f.length(), true))
        }
        val remoteRev = d.getLong("remoteRev") ?: 0L
        repo.putRaw(local.copy(
            title = d.getString("title") ?: local.title, subtitle = d.getString("subtitle") ?: local.subtitle,
            author = d.getString("author") ?: local.author, description = d.getString("description") ?: local.description,
            category = d.getString("category") ?: local.category,
            wordCount = (d.getLong("wordCount") ?: 0L).toInt(), progress = (d.getLong("progress") ?: 0L).toInt(),
            updatedAt = d.getLong("updatedAt") ?: local.updatedAt, rev = local.rev + 1,
            syncedRev = remoteRev, syncState = SyncState.SYNCED, syncError = "",
            coverPath = d.getString("coverPath") ?: local.coverPath, docJson = doc
        ))
    }

    /** Elimina todos os dados do utilizador na nuvem (opcional, a pedido). Os livros locais não são tocados. */
    suspend fun wipeCloud(uid: String) {
        val snap = fs.collection("users").document(uid).collection("books").get().await()
        for (d in snap.documents) {
            val id = d.id
            runCatching {
                val list = storage.reference.child("users/$uid/books/$id/media").listAll().await()
                list.items.forEach { it.delete().await() }
                runCatching { storage.reference.child("users/$uid/books/$id/doc.json").delete().await() }
            }
            d.reference.delete().await()
        }
        // os livros locais passam a pendentes para voltarem a ser enviados se o utilizador quiser
        for (b in repo.allForBackup().filter { it.ownerUid == uid }) {
            repo.putRaw(b.copy(syncState = SyncState.PENDING, syncedRev = 0))
            repo.mediaDao().forBook(b.id).forEach { repo.mediaDao().upsert(it.copy(uploaded = false)) }
        }
    }
}
