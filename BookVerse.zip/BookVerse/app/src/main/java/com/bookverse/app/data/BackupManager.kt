package com.bookverse.app.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup local completo (.bvbackup = ZIP): livros em books.json e imagens em media/{livro}/{ficheiro}.
 * Funciona totalmente offline e valida o ficheiro ao importar.
 */
class BackupManager(private val context: Context, private val repo: BookRepository) {

    private val safeId = Regex("^[A-Za-z0-9-]{1,64}$")
    private val safeName = Regex("^[A-Za-z0-9._-]{1,120}$")

    suspend fun export(target: Uri): Int {
        val list = repo.allForBackup()
        val arr = JSONArray()
        for (b in list) {
            arr.put(JSONObject().apply {
                put("id", b.id); put("title", b.title); put("subtitle", b.subtitle); put("author", b.author)
                put("description", b.description); put("category", b.category); put("language", b.language)
                put("publisher", b.publisher); put("year", b.year); put("copyright", b.copyright); put("isbn", b.isbn)
                put("status", b.status); put("favorite", b.favorite); put("archived", b.archived)
                put("progress", b.progress); put("wordCount", b.wordCount)
                put("createdAt", b.createdAt); put("updatedAt", b.updatedAt)
                put("coverPath", b.coverPath)
                put("docJson", b.docJson)
            })
        }
        context.contentResolver.openOutputStream(target, "wt")?.use { raw ->
            ZipOutputStream(raw).use { zip ->
                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(JSONObject().put("app", "BookVerse").put("format", 1).put("count", list.size).toString().toByteArray())
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("books.json"))
                zip.write(arr.toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                for (b in list) {
                    repo.media.bookDir(b.id).listFiles()?.filter { it.isFile }?.forEach { f ->
                        zip.putNextEntry(ZipEntry("media/${b.id}/${f.name}"))
                        f.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
        } ?: throw IllegalStateException("Não foi possível escrever o backup")
        return list.size
    }

    /** Importa um backup. Livros já existentes com o mesmo id e mais recentes localmente não são substituídos. */
    suspend fun import(source: Uri): Int {
        var booksJson: String? = null
        val media = mutableListOf<Triple<String, String, ByteArray>>()
        var total = 0L
        context.contentResolver.openInputStream(source)?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var e: ZipEntry? = zip.nextEntry
                while (e != null) {
                    val name = e.name
                    if (!e.isDirectory && !name.contains("..")) {
                        val buf = ByteArrayOutputStream()
                        val chunk = ByteArray(16 * 1024)
                        while (true) {
                            val n = zip.read(chunk)
                            if (n < 0) break
                            total += n
                            if (total > 800L * 1024 * 1024) throw IllegalArgumentException("Backup demasiado grande")
                            buf.write(chunk, 0, n)
                        }
                        when {
                            name == "books.json" -> booksJson = buf.toString("UTF-8")
                            name.startsWith("media/") -> {
                                val p = name.removePrefix("media/").split('/')
                                if (p.size == 2 && safeId.matches(p[0]) && safeName.matches(p[1])) {
                                    media.add(Triple(p[0], p[1], buf.toByteArray()))
                                }
                            }
                        }
                    }
                    zip.closeEntry()
                    e = zip.nextEntry
                }
            }
        } ?: throw IllegalArgumentException("Não foi possível abrir o ficheiro")

        val json = booksJson ?: throw IllegalArgumentException("Ficheiro de backup inválido (books.json em falta)")
        val arr = try { JSONArray(json) } catch (e: Exception) { throw IllegalArgumentException("Ficheiro de backup corrompido") }

        var imported = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            if (!safeId.matches(id)) continue
            val existing = repo.raw(id)
            if (existing != null && existing.updatedAt >= o.optLong("updatedAt")) continue
            val now = System.currentTimeMillis()
            val entity = BookEntity(
                id = id,
                ownerUid = existing?.ownerUid ?: repo.currentUid,
                title = o.optString("title", "Sem título").ifBlank { "Sem título" },
                subtitle = o.optString("subtitle"), author = o.optString("author"),
                description = o.optString("description"), category = o.optString("category", "Outros"),
                language = o.optString("language", "pt"), publisher = o.optString("publisher"),
                year = o.optString("year"), copyright = o.optString("copyright"), isbn = o.optString("isbn"),
                status = o.optString("status", "draft"), favorite = o.optBoolean("favorite"),
                archived = o.optBoolean("archived"), progress = o.optInt("progress"),
                wordCount = o.optInt("wordCount"), createdAt = o.optLong("createdAt", now),
                updatedAt = now, rev = (existing?.rev ?: 0) + 1, syncedRev = existing?.syncedRev ?: 0,
                syncState = if (repo.currentUid.isEmpty()) SyncState.LOCAL_ONLY else SyncState.PENDING,
                coverPath = o.optString("coverPath"), docJson = o.optString("docJson", "{}")
            )
            // valida que o documento é JSON
            runCatching { JSONObject(entity.docJson) }.getOrElse { continue }
            repo.putRaw(entity)
            imported++
        }
        for ((bookId, name, bytes) in media) {
            if (repo.raw(bookId) == null) continue
            repo.media.file(bookId, name).writeBytes(bytes)
            repo.mediaDao().upsert(MediaEntity(bookId, name, bytes.size.toLong(), false))
        }
        return imported
    }
}
