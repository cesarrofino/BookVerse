package com.bookverse.app

import android.app.Application
import com.bookverse.app.data.BackupManager
import com.bookverse.app.data.BookRepository
import com.bookverse.app.data.SettingsStore
import com.bookverse.app.export.ExportManager
import com.bookverse.app.sync.AuthManager
import com.bookverse.app.sync.CommunityManager
import com.google.firebase.FirebaseApp

/** Contentor simples de dependências partilhadas por toda a aplicação. */
class BookVerseApp : Application() {
    lateinit var settings: SettingsStore
    lateinit var repository: BookRepository
    lateinit var auth: AuthManager
    lateinit var community: CommunityManager
    lateinit var exporter: ExportManager
    lateinit var backup: BackupManager

    override fun onCreate() {
        super.onCreate()
        try { FirebaseApp.initializeApp(this) } catch (_: Exception) {}
        settings = SettingsStore(this)
        repository = BookRepository(this)
        auth = AuthManager(this, settings)
        community = CommunityManager(auth)
        repository.currentUid = auth.currentUid()
        exporter = ExportManager(this, repository)
        backup = BackupManager(this, repository)
    }
}
