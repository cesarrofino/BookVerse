package com.bookverse.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

/** Colunas leves (sem o documento) para listagens. */
data class BookSummary(
    val id: String,
    val title: String,
    val subtitle: String,
    val author: String,
    val category: String,
    val status: String,
    val favorite: Boolean,
    val archived: Boolean,
    val exported: Boolean,
    val progress: Int,
    val wordCount: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val syncState: String,
    val coverPath: String
)

@Dao
interface BookDao {
    @Query(
        "SELECT id,title,subtitle,author,category,status,favorite,archived,exported,progress,wordCount," +
            "createdAt,updatedAt,syncState,coverPath FROM books " +
            "WHERE deleted = 0 AND ownerUid IN ('', :uid) ORDER BY updatedAt DESC"
    )
    suspend fun summaries(uid: String): List<BookSummary>

    @Query("SELECT * FROM books WHERE id = :id LIMIT 1")
    suspend fun get(id: String): BookEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(book: BookEntity)

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun hardDelete(id: String)

    @Query("UPDATE books SET deleted = 1, updatedAt = :now, rev = rev + 1, syncState = 'pending' WHERE id = :id")
    suspend fun markDeleted(id: String, now: Long)

    @Query("UPDATE books SET favorite = :v, updatedAt = :now, rev = rev + 1, syncState = CASE WHEN syncState = 'local' THEN 'local' ELSE 'pending' END WHERE id = :id")
    suspend fun setFavorite(id: String, v: Boolean, now: Long)

    @Query("UPDATE books SET archived = :v, updatedAt = :now, rev = rev + 1, syncState = CASE WHEN syncState = 'local' THEN 'local' ELSE 'pending' END WHERE id = :id")
    suspend fun setArchived(id: String, v: Boolean, now: Long)

    @Query("UPDATE books SET status = :v, updatedAt = :now, rev = rev + 1, syncState = CASE WHEN syncState = 'local' THEN 'local' ELSE 'pending' END WHERE id = :id")
    suspend fun setStatus(id: String, v: String, now: Long)

    @Query("UPDATE books SET exported = 1 WHERE id = :id")
    suspend fun markExported(id: String)

    @Query("UPDATE books SET coverPath = :path WHERE id = :id")
    suspend fun setCoverPath(id: String, path: String)

    /** Livros do utilizador com alterações por enviar (inclui eliminados). */
    @Query("SELECT * FROM books WHERE ownerUid = :uid AND syncState IN ('pending','error')")
    suspend fun pendingFor(uid: String): List<BookEntity>

    /** Livros criados offline sem dono: serão associados ao utilizador ao iniciar sessão. */
    @Query("UPDATE books SET ownerUid = :uid, syncState = 'pending' WHERE ownerUid = ''")
    suspend fun claimLocal(uid: String)

    @Query("UPDATE books SET syncState = :state, syncError = :err, syncedRev = :syncedRev WHERE id = :id")
    suspend fun setSyncResult(id: String, state: String, err: String, syncedRev: Long)

    @Query("SELECT COUNT(*) FROM books WHERE deleted = 0 AND ownerUid IN ('', :uid) AND syncState IN ('pending','error')")
    suspend fun pendingCount(uid: String): Int

    @Query("SELECT * FROM books WHERE deleted = 0")
    suspend fun allForBackup(): List<BookEntity>
}

@Dao
interface VersionDao {
    @Insert
    suspend fun insert(v: BookVersionEntity): Long

    @Query("SELECT vid,bookId,createdAt,label,title,wordCount,'' AS docJson FROM book_versions WHERE bookId = :bookId ORDER BY createdAt DESC")
    suspend fun list(bookId: String): List<BookVersionEntity>

    @Query("SELECT * FROM book_versions WHERE vid = :vid LIMIT 1")
    suspend fun get(vid: Long): BookVersionEntity?

    @Query("SELECT createdAt FROM book_versions WHERE bookId = :bookId ORDER BY createdAt DESC LIMIT 1")
    suspend fun lastCreatedAt(bookId: String): Long?

    /** Mantém apenas as [keep] versões mais recentes. */
    @Query(
        "DELETE FROM book_versions WHERE bookId = :bookId AND vid NOT IN " +
            "(SELECT vid FROM book_versions WHERE bookId = :bookId ORDER BY createdAt DESC LIMIT :keep)"
    )
    suspend fun prune(bookId: String, keep: Int)
}

@Dao
interface MediaDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(m: MediaEntity)

    @Query("SELECT * FROM media WHERE bookId = :bookId")
    suspend fun forBook(bookId: String): List<MediaEntity>

    @Query("UPDATE media SET uploaded = 1 WHERE bookId = :bookId AND fileName = :fileName")
    suspend fun markUploaded(bookId: String, fileName: String)

    @Query("DELETE FROM media WHERE bookId = :bookId AND fileName = :fileName")
    suspend fun delete(bookId: String, fileName: String)

    @Query("SELECT COALESCE(SUM(sizeBytes),0) FROM media")
    suspend fun totalBytes(): Long
}
