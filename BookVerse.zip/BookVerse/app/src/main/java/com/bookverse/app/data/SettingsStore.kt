package com.bookverse.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

/**
 * Definições da aplicação. As preferências gerais ficam em SharedPreferences normais;
 * dados sensíveis (identificador de sessão em cache, etc.) ficam num ficheiro cifrado.
 */
class SettingsStore(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("bookverse_settings", Context.MODE_PRIVATE)

    private val secure: SharedPreferences = try {
        val key = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context.applicationContext,
            "bookverse_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Em casos raros (keystore corrompido) recorre a preferências privadas normais.
        context.applicationContext.getSharedPreferences("bookverse_secure_fallback", Context.MODE_PRIVATE)
    }

    private val defaults = mapOf(
        "theme" to "auto",              // light | dark | auto
        "language" to "pt",
        "defaultFont" to "serif",
        "defaultFontSize" to "12",
        "lineHeight" to "1.5",
        "paragraphSpacing" to "8",
        "marginTop" to "20",
        "marginBottom" to "20",
        "marginInner" to "20",
        "marginOuter" to "20",
        "autosave" to "true",
        "autosaveSeconds" to "3",
        "exportPageSize" to "A5",
        "exportOrientation" to "portrait",
        "exportImageQuality" to "high",
        "exportIncludeBackCover" to "true",
        "syncWifiOnly" to "false",
        "syncAuto" to "true"
    )

    fun all(): JSONObject {
        val o = JSONObject()
        for ((k, v) in defaults) o.put(k, prefs.getString(k, v))
        return o
    }

    fun get(key: String): String = prefs.getString(key, defaults[key] ?: "") ?: ""

    fun getBool(key: String): Boolean = get(key) == "true"

    fun set(key: String, value: String) {
        if (key in defaults) prefs.edit().putString(key, value).apply()
    }

    fun setAll(json: JSONObject) {
        val e = prefs.edit()
        for (k in json.keys()) if (k in defaults) e.putString(k, json.optString(k))
        e.apply()
    }

    fun secureGet(key: String): String = secure.getString(key, "") ?: ""
    fun securePut(key: String, value: String) = secure.edit().putString(key, value).apply()
    fun secureRemove(key: String) = secure.edit().remove(key).apply()
}
