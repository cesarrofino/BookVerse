package com.bookverse.app.bridge

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.bookverse.app.BookVerseApp
import com.bookverse.app.BuildConfig
import com.bookverse.app.export.ExportRequest
import com.bookverse.app.share.ShareHelper
import com.bookverse.app.sync.AuthManager
import com.bookverse.app.sync.SyncManager
import com.bookverse.app.sync.SyncWorker
import com.bookverse.app.data.MediaEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Ponte única JavaScript → Kotlin. O JS chama Android.call(id, método, jsonArgs) e recebe o resultado
 * em window.__bvResolve(id, ok, jsonResultado). Todo o trabalho pesado corre fora da thread principal.
 */
class NativeBridge(
    private val app: BookVerseApp,
    private val host: ActivityHost,
    private val webView: WebView
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private val repo get() = app.repository
    private val settings get() = app.settings
    private val context: Context get() = app

    fun destroy() = scope.cancel()

    @JavascriptInterface
    fun call(id: Int, method: String, argsJson: String) {
        scope.launch {
            try {
                val args = if (argsJson.isBlank()) JSONObject() else JSONObject(argsJson)
                val io = withContext(Dispatchers.IO) { dispatchIo(method, args) }
                val result = if (io === Unhandled) dispatchUi(method, args) else io
                resolve(id, true, result)
            } catch (e: AuthManager.AuthException) {
                resolve(id, false, e.message ?: "Erro")
            } catch (e: Exception) {
                resolve(id, false, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun resolve(id: Int, ok: Boolean, value: Any?) {
        val payload = when (value) {
            null, Unit -> "null"
            is JSONObject, is JSONArray -> value.toString()
            is String -> JSONObject.quote(value)
            else -> value.toString()
        }
        val js = "window.__bvResolve($id, $ok, $payload)"
        main.post { webView.evaluateJavascript(js, null) }
    }

    private object Unhandled

    /** Métodos que não precisam de Activity. Devolve [Unhandled] para delegar em [dispatchUi]. */
    private suspend fun dispatchIo(method: String, a: JSONObject): Any = when (method) {
        // ---- definições ----
        "settings.get" -> settings.all()
        "settings.set" -> { settings.set(a.getString("key"), a.getString("value")); Unit }
        "settings.setAll" -> { settings.setAll(a); Unit }

        // ---- livros ----
        "books.list" -> repo.list()
        "books.get" -> repo.get(a.getString("id")) ?: throw IllegalArgumentException("Livro não encontrado")
        "books.save" -> {
            val saved = repo.save(a)
            if (app.auth.isConfigured && repo.currentUid.isNotEmpty() && settings.getBool("syncAuto")) {
                SyncWorker.enqueue(context, 8, settings.getBool("syncWifiOnly"))
            }
            saved
        }
        "books.delete" -> { repo.delete(a.getString("id")); kickSync(); Unit }
        "books.duplicate" -> (repo.duplicate(a.getString("id")) ?: JSONObject.NULL).also { kickSync() }
        "books.setFlag" -> { repo.setFlag(a.getString("id"), a.getString("field"), a.getString("value")); kickSync(); Unit }
        "books.rename" -> { repo.rename(a.getString("id"), a.getString("title")); kickSync(); Unit }
        "books.versions" -> repo.listVersions(a.getString("id"))
        "books.restoreVersion" -> repo.restoreVersion(a.getLong("vid")) ?: throw IllegalArgumentException("Versão não encontrada")
        "books.snapshot" -> { repo.addVersionSnapshot(a.getString("id"), a.optString("label", "Versão manual")); Unit }

        // ---- media ----
        "media.saveDataUrl" -> {
            val bookId = a.getString("bookId")
            val img = repo.media.saveDataUrl(bookId, a.getString("dataUrl"), a.getString("name"))
            repo.mediaDao().upsert(MediaEntity(bookId, img.fileName, img.size, false))
            if (a.optBoolean("isFrontCover", false)) repo.setCover(bookId, img.fileName)
            JSONObject().put("url", img.url).put("fileName", img.fileName)
        }

        // ---- exportação ----
        "export.run" -> {
            val r = app.exporter.export(ExportRequest(a))
            JSONObject().put("path", r.path).put("fileName", r.fileName).put("mime", r.mime).put("size", r.sizeBytes)
        }
        "export.saveImage" -> {
            val r = app.exporter.saveImage(a.optString("bookId"), a.getString("dataUrl"), a.optString("name", "capa"))
            JSONObject().put("path", r.path).put("fileName", r.fileName).put("mime", r.mime).put("size", r.sizeBytes)
        }
        "export.share" -> {
            val f = app.exporter.resolveExport(a.getString("path")) ?: throw IllegalArgumentException("Ficheiro não encontrado. Exporte novamente.")
            val ok = withContext(Dispatchers.Main) { ShareHelper.share(host.activity, f, a.getString("mime"), a.optString("subject", f.name)) }
            if (!ok) throw IllegalStateException("Nenhuma aplicação disponível para partilhar")
            Unit
        }
        "export.open" -> {
            val f = app.exporter.resolveExport(a.getString("path")) ?: throw IllegalArgumentException("Ficheiro não encontrado. Exporte novamente.")
            val ok = withContext(Dispatchers.Main) { ShareHelper.open(host.activity, f, a.getString("mime")) }
            if (!ok) throw IllegalStateException("Nenhuma aplicação instalada consegue abrir este tipo de ficheiro")
            Unit
        }

        // ---- sessão e perfil ----
        "auth.state" -> app.auth.userJson().also { it.put("bio", "") }
        "auth.register" -> { app.auth.register(a.optString("name"), a.getString("email"), a.getString("password")); afterLogin() }
        "auth.login" -> { app.auth.login(a.getString("email"), a.getString("password")); afterLogin() }
        "auth.reset" -> { app.auth.resetPassword(a.getString("email")); Unit }
        "auth.logout" -> {
            app.auth.logout(); repo.currentUid = ""; app.auth.userJson()
        }
        "auth.updateProfile" -> { app.auth.updateProfile(a.getString("name"), a.optString("bio")); app.auth.userJson() }
        "auth.bio" -> app.auth.loadBio()

        // ---- comunidade ----
        "community.list" -> app.community.list(a.optInt("limit", 40))
        "community.get" -> app.community.get(a.getString("id"))
        "community.mine" -> app.community.mine()
        "community.publish" -> app.community.publish(a)
        "community.unpublish" -> { app.community.unpublish(a.getString("id")); Unit }
        "community.react" -> app.community.react(a.getString("id"), a.getString("type"))
        "community.comments" -> app.community.comments(a.getString("id"))
        "community.comment" -> app.community.comment(a.getString("id"), a.getString("text"))
        "community.deleteComment" -> { app.community.deleteComment(a.getString("id"), a.getString("commentId")); Unit }
        "community.uploadImage" -> app.community.uploadImage(a.getString("id"), a.getString("name"), a.getString("data"))
        "community.clearImages" -> { app.community.clearImages(a.getString("id")); Unit }

        // ---- sincronização ----
        "sync.now" -> {
            val uid = app.auth.currentUid()
            if (!app.auth.isConfigured) throw IllegalStateException("Firebase não configurado (ver README)")
            if (uid.isEmpty()) throw IllegalStateException("Inicie sessão para sincronizar")
            val r = SyncManager(context, repo).syncAll(uid)
            JSONObject().put("pushed", r.pushed).put("pulled", r.pulled).put("conflicts", r.conflicts)
                .put("errors", r.errors).put("message", r.message)
        }
        "sync.status" -> JSONObject()
            .put("configured", app.auth.isConfigured)
            .put("signedIn", app.auth.currentUid().isNotEmpty())
            .put("pending", repo.pendingCount())
            .put("running", SyncManager.running)
            .put("lastSyncAt", SyncManager.lastSyncAt)
            .put("lastError", SyncManager.lastReport.message)
            .put("conflicts", SyncManager.lastReport.conflicts)
        "sync.wipeCloud" -> {
            val uid = app.auth.currentUid()
            if (uid.isEmpty()) throw IllegalStateException("Sem sessão iniciada")
            SyncManager(context, repo).wipeCloud(uid); Unit
        }

        // ---- armazenamento e aplicação ----
        "storage.info" -> {
            val stat = StatFs(context.filesDir.absolutePath)
            JSONObject()
                .put("media", repo.mediaTotalBytes())
                .put("exports", app.exporter.totalBytes())
                .put("database", File(context.getDatabasePath("bookverse.db").path).length())
                .put("books", repo.bookCount())
                .put("free", stat.availableBytes)
        }
        "storage.clearExports" -> { app.exporter.clear(); Unit }
        "app.info" -> JSONObject().put("version", BuildConfig.VERSION_NAME).put("code", BuildConfig.VERSION_CODE)
            .put("package", context.packageName)
        else -> Unhandled
    }

    private suspend fun afterLogin(): JSONObject {
        repo.currentUid = app.auth.currentUid()
        repo.claimLocalBooks(repo.currentUid)
        kickSync(0)
        return app.auth.userJson()
    }

    private fun kickSync(delay: Long = 5) {
        if (app.auth.isConfigured && repo.currentUid.isNotEmpty() && settings.getBool("syncAuto")) {
            SyncWorker.enqueue(context, delay, settings.getBool("syncWifiOnly"))
        }
    }

    /** Métodos que precisam de interface do sistema (têm de correr na thread principal). */
    private suspend fun dispatchUi(method: String, a: JSONObject): Any? {
        return when (method) {
        "media.pick" -> {
            val uri = host.pickImage(a.optBoolean("camera", false)) ?: return JSONObject().put("cancelled", true)
            val bookId = a.getString("bookId")
            val img = withContext(Dispatchers.IO) { repo.media.importImage(bookId, uri, settings.get("exportImageQuality")) }
            withContext(Dispatchers.IO) { repo.mediaDao().upsert(MediaEntity(bookId, img.fileName, img.size, false)) }
            JSONObject().put("url", img.url).put("fileName", img.fileName).put("width", img.width).put("height", img.height)
        }
        "export.saveToDevice" -> {
            val f = app.exporter.resolveExport(a.getString("path")) ?: throw IllegalArgumentException("Ficheiro não encontrado. Exporte novamente.")
            val target = host.createDocument(f.name, a.getString("mime")) ?: return JSONObject().put("cancelled", true)
            withContext(Dispatchers.IO) { ShareHelper.copyTo(context, f, target) }
            JSONObject().put("saved", true)
        }
        "backup.export" -> {
            val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date())
            val target = host.createDocument("BookVerse-backup-$stamp.bvbackup", "application/octet-stream")
                ?: return JSONObject().put("cancelled", true)
            val n = withContext(Dispatchers.IO) { app.backup.export(target) }
            JSONObject().put("count", n)
        }
        "backup.import" -> {
            val src = host.openDocument(arrayOf("application/octet-stream", "application/zip", "*/*"))
                ?: return JSONObject().put("cancelled", true)
            val n = withContext(Dispatchers.IO) { app.backup.import(src) }
            kickSync(0)
            JSONObject().put("count", n)
        }
        "auth.google" -> {
            val data = host.launchForResult(app.auth.googleIntent()) ?: throw AuthManager.AuthException("Início de sessão cancelado")
            app.auth.finishGoogle(data)
            afterLogin()
        }
        "auth.github" -> {
            app.auth.loginGithub(host.activity)
            afterLogin()
        }
        "app.setBars" -> { host.setSystemBars(a.getString("color"), a.optBoolean("darkIcons")); Unit }
        "clipboard.get" -> {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = cm.primaryClip
            val o = JSONObject().put("text", "").put("html", "")
            if (clip != null && clip.itemCount > 0) {
                val item = clip.getItemAt(0)
                o.put("text", item.coerceToText(context)?.toString() ?: "")
                o.put("html", item.htmlText ?: "")
            }
            o
        }
        else -> throw IllegalArgumentException("Método desconhecido: $method")
        }
    }
}
