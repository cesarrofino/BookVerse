package com.bookverse.app.export

import android.util.Base64
import com.bookverse.app.data.MediaManager
import org.json.JSONArray
import org.json.JSONObject

/** Secção do livro (página de rosto, capítulo, etc.) recebida do editor. */
data class Section(
    val id: String,
    val type: String,
    val title: String,
    val html: String,
    val inToc: Boolean
)

data class TocEntry(val title: String, val sectionId: String, val level: Int)

/** Pedido de exportação construído a partir do JSON enviado pelo JavaScript. */
class ExportRequest(val json: JSONObject) {
    val format: String = json.optString("format")
    val bookId: String = json.optString("bookId")
    val title: String = json.optString("title").ifBlank { "Livro" }
    val subtitle: String = json.optString("subtitle")
    val author: String = json.optString("author")
    val language: String = json.optString("language", "pt").ifBlank { "pt" }
    val publisher: String = json.optString("publisher")
    val year: String = json.optString("year")
    val copyright: String = json.optString("copyright")
    val isbn: String = json.optString("isbn")
    val description: String = json.optString("description")
    val fontFamily: String = json.optString("fontFamily", "serif")
    val fontSizePt: Double = json.optDouble("fontSizePt", 12.0)
    val lineHeight: Double = json.optDouble("lineHeight", 1.5)
    val pageWmm: Double = json.optDouble("pageWmm", 148.0)
    val pageHmm: Double = json.optDouble("pageHmm", 210.0)
    val marginTopMm: Double = json.optDouble("marginTop", 20.0)
    val marginBottomMm: Double = json.optDouble("marginBottom", 20.0)
    val marginInnerMm: Double = json.optDouble("marginInner", 20.0)
    val marginOuterMm: Double = json.optDouble("marginOuter", 20.0)
    val landscape: Boolean = json.optBoolean("landscape", false)
    val imageQuality: String = json.optString("imageQuality", "high")
    val includeBackCover: Boolean = json.optBoolean("includeBackCover", true)
    val coverFront: String = json.optString("coverFront")     // data URL PNG
    val coverBack: String = json.optString("coverBack")       // data URL PNG
    val pagesHtml: String = json.optString("pagesHtml")       // documento paginado (só PDF)
    val pageCount: Int = json.optInt("pageCount", 0)

    val sections: List<Section> = json.optJSONArray("sections").toSections()
    val toc: List<TocEntry> = json.optJSONArray("toc").toToc()

    private fun JSONArray?.toSections(): List<Section> {
        if (this == null) return emptyList()
        return (0 until length()).map {
            val o = getJSONObject(it)
            Section(o.optString("id", "s$it"), o.optString("type"), o.optString("title"),
                o.optString("html"), o.optBoolean("inToc", false))
        }
    }

    private fun JSONArray?.toToc(): List<TocEntry> {
        if (this == null) return emptyList()
        return (0 until length()).map {
            val o = getJSONObject(it)
            TocEntry(o.optString("title"), o.optString("sectionId"), o.optInt("level", 1))
        }
    }

    /** Nome de ficheiro seguro derivado do título. */
    fun safeBaseName(): String {
        val s = title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().replace(Regex("\\s+"), "_")
        return s.ifEmpty { "livro" }.take(60)
    }
}

/** Resultado de uma exportação. */
data class ExportResult(val path: String, val fileName: String, val mime: String, val sizeBytes: Long)

object Mimes {
    const val PDF = "application/pdf"
    const val EPUB = "application/epub+zip"
    const val DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val TXT = "text/plain"
    const val PNG = "image/png"

    fun forFormat(format: String) = when (format) {
        "pdf" -> PDF; "epub" -> EPUB; "docx" -> DOCX; "txt" -> TXT; "png" -> PNG
        else -> "application/octet-stream"
    }
}

/** Bytes de uma imagem referenciada no HTML (ficheiro local ou data URL). */
class ImageBytes(val bytes: ByteArray, val mime: String, val ext: String)

object ImageResolver {
    fun resolve(src: String, media: MediaManager?): ImageBytes? {
        if (src.startsWith("data:image/")) {
            val comma = src.indexOf(',')
            if (comma < 0) return null
            val mime = src.substring(5, src.indexOf(';').takeIf { it > 0 } ?: comma)
            val bytes = try { Base64.decode(src.substring(comma + 1), Base64.DEFAULT) } catch (e: Exception) { return null }
            return ImageBytes(bytes, mime, extFor(mime))
        }
        val f = media?.fileFromUrl(src) ?: return null
        val mime = when (f.extension.lowercase()) { "png" -> "image/png"; "gif" -> "image/gif"; "webp" -> "image/webp"; else -> "image/jpeg" }
        return ImageBytes(f.readBytes(), mime, extFor(mime))
    }

    fun extFor(mime: String) = when (mime) { "image/png" -> "png"; "image/gif" -> "gif"; "image/webp" -> "webp"; else -> "jpg" }

    fun decodeDataUrl(dataUrl: String): ImageBytes? =
        if (dataUrl.isEmpty()) null else resolve(dataUrl, null)
}
