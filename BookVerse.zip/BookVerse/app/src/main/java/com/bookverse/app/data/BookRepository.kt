package com.bookverse.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Único ponto de acesso aos livros. Escreve sempre primeiro na base de dados local;
 * a sincronização na nuvem é feita à parte e nunca elimina dados locais válidos.
 */
class BookRepository(context: Context) {
    private val appContext = context.applicationContext
    private val db = AppDatabase.get(appContext)
    private val books = db.books()
    private val versions = db.versions()
    val media = MediaManager(appContext)

    /** uid atual ("" se não houver sessão). Definido pela camada de autenticação. */
    @Volatile var currentUid: String = ""

    private fun pendingOr(local: Boolean) = if (currentUid.isEmpty()) SyncState.LOCAL_ONLY else SyncState.PENDING

    suspend fun list(): JSONArray {
        val arr = JSONArray()
        for (b in books.summaries(currentUid)) {
            arr.put(JSONObject().apply {
                put("id", b.id); put("title", b.title); put("subtitle", b.subtitle); put("author", b.author)
                put("category", b.category); put("status", b.status); put("favorite", b.favorite)
                put("archived", b.archived); put("exported", b.exported); put("progress", b.progress)
                put("wordCount", b.wordCount); put("createdAt", b.createdAt); put("updatedAt", b.updatedAt)
                put("syncState", b.syncState)
                put("coverUrl", if (b.coverPath.isNotEmpty()) "${MediaManager.HOST}/media/${b.id}/${b.coverPath}?v=${b.updatedAt}" else "")
            })
        }
        return arr
    }

    suspend fun get(id: String): JSONObject? {
        val b = books.get(id) ?: return null
        if (b.deleted) return null
        return toJson(b, includeDoc = true)
    }

    private fun toJson(b: BookEntity, includeDoc: Boolean): JSONObject = JSONObject().apply {
        put("id", b.id); put("title", b.title); put("subtitle", b.subtitle); put("author", b.author)
        put("description", b.description); put("category", b.category); put("language", b.language)
        put("publisher", b.publisher); put("year", b.year); put("copyright", b.copyright); put("isbn", b.isbn)
        put("status", b.status); put("favorite", b.favorite); put("archived", b.archived)
        put("exported", b.exported); put("progress", b.progress); put("wordCount", b.wordCount)
        put("createdAt", b.createdAt); put("updatedAt", b.updatedAt); put("syncState", b.syncState)
        put("coverUrl", if (b.coverPath.isNotEmpty()) "${MediaManager.HOST}/media/${b.id}/${b.coverPath}?v=${b.updatedAt}" else "")
        if (includeDoc) put("doc", runCatching { JSONObject(b.docJson) }.getOrDefault(JSONObject()))
    }

    /**
     * Cria ou atualiza um livro. [json] contém metadados + "doc". Devolve o livro gravado.
     * Guarda uma versão de recuperação no máximo a cada 10 minutos.
     */
    suspend fun save(json: JSONObject): JSONObject {
        val now = System.currentTimeMillis()
        val id = json.optString("id").ifEmpty { UUID.randomUUID().toString() }
        val old = books.get(id)
        val doc = json.optJSONObject("doc")?.toString() ?: old?.docJson ?: "{}"
        val entity = BookEntity(
            id = id,
            ownerUid = old?.ownerUid ?: currentUid,
            title = json.optString("title", old?.title ?: "Sem título").ifBlank { "Sem título" },
            subtitle = json.optString("subtitle", old?.subtitle ?: ""),
            author = json.optString("author", old?.author ?: ""),
            description = json.optString("description", old?.description ?: ""),
            category = json.optString("category", old?.category ?: "Outros"),
            language = json.optString("language", old?.language ?: "pt"),
            publisher = json.optString("publisher", old?.publisher ?: ""),
            year = json.optString("year", old?.year ?: ""),
            copyright = json.optString("copyright", old?.copyright ?: ""),
            isbn = json.optString("isbn", old?.isbn ?: ""),
            status = json.optString("status", old?.status ?: "draft"),
            favorite = json.optBoolean("favorite", old?.favorite ?: false),
            archived = json.optBoolean("archived", old?.archived ?: false),
            exported = old?.exported ?: false,
            progress = json.optInt("progress", old?.progress ?: 0).coerceIn(0, 100),
            wordCount = json.optInt("wordCount", old?.wordCount ?: 0),
            createdAt = old?.createdAt ?: json.optLong("createdAt", now),
            updatedAt = now,
            rev = (old?.rev ?: 0) + 1,
            syncedRev = old?.syncedRev ?: 0,
            syncState = pendingOr(true),
            syncError = "",
            deleted = false,
            coverPath = old?.coverPath ?: "",
            docJson = doc
        )
        books.upsert(entity)

        // versão de recuperação
        val last = versions.lastCreatedAt(id) ?: 0L
        if (now - last > 10 * 60 * 1000L && entity.wordCount > 0) {
            versions.insert(BookVersionEntity(bookId = id, createdAt = now, label = "Gravação automática",
                title = entity.title, wordCount = entity.wordCount, docJson = doc))
            versions.prune(id, 20)
        }
        return toJson(entity, includeDoc = false)
    }

    suspend fun setCover(id: String, fileName: String) {
        books.setCoverPath(id, fileName)
    }

    suspend fun delete(id: String) {
        val b = books.get(id) ?: return
        if (b.ownerUid.isEmpty() || currentUid.isEmpty()) {
            books.hardDelete(id)
            media.deleteBook(id)
        } else {
            // mantém marcador para que a eliminação seja propagada à nuvem
            books.markDeleted(id, System.currentTimeMillis())
        }
    }

    suspend fun duplicate(id: String): JSONObject? {
        val src = books.get(id) ?: return null
        val newId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        // copia as imagens e reescreve os URLs no documento
        val srcDir = media.bookDir(id)
        val dstDir = media.bookDir(newId)
        srcDir.listFiles()?.forEach { it.copyTo(java.io.File(dstDir, it.name), overwrite = true) }
        val newDoc = src.docJson.replace("/media/$id/", "/media/$newId/")
        val copy = src.copy(
            id = newId, ownerUid = currentUid, title = src.title + " (cópia)", favorite = false,
            exported = false, createdAt = now, updatedAt = now, rev = 1, syncedRev = 0,
            syncState = pendingOr(true), syncError = "", deleted = false, docJson = newDoc
        )
        books.upsert(copy)
        db.media().forBook(id).forEach { db.media().upsert(it.copy(bookId = newId, uploaded = false)) }
        return toJson(copy, includeDoc = false)
    }

    suspend fun setFlag(id: String, field: String, value: String) {
        val now = System.currentTimeMillis()
        when (field) {
            "favorite" -> books.setFavorite(id, value == "true", now)
            "archived" -> books.setArchived(id, value == "true", now)
            "status" -> books.setStatus(id, value, now)
        }
    }

    suspend fun rename(id: String, title: String) {
        val b = books.get(id) ?: return
        books.upsert(b.copy(title = title.ifBlank { b.title }, updatedAt = System.currentTimeMillis(),
            rev = b.rev + 1, syncState = pendingOr(true)))
    }

    suspend fun markExported(id: String) = books.markExported(id)

    suspend fun listVersions(bookId: String): JSONArray {
        val arr = JSONArray()
        for (v in versions.list(bookId)) arr.put(JSONObject().apply {
            put("vid", v.vid); put("createdAt", v.createdAt); put("label", v.label)
            put("title", v.title); put("wordCount", v.wordCount)
        })
        return arr
    }

    /** Restaura uma versão: antes guarda o estado atual como nova versão (nada se perde). */
    suspend fun restoreVersion(vid: Long): JSONObject? {
        val v = versions.get(vid) ?: return null
        val cur = books.get(v.bookId) ?: return null
        val now = System.currentTimeMillis()
        versions.insert(BookVersionEntity(bookId = cur.id, createdAt = now, label = "Antes de restaurar",
            title = cur.title, wordCount = cur.wordCount, docJson = cur.docJson))
        books.upsert(cur.copy(docJson = v.docJson, wordCount = v.wordCount, updatedAt = now + 1,
            rev = cur.rev + 1, syncState = pendingOr(true)))
        return get(cur.id)
    }

    suspend fun addVersionSnapshot(bookId: String, label: String) {
        val b = books.get(bookId) ?: return
        versions.insert(BookVersionEntity(bookId = b.id, createdAt = System.currentTimeMillis(), label = label,
            title = b.title, wordCount = b.wordCount, docJson = b.docJson))
        versions.prune(bookId, 20)
    }

    suspend fun claimLocalBooks(uid: String) = books.claimLocal(uid)

    suspend fun mediaTotalBytes(): Long = media.totalBytes()
    suspend fun bookCount(): Int = books.summaries(currentUid).size

    suspend fun raw(id: String): BookEntity? = books.get(id)
    suspend fun putRaw(b: BookEntity) = books.upsert(b)
    suspend fun pending(uid: String) = books.pendingFor(uid)
    suspend fun setSyncResult(id: String, state: String, err: String, syncedRev: Long) =
        books.setSyncResult(id, state, err, syncedRev)
    suspend fun pendingCount() = books.pendingCount(currentUid)
    suspend fun hardDelete(id: String) { books.hardDelete(id); media.deleteBook(id) }
    suspend fun allForBackup() = books.allForBackup()
    fun mediaDao() = db.media()
}
