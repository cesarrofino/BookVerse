package com.bookverse.app.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.print.PdfPrint
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import com.bookverse.app.data.MediaManager
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Exporta PDF imprimindo, sem diálogo, o documento paginado produzido pelo motor de paginação do editor
 * (as mesmas páginas da pré-visualização). Texto permanece pesquisável e as fontes usadas são incorporadas
 * pelo motor de impressão do Android.
 */
class PdfExporter(private val context: Context, private val media: MediaManager) {

    private val main = Handler(Looper.getMainLooper())

    /** Deve ser chamado de qualquer thread; o callback é invocado na thread principal. */
    fun export(req: ExportRequest, out: File, onDone: (Throwable?) -> Unit) {
        main.post {
            try {
                run(req, out, onDone)
            } catch (e: Throwable) {
                onDone(e)
            }
        }
    }

    private fun run(req: ExportRequest, out: File, onDone: (Throwable?) -> Unit) {
        val wv = WebView(context)
        var finished = false
        fun finish(t: Throwable?) {
            if (finished) return
            finished = true
            main.post { try { wv.destroy() } catch (_: Exception) {}; onDone(t) }
        }

        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/media/", WebViewAssetLoader.InternalStoragePathHandler(context, media.root))
            .build()

        wv.settings.apply {
            javaScriptEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            loadWithOverviewMode = false
            useWideViewPort = false
        }
        // O tamanho real da página (em px CSS a 96dpi) tem de coincidir com o papel para evitar redimensionamento.
        val pwMm = if (req.landscape) req.pageHmm else req.pageWmm
        val phMm = if (req.landscape) req.pageWmm else req.pageHmm
        val widthMils = (pwMm / 25.4 * 1000).toInt()
        val heightMils = (phMm / 25.4 * 1000).toInt()

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val path = request.url.path ?: ""
                if (req.imageQuality != "high" && path.startsWith("/media/")) {
                    val f = media.fileFromUrl(request.url.toString().substringBefore('?'))
                    if (f != null) downscaled(f, req.imageQuality)?.let { return it }
                }
                return loader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                // pequeno atraso para o layout terminar (imagens e fontes)
                main.postDelayed({
                    try {
                        val adapter = view.createPrintDocumentAdapter(req.safeBaseName())
                        PdfPrint(widthMils, heightMils).write(adapter, out) { err -> finish(err) }
                    } catch (e: Throwable) {
                        finish(e)
                    }
                }, 600)
            }
        }
        // largura/altura da viewport iguais à página para que o conteúdo seja impresso a 100%
        wv.layout(0, 0, (pwMm / 25.4 * 96).toInt(), (phMm / 25.4 * 96).toInt())

        val html = buildDocument(req, pwMm, phMm)
        wv.loadDataWithBaseURL("https://appassets.androidplatform.net/", html, "text/html", "UTF-8", null)
    }

    /** Reduz a resolução das imagens conforme a qualidade escolhida (baixa/média) para ficheiros menores. */
    private fun downscaled(f: File, quality: String): WebResourceResponse? {
        return try {
            val maxSide = if (quality == "low") 900 else 1500
            val jpegQ = if (quality == "low") 65 else 80
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            if (bounds.outWidth <= 0) return null
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= maxSide || bounds.outHeight / (sample * 2) >= maxSide) sample *= 2
            var bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
            val longest = maxOf(bmp.width, bmp.height)
            if (longest > maxSide) {
                val k = maxSide.toFloat() / longest
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, jpegQ, out)
            bmp.recycle()
            WebResourceResponse("image/jpeg", null, ByteArrayInputStream(out.toByteArray()))
        } catch (e: Exception) {
            null
        }
    }

    private fun buildDocument(req: ExportRequest, pwMm: Double, phMm: Double): String {
        val cover = req.coverFront
        val back = if (req.includeBackCover) req.coverBack else ""
        val sb = StringBuilder()
        sb.append("<!doctype html><html><head><meta charset=\"utf-8\"><style>")
        sb.append("@page{size:${pwMm}mm ${phMm}mm;margin:0}")
        sb.append("html,body{margin:0;padding:0;background:#fff}")
        sb.append(".bv-page{position:relative;width:${pwMm}mm;height:${phMm}mm;overflow:hidden;page-break-after:always;break-after:page;box-sizing:border-box;background:#fff}")
        sb.append(".bv-page:last-child{page-break-after:auto;break-after:auto}")
        sb.append(".bv-cover{width:${pwMm}mm;height:${phMm}mm;display:block;object-fit:cover}")
        sb.append(req.json.optString("pagesCss"))
        sb.append("</style></head><body>")
        if (cover.isNotEmpty()) sb.append("<div class=\"bv-page\"><img class=\"bv-cover\" src=\"$cover\"></div>")
        sb.append(req.pagesHtml)
        if (back.isNotEmpty()) sb.append("<div class=\"bv-page\"><img class=\"bv-cover\" src=\"$back\"></div>")
        sb.append("</body></html>")
        return sb.toString()
    }
}
