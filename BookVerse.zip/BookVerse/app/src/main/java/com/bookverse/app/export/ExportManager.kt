package com.bookverse.app.export

import android.content.Context
import com.bookverse.app.data.BookRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Coordena a exportação para PDF, EPUB, DOCX e TXT. Tudo offline; ficheiros em filesDir/exports. */
class ExportManager(private val context: Context, private val repo: BookRepository) {

    val exportsDir: File get() = File(context.filesDir, "exports").also { it.mkdirs() }

    suspend fun export(req: ExportRequest): ExportResult {
        val ext = when (req.format) {
            "pdf", "epub", "docx", "txt" -> req.format
            else -> throw IllegalArgumentException("Formato não suportado: ${req.format}")
        }
        val out = File(exportsDir, "${req.safeBaseName()}.$ext")
        if (out.exists()) out.delete()

        when (req.format) {
            "txt" -> withContext(Dispatchers.IO) { TxtExporter.export(req, out) }
            "epub" -> withContext(Dispatchers.IO) { EpubExporter(repo.media).export(req, out) }
            "docx" -> withContext(Dispatchers.IO) { DocxExporter(repo.media).export(req, out) }
            "pdf" -> suspendCancellableCoroutine<Unit> { cont ->
                PdfExporter(context, repo.media).export(req, out) { err ->
                    if (err == null) cont.resume(Unit) else cont.resumeWithException(err)
                }
            }
        }
        if (!out.exists() || out.length() == 0L) throw IllegalStateException("O ficheiro exportado está vazio")
        if (req.bookId.isNotEmpty()) repo.markExported(req.bookId)
        return ExportResult(out.absolutePath, out.name, Mimes.forFormat(req.format), out.length())
    }

    /** Guarda uma imagem (capa) em exports/ para partilha. */
    suspend fun saveImage(bookId: String, dataUrl: String, baseName: String): ExportResult = withContext(Dispatchers.IO) {
        val ib = ImageResolver.decodeDataUrl(dataUrl) ?: throw IllegalArgumentException("Imagem inválida")
        val safe = baseName.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().replace(Regex("\\s+"), "_").ifEmpty { "capa" }.take(60)
        val out = File(exportsDir, "$safe.png")
        out.writeBytes(ib.bytes)
        ExportResult(out.absolutePath, out.name, Mimes.PNG, out.length())
    }

    fun totalBytes(): Long = exportsDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun clear() { exportsDir.listFiles()?.forEach { it.delete() } }

    /** Só permite aceder a ficheiros dentro de exports/ (impede path traversal vindo do JS). */
    fun resolveExport(path: String): File? {
        val f = File(path).canonicalFile
        return if (f.parentFile?.canonicalPath == exportsDir.canonicalPath && f.exists()) f else null
    }
}
