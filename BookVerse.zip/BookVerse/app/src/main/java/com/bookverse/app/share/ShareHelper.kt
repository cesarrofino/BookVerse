package com.bookverse.app.share

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.bookverse.app.R
import java.io.File

/**
 * Partilha real através do Android Sharesheet. O ficheiro já existe (foi exportado antes) e é exposto
 * por FileProvider com permissão temporária de leitura; nunca se partilham caminhos diretos.
 */
object ShareHelper {

    fun uriFor(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    fun share(context: Context, file: File, mime: String, subject: String): Boolean {
        val uri = uriFor(context, file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TITLE, file.name)
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, context.getString(R.string.share_title)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try { context.startActivity(chooser); true } catch (e: ActivityNotFoundException) { false }
    }

    fun open(context: Context, file: File, mime: String): Boolean {
        val uri = uriFor(context, file)
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(view, context.getString(R.string.open_with_title)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try { context.startActivity(chooser); true } catch (e: ActivityNotFoundException) { false }
    }

    /** Copia o ficheiro exportado para o destino escolhido pelo utilizador (Storage Access Framework). */
    fun copyTo(context: Context, source: File, target: Uri) {
        context.contentResolver.openOutputStream(target, "wt")?.use { out ->
            source.inputStream().use { it.copyTo(out) }
        } ?: throw IllegalStateException("Não foi possível escrever no destino")
    }
}
