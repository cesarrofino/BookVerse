package com.bookverse.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

/**
 * Gere as imagens dos livros em filesDir/media/{bookId}/{ficheiro}.
 * As imagens são servidas à WebView por https://appassets.androidplatform.net/media/{bookId}/{ficheiro}.
 */
class MediaManager(private val context: Context) {

    companion object {
        const val HOST = "https://appassets.androidplatform.net"
        const val MAX_INPUT_BYTES = 40L * 1024 * 1024   // limite de validação de ficheiros importados
        private val SAFE_NAME = Regex("^[A-Za-z0-9._-]{1,120}$")
        private val SAFE_ID = Regex("^[A-Za-z0-9-]{1,64}$")
    }

    val root: File get() = File(context.filesDir, "media").also { it.mkdirs() }

    fun bookDir(bookId: String): File {
        require(SAFE_ID.matches(bookId)) { "Identificador inválido" }
        return File(root, bookId).also { it.mkdirs() }
    }

    fun file(bookId: String, name: String): File {
        require(SAFE_NAME.matches(name)) { "Nome de ficheiro inválido" }
        return File(bookDir(bookId), name)
    }

    fun urlFor(bookId: String, name: String) = "$HOST/media/$bookId/$name"

    /** Converte "https://appassets.../media/{book}/{file}" em ficheiro local, ou null. */
    fun fileFromUrl(url: String): File? {
        val prefix = "$HOST/media/"
        if (!url.startsWith(prefix)) return null
        val parts = url.removePrefix(prefix).substringBefore('?').split('/')
        if (parts.size != 2) return null
        return try {
            file(parts[0], parts[1]).takeIf { it.exists() }
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    /**
     * Importa uma imagem (galeria/câmara/SAF): valida que é mesmo uma imagem decodificável,
     * limita o tamanho e reduz a resolução conforme a qualidade escolhida.
     * @return nome do ficheiro guardado.
     */
    fun importImage(bookId: String, uri: Uri, quality: String = "high"): ImportedImage {
        val resolver = context.contentResolver
        val size = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        if (size > MAX_INPUT_BYTES) throw IllegalArgumentException("Imagem demasiado grande (máx. 40 MB)")

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: throw IllegalArgumentException("Não foi possível abrir o ficheiro")
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0)
            throw IllegalArgumentException("O ficheiro selecionado não é uma imagem válida")

        val maxSide = when (quality) { "low" -> 1000; "medium" -> 1600; else -> 2400 }
        var sample = 1
        while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalArgumentException("Falha ao decodificar a imagem")

        val longest = maxOf(bmp.width, bmp.height)
        if (longest > maxSide) {
            val s = maxSide.toFloat() / longest
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt().coerceAtLeast(1), (bmp.height * s).toInt().coerceAtLeast(1), true)
        }
        val name = "img_" + UUID.randomUUID().toString().substring(0, 12) + ".jpg"
        val q = when (quality) { "low" -> 70; "medium" -> 82; else -> 92 }
        file(bookId, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, q, it) }
        val w = bmp.width
        val h = bmp.height
        bmp.recycle()
        return ImportedImage(name, urlFor(bookId, name), w, h, file(bookId, name).length())
    }

    /** Guarda um PNG/JPEG recebido como data URL (ex.: capa renderizada). */
    fun saveDataUrl(bookId: String, dataUrl: String, name: String): ImportedImage {
        val comma = dataUrl.indexOf(',')
        require(dataUrl.startsWith("data:image/") && comma > 0) { "Imagem inválida" }
        val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        require(bounds.outWidth > 0) { "Imagem inválida" }
        val f = file(bookId, name)
        f.writeBytes(bytes)
        return ImportedImage(name, urlFor(bookId, name), bounds.outWidth, bounds.outHeight, f.length())
    }

    fun readBytes(bookId: String, name: String): ByteArray? =
        try { file(bookId, name).takeIf { it.exists() }?.readBytes() } catch (e: Exception) { null }

    fun toDataUrl(f: File): String {
        val mime = if (f.name.endsWith(".png")) "image/png" else "image/jpeg"
        val out = ByteArrayOutputStream()
        out.write(f.readBytes())
        return "data:$mime;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    fun deleteBook(bookId: String) {
        if (SAFE_ID.matches(bookId)) File(root, bookId).deleteRecursively()
    }

    fun totalBytes(): Long = root.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    data class ImportedImage(val fileName: String, val url: String, val width: Int, val height: Int, val size: Long)
}
