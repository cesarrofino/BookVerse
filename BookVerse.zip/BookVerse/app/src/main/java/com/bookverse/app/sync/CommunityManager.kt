package com.bookverse.app.sync

import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

/**
 * Comunidade: livros publicados, visíveis a todos os utilizadores com sessão, e reações.
 *   published/{livro}                 metadados, capa pequena e contadores de reações
 *   published/{livro}/parts/{n}       texto (HTML) dividido em partes
 *   published/{livro}/reactions/{uid} reação de cada utilizador (uma por livro)
 */
class CommunityManager(private val auth: AuthManager) {

    companion object {
        val TYPES = listOf("like", "love", "wow", "clap", "inspire")
        private const val TIMEOUT_MS = 25_000L
        private const val PART_CHARS = 350_000
    }

    private val fs: FirebaseFirestore
        get() {
            if (!auth.isConfigured) throw AuthManager.AuthException("O Firebase ainda não está configurado (ver README).")
            return FirebaseFirestore.getInstance(FirebaseApp.getInstance())
        }

    private fun uid(): String {
        val u = auth.currentUser()?.uid ?: ""
        if (u.isEmpty()) throw AuthManager.AuthException("Entre com a sua conta Google para usar a comunidade.")
        return u
    }

    private fun countsOf(d: Map<String, Any?>?): JSONObject {
        val c = JSONObject()
        @Suppress("UNCHECKED_CAST")
        val m = d?.get("counts") as? Map<String, Any?>
        for (t in TYPES) c.put(t, ((m?.get(t) as? Number)?.toLong() ?: 0L).coerceAtLeast(0))
        return c
    }

    private fun metaOf(id: String, d: Map<String, Any?>, withCover: Boolean = true): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        for (k in listOf("ownerUid", "ownerName", "title", "subtitle", "author", "category", "language", "description"))
            o.put(k, d[k] as? String ?: "")
        o.put("wordCount", (d["wordCount"] as? Number)?.toLong() ?: 0L)
        o.put("partCount", (d["partCount"] as? Number)?.toLong() ?: 0L)
        o.put("commentCount", ((d["commentCount"] as? Number)?.toLong() ?: 0L).coerceAtLeast(0))
        o.put("publishedAt", (d["publishedAt"] as? com.google.firebase.Timestamp)?.toDate()?.time ?: 0L)
        if (withCover) o.put("cover", d["cover"] as? String ?: "")
        o.put("counts", countsOf(d))
        o.put("mine", "")
        return o
    }

    suspend fun list(limit: Int): JSONArray = withTimeout(TIMEOUT_MS) {
        uid()
        val snap = fs.collection("published").orderBy("publishedAt", Query.Direction.DESCENDING).limit(limit.toLong()).get().await()
        val arr = JSONArray()
        for (d in snap.documents) arr.put(metaOf(d.id, d.data ?: emptyMap()))
        arr
    }

    suspend fun get(id: String): JSONObject = withTimeout(TIMEOUT_MS) {
        val me = uid()
        val ref = fs.collection("published").document(id)
        val doc = ref.get().await()
        if (!doc.exists()) throw AuthManager.AuthException("Este livro já não está publicado.")
        val meta = metaOf(id, doc.data ?: emptyMap())
        val parts = ref.collection("parts").orderBy("n").get().await()
        val arr = JSONArray()
        for (p in parts.documents) arr.put(JSONObject().put("title", p.getString("title") ?: "").put("html", p.getString("html") ?: ""))
        meta.put("parts", arr)
        val mine = ref.collection("reactions").document(me).get().await()
        meta.put("mine", mine.getString("type") ?: "")
        meta
    }

    /** Ids dos livros que o utilizador já publicou. */
    suspend fun mine(): JSONArray = withTimeout(TIMEOUT_MS) {
        val me = uid()
        val snap = fs.collection("published").whereEqualTo("ownerUid", me).get().await()
        val arr = JSONArray()
        for (d in snap.documents) arr.put(d.id)
        arr
    }

    /** Publica (ou atualiza) um livro. a: id, title, subtitle, author, category, language, description, cover, wordCount, sections[{title,html}]. */
    suspend fun publish(a: JSONObject): JSONObject = withTimeout(60_000L) {
        val me = uid()
        val db = fs
        val id = a.getString("id")
        val ref = db.collection("published").document(id)
        val existing = ref.get().await()
        if (existing.exists() && existing.getString("ownerUid") != me) throw AuthManager.AuthException("Este livro pertence a outro utilizador.")

        // partes de texto (cada documento do Firestore tem limite de 1 MB)
        val parts = ArrayList<Pair<String, String>>()
        val secs = a.getJSONArray("sections")
        for (i in 0 until secs.length()) {
            val s = secs.getJSONObject(i)
            val title = s.optString("title")
            var html = s.optString("html")
            if (html.length <= PART_CHARS) parts.add(title to html)
            else { var k = 0; while (html.isNotEmpty()) { val cut = minOf(PART_CHARS, html.length); parts.add((if (k == 0) title else "") to html.substring(0, cut)); html = html.substring(cut); k++ } }
        }
        if (parts.isEmpty()) throw AuthManager.AuthException("O livro está vazio.")

        val user = auth.currentUser()
        val counts = if (existing.exists()) (existing.get("counts") as? Map<*, *>) else null
        val meta = hashMapOf<String, Any?>(
            "ownerUid" to me, "ownerName" to (user?.displayName ?: a.optString("author")),
            "title" to a.getString("title"), "subtitle" to a.optString("subtitle"), "author" to a.optString("author"),
            "category" to a.optString("category"), "language" to a.optString("language"), "description" to a.optString("description").take(1500),
            "cover" to a.optString("cover"), "wordCount" to a.optLong("wordCount"), "partCount" to parts.size,
            "publishedAt" to (if (existing.exists()) existing.get("publishedAt") else FieldValue.serverTimestamp()),
            "updatedAt" to FieldValue.serverTimestamp(),
            "commentCount" to (existing.get("commentCount") ?: 0L),
            "counts" to (counts ?: TYPES.associateWith { 0L })
        )
        ref.set(meta).await()

        // substitui as partes antigas
        val old = ref.collection("parts").get().await()
        old.documents.chunked(400).forEach { chunk ->
            val b = db.batch(); chunk.forEach { b.delete(it.reference) }; b.commit().await()
        }
        parts.withIndex().toList().chunked(20).forEach { chunk ->
            val b = db.batch()
            for ((i, p) in chunk) b.set(ref.collection("parts").document("%05d".format(i)), hashMapOf("n" to i, "title" to p.first, "html" to p.second))
            b.commit().await()
        }
        JSONObject().put("id", id).put("parts", parts.size)
    }

    suspend fun unpublish(id: String) = withTimeout(TIMEOUT_MS) {
        val me = uid()
        val ref = fs.collection("published").document(id)
        val d = ref.get().await()
        if (!d.exists()) return@withTimeout
        if (d.getString("ownerUid") != me) throw AuthManager.AuthException("Só o autor pode remover a publicação.")
        for (col in listOf("parts", "reactions", "comments")) {
            ref.collection(col).get().await().documents.chunked(400).forEach { chunk ->
                val b = fs.batch(); chunk.forEach { b.delete(it.reference) }; b.commit().await()
            }
        }
        ref.delete().await()
        clearImages(id)
        Unit
    }

    /** Reage a um livro; tocar na mesma reação outra vez remove-a. Devolve os contadores e a reação atual. */
    suspend fun react(id: String, type: String): JSONObject = withTimeout(TIMEOUT_MS) {
        val me = uid()
        if (type !in TYPES) throw AuthManager.AuthException("Reação inválida.")
        val db = fs
        val ref = db.collection("published").document(id)
        val rRef = ref.collection("reactions").document(me)
        val now = db.runTransaction { tr ->
            val prev = tr.get(rRef).getString("type") ?: ""
            if (!tr.get(ref).exists()) throw IllegalStateException("Este livro já não está publicado.")
            if (prev == type) {
                tr.delete(rRef)
                tr.update(ref, "counts.$type", FieldValue.increment(-1))
                ""
            } else {
                if (prev.isNotEmpty()) tr.update(ref, "counts.$prev", FieldValue.increment(-1))
                tr.set(rRef, hashMapOf("type" to type, "at" to FieldValue.serverTimestamp()))
                tr.update(ref, "counts.$type", FieldValue.increment(1))
                type
            }
        }.await()
        val d = ref.get().await()
        JSONObject().put("counts", countsOf(d.data)).put("mine", now)
    }

    /** Carrega uma imagem (JPEG em data URL) para o Storage e devolve o URL de descarga. */
    suspend fun uploadImage(bookId: String, name: String, dataUrl: String): String = withTimeout(60_000L) {
        val me = uid()
        val comma = dataUrl.indexOf(',')
        if (comma < 0) throw AuthManager.AuthException("Imagem inválida.")
        val bytes = android.util.Base64.decode(dataUrl.substring(comma + 1), android.util.Base64.DEFAULT)
        if (bytes.size > 2_800_000) throw AuthManager.AuthException("Uma das imagens é demasiado grande.")
        val safe = name.replace(Regex("[^A-Za-z0-9_.-]"), "_")
        val ref = FirebaseStorage.getInstance(FirebaseApp.getInstance()).reference.child("published/$me/$bookId/$safe")
        ref.putBytes(bytes, StorageMetadata.Builder().setContentType("image/jpeg").build()).await()
        ref.downloadUrl.await().toString()
    }

    /** Apaga as imagens publicadas de um livro (antes de republicar ou ao remover). */
    suspend fun clearImages(bookId: String) {
        try {
            val me = uid()
            val dir = FirebaseStorage.getInstance(FirebaseApp.getInstance()).reference.child("published/$me/$bookId")
            for (item in dir.listAll().await().items) { try { item.delete().await() } catch (_: Exception) {} }
        } catch (_: Exception) { /* sem imagens ou sem permissão: ignora */ }
    }

    suspend fun comments(id: String): JSONArray = withTimeout(TIMEOUT_MS) {
        uid()
        val snap = fs.collection("published").document(id).collection("comments").orderBy("at").limit(200).get().await()
        val arr = JSONArray()
        for (d in snap.documents) arr.put(commentJson(d.id, d.getString("uid") ?: "", d.getString("name") ?: "", d.getString("text") ?: "", d.getTimestamp("at")?.toDate()?.time ?: 0L))
        arr
    }

    private fun commentJson(id: String, uid: String, name: String, text: String, at: Long) =
        JSONObject().put("id", id).put("uid", uid).put("name", name).put("text", text).put("at", at)

    suspend fun comment(id: String, text: String): JSONObject = withTimeout(TIMEOUT_MS) {
        val me = uid()
        val t = text.trim()
        if (t.isEmpty()) throw AuthManager.AuthException("Escreva um comentário.")
        if (t.length > 1000) throw AuthManager.AuthException("O comentário é demasiado longo (máx. 1000 caracteres).")
        val db = fs
        val ref = db.collection("published").document(id)
        val cRef = ref.collection("comments").document()
        val u = auth.currentUser()
        val name = (u?.displayName?.takeIf { it.isNotBlank() } ?: u?.email?.substringBefore('@') ?: "Leitor")
        val b = db.batch()
        b.set(cRef, hashMapOf("uid" to me, "name" to name, "text" to t, "at" to FieldValue.serverTimestamp()))
        b.update(ref, "commentCount", FieldValue.increment(1))
        b.commit().await()
        commentJson(cRef.id, me, name, t, System.currentTimeMillis())
    }

    suspend fun deleteComment(id: String, commentId: String) = withTimeout(TIMEOUT_MS) {
        uid()
        val db = fs
        val ref = db.collection("published").document(id)
        val b = db.batch()
        b.delete(ref.collection("comments").document(commentId))
        b.update(ref, "commentCount", FieldValue.increment(-1))
        b.commit().await()
        Unit
    }
}
