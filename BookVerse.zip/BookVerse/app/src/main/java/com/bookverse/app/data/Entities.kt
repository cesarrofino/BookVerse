package com.bookverse.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Estados de sincronização de um livro. */
object SyncState {
    const val LOCAL_ONLY = "local"      // sem sessão iniciada ou nunca sincronizado
    const val PENDING = "pending"       // alterações locais por enviar
    const val SYNCED = "synced"
    const val ERROR = "error"
}

/**
 * Livro. Os metadados ficam em colunas (para pesquisa/ordenação rápida) e o
 * documento completo (capítulos, estrutura, capa, layout) fica em [docJson].
 */
@Entity(tableName = "books", indices = [Index("ownerUid"), Index("updatedAt")])
data class BookEntity(
    @PrimaryKey val id: String,
    val ownerUid: String = "",              // "" = utilizador local/anónimo
    val title: String,
    val subtitle: String = "",
    val author: String = "",
    val description: String = "",
    val category: String = "Outros",
    val language: String = "pt",
    val publisher: String = "",
    val year: String = "",
    val copyright: String = "",
    val isbn: String = "",
    val status: String = "draft",           // draft | completed | published
    val favorite: Boolean = false,
    val archived: Boolean = false,
    val exported: Boolean = false,
    val progress: Int = 0,                  // 0..100
    val wordCount: Int = 0,
    val createdAt: Long,
    val updatedAt: Long,
    val rev: Long = 1,                      // incrementa em cada gravação local
    val syncedRev: Long = 0,                // última rev confirmada na nuvem
    val syncState: String = SyncState.LOCAL_ONLY,
    val syncError: String = "",
    val deleted: Boolean = false,           // marcador para propagar eliminações
    val coverPath: String = "",             // PNG da capa frontal (relativo a filesDir/media)
    val docJson: String = "{}"
)

/** Instantâneo de uma versão anterior do livro (recuperação). */
@Entity(
    tableName = "book_versions",
    foreignKeys = [ForeignKey(
        entity = BookEntity::class,
        parentColumns = ["id"],
        childColumns = ["bookId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("bookId")]
)
data class BookVersionEntity(
    @PrimaryKey(autoGenerate = true) val vid: Long = 0,
    val bookId: String,
    val createdAt: Long,
    val label: String,
    val title: String,
    val wordCount: Int,
    val docJson: String
)

/** Ficheiro de media (imagem) pertencente a um livro. */
@Entity(
    tableName = "media",
    primaryKeys = ["bookId", "fileName"],
    foreignKeys = [ForeignKey(
        entity = BookEntity::class,
        parentColumns = ["id"],
        childColumns = ["bookId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("bookId")]
)
data class MediaEntity(
    val bookId: String,
    val fileName: String,
    val sizeBytes: Long,
    val uploaded: Boolean = false
)
