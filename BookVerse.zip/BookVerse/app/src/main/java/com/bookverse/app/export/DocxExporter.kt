package com.bookverse.app.export

import android.graphics.BitmapFactory
import com.bookverse.app.data.MediaManager
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Gera DOCX (Office Open XML) editável no Word: estilos de título, formatação em linha
 * (negrito, itálico, sublinhado, rasurado, cor, realce, tamanho, tipo de letra), alinhamento,
 * listas, tabelas, citações, imagens, quebras de página, capa, índice e rodapé com numeração.
 */
class DocxExporter(private val media: MediaManager) {

    private val EMU_PER_MM = 36000L
    private val rels = StringBuilder()
    private val imageFiles = LinkedHashMap<String, ByteArray>()
    private var relCounter = 10
    private var drawingId = 1
    private lateinit var req: ExportRequest

    private class Fmt(
        var bold: Boolean = false, var italic: Boolean = false, var underline: Boolean = false,
        var strike: Boolean = false, var color: String? = null, var highlight: String? = null,
        var sizeHalfPt: Int? = null, var font: String? = null, var sup: Boolean = false, var sub: Boolean = false,
        var link: String? = null
    ) {
        fun copy() = Fmt(bold, italic, underline, strike, color, highlight, sizeHalfPt, font, sup, sub, link)
    }

    private class Para(
        var style: String? = null, var align: String? = null, var indentLeftTw: Int = 0, var firstLineTw: Int = 0,
        var spaceAfterTw: Int? = null, var lineTw: Int? = null, var numId: Int? = null, var numLevel: Int = 0,
        var pageBreakBefore: Boolean = false, var keepNext: Boolean = false, var quote: Boolean = false
    )

    fun export(request: ExportRequest, out: File) {
        req = request
        val body = StringBuilder()
        var first = true

        // Capa
        val cover = ImageResolver.decodeDataUrl(req.coverFront)
        val pw = (req.pageWmm * 56.6929).toInt().let { if (req.landscape) (req.pageHmm * 56.6929).toInt() else it }
        val ph = (req.pageHmm * 56.6929).toInt().let { if (req.landscape) (req.pageWmm * 56.6929).toInt() else it }
        val marginL = (req.marginInnerMm * 56.6929).toInt()
        val marginR = (req.marginOuterMm * 56.6929).toInt()
        val marginT = (req.marginTopMm * 56.6929).toInt()
        val marginB = (req.marginBottomMm * 56.6929).toInt()

        if (cover != null) {
            val usableWmm = (if (req.landscape) req.pageHmm else req.pageWmm) - req.marginInnerMm - req.marginOuterMm
            val usableHmm = (if (req.landscape) req.pageWmm else req.pageHmm) - req.marginTopMm - req.marginBottomMm - 5
            body.append("<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr>")
            body.append(imageRun(cover, usableWmm, usableHmm, "Capa"))
            body.append("</w:p>")
            first = false
        }

        val tocLevelHeadings = HashMap<String, Int>()
        for (t in req.toc) tocLevelHeadings[t.sectionId] = t.level

        for (s in req.sections) {
            if (s.type == "cover" || s.type == "backcover") continue
            val breakBefore = !first
            first = false
            if (s.type == "toc") {
                body.append(tocBlock(s, breakBefore))
                continue
            }
            val centered = s.type == "title" || s.type == "dedication" || s.type == "copyright"
            val doc = Jsoup.parseBodyFragment(s.html)
            var pendingBreak = breakBefore
            val hasHeading = doc.select("h1,h2").isNotEmpty()
            if (!hasHeading && s.title.isNotBlank() && s.type in setOf("chapter", "preface", "intro", "conclusion", "acknowledgments", "references", "about")) {
                body.append(paragraph(Para(style = "Heading1", pageBreakBefore = pendingBreak, keepNext = true), listOf(run(s.title, Fmt()))))
                pendingBreak = false
            }
            val ctx = Ctx(pendingBreak, if (centered) "center" else null)
            blocks(doc.body(), ctx, body)
            if (ctx.pendingBreak && body.isEmpty()) body.append("<w:p/>")
        }

        if (req.includeBackCover) {
            ImageResolver.decodeDataUrl(req.coverBack)?.let {
                val uw = (if (req.landscape) req.pageHmm else req.pageWmm) - req.marginInnerMm - req.marginOuterMm
                val uh = (if (req.landscape) req.pageWmm else req.pageHmm) - req.marginTopMm - req.marginBottomMm - 5
                body.append("<w:p><w:pPr><w:pageBreakBefore/><w:jc w:val=\"center\"/></w:pPr>")
                body.append(imageRun(it, uw, uh, "Contracapa"))
                body.append("</w:p>")
            }
        }

        val orient = if (req.landscape) " w:orient=\"landscape\"" else ""
        body.append("<w:sectPr><w:footerReference w:type=\"default\" r:id=\"rIdFooter\"/>" +
            "<w:pgSz w:w=\"$pw\" w:h=\"$ph\"$orient/>" +
            "<w:pgMar w:top=\"$marginT\" w:right=\"$marginR\" w:bottom=\"$marginB\" w:left=\"$marginL\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>")

        val documentXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
            "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>$body</w:body></w:document>"

        ZipOutputStream(FileOutputStream(out)).use { zip ->
            fun put(name: String, data: ByteArray) { zip.putNextEntry(ZipEntry(name)); zip.write(data); zip.closeEntry() }
            put("[Content_Types].xml", contentTypes().toByteArray())
            put("_rels/.rels", ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
                "</Relationships>").toByteArray())
            put("docProps/core.xml", coreXml().toByteArray())
            put("word/document.xml", documentXml.toByteArray())
            put("word/styles.xml", stylesXml().toByteArray())
            put("word/numbering.xml", numberingXml().toByteArray())
            put("word/footer1.xml", footerXml().toByteArray())
            put("word/_rels/document.xml.rels", documentRels().toByteArray())
            for ((name, bytes) in imageFiles) put("word/media/$name", bytes)
        }
    }

    // ---------- blocos ----------

    private class Ctx(var pendingBreak: Boolean, val defaultAlign: String?)

    private fun blocks(parent: Element, ctx: Ctx, out: StringBuilder, listDepth: Int = 0, listKind: String? = null, quote: Boolean = false) {
        for (n in parent.childNodes()) {
            if (n is TextNode) {
                if (n.isBlank) continue
                out.append(paragraph(newPara(ctx, quote), inline(n, Fmt())))
                ctx.pendingBreak = false
                continue
            }
            if (n !is Element) continue
            when (val tag = n.tagName().lowercase()) {
                "script", "style" -> {}
                "h1", "h2", "h3", "h4", "h5", "h6" -> {
                    val lvl = tag[1].digitToInt().coerceAtMost(3)
                    val p = Para(style = "Heading$lvl", keepNext = true, pageBreakBefore = ctx.pendingBreak,
                        align = alignOf(n) ?: ctx.defaultAlign)
                    out.append(paragraph(p, inlineChildren(n, Fmt())))
                    ctx.pendingBreak = false
                }
                "p", "div", "figure", "figcaption", "section", "span" -> {
                    if (n.hasClass("pagebreak") || n.attr("style").contains("page-break-after") || n.attr("style").contains("break-after: page")) {
                        ctx.pendingBreak = true
                        continue
                    }
                    if (n.select("p,div,h1,h2,h3,ul,ol,table,blockquote").isNotEmpty() && tag != "p") {
                        blocks(n, ctx, out, listDepth, listKind, quote)
                        continue
                    }
                    val p = newPara(ctx, quote)
                    applyParaStyle(n, p)
                    val runs = inlineChildren(n, Fmt())
                    out.append(paragraph(p, runs.ifEmpty { listOf("") }))
                    ctx.pendingBreak = false
                }
                "blockquote" -> {
                    if (n.select("p,div").isNotEmpty()) blocks(n, ctx, out, listDepth, listKind, true)
                    else {
                        out.append(paragraph(newPara(ctx, true), inlineChildren(n, Fmt())))
                        ctx.pendingBreak = false
                    }
                }
                "hr" -> {
                    out.append("<w:p><w:pPr>${if (ctx.pendingBreak) "<w:pageBreakBefore/>" else ""}<w:pBdr><w:bottom w:val=\"single\" w:sz=\"6\" w:space=\"1\" w:color=\"999999\"/></w:pBdr><w:spacing w:before=\"120\" w:after=\"120\"/></w:pPr></w:p>")
                    ctx.pendingBreak = false
                }
                "ul", "ol" -> {
                    for (li in n.children().filter { it.tagName().equals("li", true) }) {
                        val p = newPara(ctx, quote)
                        p.numId = if (tag == "ol") 2 else 1
                        p.numLevel = listDepth.coerceAtMost(3)
                        val nested = li.children().filter { it.tagName().lowercase() in setOf("ul", "ol") }
                        val runs = mutableListOf<String>()
                        for (c in li.childNodes()) {
                            if (c is Element && c.tagName().lowercase() in setOf("ul", "ol")) continue
                            runs.addAll(inline(c, Fmt()))
                        }
                        out.append(paragraph(p, runs))
                        ctx.pendingBreak = false
                        for (sub in nested) {
                            val tmp = Element("div"); tmp.appendChild(sub.clone())
                            blocks(tmp, ctx, out, listDepth + 1, sub.tagName(), quote)
                        }
                    }
                }
                "table" -> { out.append(table(n)); out.append("<w:p/>"); ctx.pendingBreak = false }
                "img" -> {
                    val r = imageParagraph(n, ctx); if (r.isNotEmpty()) out.append(r); ctx.pendingBreak = false
                }
                else -> blocks(n, ctx, out, listDepth, listKind, quote)
            }
        }
    }

    private fun newPara(ctx: Ctx, quote: Boolean) = Para(
        style = if (quote) "Quote" else null, align = ctx.defaultAlign, pageBreakBefore = ctx.pendingBreak, quote = quote
    )

    private fun alignOf(e: Element): String? {
        val st = e.attr("style")
        val m = Regex("text-align\\s*:\\s*(left|right|center|justify)").find(st)
        return m?.groupValues?.get(1) ?: e.attr("align").takeIf { it.isNotEmpty() }
    }

    private fun applyParaStyle(e: Element, p: Para) {
        alignOf(e)?.let { p.align = it }
        val st = e.attr("style")
        Regex("margin-left\\s*:\\s*([0-9.]+)(px|em|pt|mm)").find(st)?.let { p.indentLeftTw = toTwips(it.groupValues[1].toDouble(), it.groupValues[2]) }
        Regex("text-indent\\s*:\\s*([0-9.]+)(px|em|pt|mm)").find(st)?.let { p.firstLineTw = toTwips(it.groupValues[1].toDouble(), it.groupValues[2]) }
        Regex("margin-bottom\\s*:\\s*([0-9.]+)(px|em|pt|mm)").find(st)?.let { p.spaceAfterTw = toTwips(it.groupValues[1].toDouble(), it.groupValues[2]) }
        Regex("line-height\\s*:\\s*([0-9.]+)\\s*(;|$)").find(st)?.let { p.lineTw = (it.groupValues[1].toDouble() * 240).toInt() }
    }

    private fun toTwips(v: Double, unit: String): Int = when (unit) {
        "px" -> (v * 15).toInt(); "pt" -> (v * 20).toInt(); "mm" -> (v * 56.6929).toInt()
        else -> (v * req.fontSizePt * 20).toInt()
    }

    // ---------- parágrafos e runs ----------

    private fun paragraph(p: Para, runs: List<String>): String {
        val sb = StringBuilder("<w:p><w:pPr>")
        p.style?.let { sb.append("<w:pStyle w:val=\"$it\"/>") }
        if (p.keepNext) sb.append("<w:keepNext/>")
        if (p.pageBreakBefore) sb.append("<w:pageBreakBefore/>")
        p.numId?.let { sb.append("<w:numPr><w:ilvl w:val=\"${p.numLevel}\"/><w:numId w:val=\"$it\"/></w:numPr>") }
        if (p.spaceAfterTw != null || p.lineTw != null) {
            sb.append("<w:spacing")
            p.spaceAfterTw?.let { sb.append(" w:after=\"$it\"") }
            p.lineTw?.let { sb.append(" w:line=\"$it\" w:lineRule=\"auto\"") }
            sb.append("/>")
        }
        if (p.indentLeftTw != 0 || p.firstLineTw != 0) {
            sb.append("<w:ind w:left=\"${p.indentLeftTw}\" w:firstLine=\"${p.firstLineTw}\"/>")
        }
        p.align?.let {
            val v = when (it) { "justify" -> "both"; "center" -> "center"; "right" -> "right"; else -> "left" }
            sb.append("<w:jc w:val=\"$v\"/>")
        }
        sb.append("</w:pPr>")
        for (r in runs) sb.append(r)
        sb.append("</w:p>")
        return sb.toString()
    }

    private fun inlineChildren(e: Element, f: Fmt): List<String> {
        val out = mutableListOf<String>()
        for (c in e.childNodes()) out.addAll(inline(c, f))
        return out
    }

    private fun inline(n: Node, f: Fmt): List<String> {
        if (n is TextNode) {
            val t = n.wholeText.replace(' ', ' ').replace(Regex("[\\r\\n\\t]+"), " ")
            return if (t.isEmpty()) emptyList() else listOf(run(t, f))
        }
        if (n !is Element) return emptyList()
        val tag = n.tagName().lowercase()
        if (tag == "br") return listOf("<w:r><w:br/></w:r>")
        if (tag == "img") {
            val ib = ImageResolver.resolve(n.attr("src"), media) ?: return emptyList()
            return listOf("<w:r>" + drawing(ib, 100.0, 100.0, n.attr("alt"), null) + "</w:r>")
        }
        val nf = f.copy()
        when (tag) {
            "b", "strong" -> nf.bold = true
            "i", "em" -> nf.italic = true
            "u" -> nf.underline = true
            "s", "strike", "del" -> nf.strike = true
            "sup" -> nf.sup = true
            "sub" -> nf.sub = true
            "a" -> nf.link = n.attr("href")
            "font" -> {
                n.attr("color").takeIf { it.isNotEmpty() }?.let { nf.color = hex(it) }
                n.attr("face").takeIf { it.isNotEmpty() }?.let { nf.font = wordFont(it.substringBefore(',').trim('"', '\'', ' ')) }
            }
        }
        val st = n.attr("style")
        if (st.isNotEmpty()) {
            if (Regex("font-weight\\s*:\\s*(bold|[6-9]00)").containsMatchIn(st)) nf.bold = true
            if (Regex("font-style\\s*:\\s*italic").containsMatchIn(st)) nf.italic = true
            if (Regex("text-decoration[^;]*underline").containsMatchIn(st)) nf.underline = true
            if (Regex("text-decoration[^;]*line-through").containsMatchIn(st)) nf.strike = true
            Regex("(?<![-a-z])color\\s*:\\s*([^;]+)").find(st)?.let { nf.color = hex(it.groupValues[1]) }
            Regex("background(-color)?\\s*:\\s*([^;]+)").find(st)?.let { nf.highlight = hex(it.groupValues[2]) }
            Regex("font-size\\s*:\\s*([0-9.]+)(px|pt)").find(st)?.let {
                val v = it.groupValues[1].toDouble()
                nf.sizeHalfPt = ((if (it.groupValues[2] == "px") v * 0.75 else v) * 2).toInt().coerceIn(2, 400)
            }
            Regex("font-family\\s*:\\s*([^;]+)").find(st)?.let {
                nf.font = wordFont(it.groupValues[1].substringBefore(',').trim().trim('"', '\''))
            }
        }
        return inlineChildren(n, nf)
    }

    private fun run(text: String, f: Fmt): String {
        val rpr = StringBuilder()
        f.font?.let { rpr.append("<w:rFonts w:ascii=\"${x(it)}\" w:hAnsi=\"${x(it)}\" w:cs=\"${x(it)}\"/>") }
        if (f.bold) rpr.append("<w:b/>")
        if (f.italic) rpr.append("<w:i/>")
        if (f.strike) rpr.append("<w:strike/>")
        f.color?.let { rpr.append("<w:color w:val=\"$it\"/>") }
        f.sizeHalfPt?.let { rpr.append("<w:sz w:val=\"$it\"/><w:szCs w:val=\"$it\"/>") }
        f.highlight?.let { rpr.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$it\"/>") }
        if (f.underline || f.link != null) rpr.append("<w:u w:val=\"single\"/>")
        if (f.link != null && f.color == null) rpr.append("<w:color w:val=\"0563C1\"/>")
        if (f.sup) rpr.append("<w:vertAlign w:val=\"superscript\"/>")
        if (f.sub) rpr.append("<w:vertAlign w:val=\"subscript\"/>")
        val r = "<w:r>" + (if (rpr.isNotEmpty()) "<w:rPr>$rpr</w:rPr>" else "") +
            "<w:t xml:space=\"preserve\">${x(text)}</w:t></w:r>"
        val link = f.link
        if (link != null && (link.startsWith("http") || link.startsWith("mailto:"))) {
            val id = "rIdL${++relCounter}"
            rels.append("<Relationship Id=\"$id\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink\" Target=\"${x(link)}\" TargetMode=\"External\"/>")
            return "<w:hyperlink r:id=\"$id\">$r</w:hyperlink>"
        }
        return r
    }

    /** Converte famílias genéricas do Android para fontes que existem no Word. */
    private fun wordFont(name: String): String = when (name.lowercase()) {
        "serif" -> "Times New Roman"
        "sans-serif", "sans-serif-medium" -> "Arial"
        "sans-serif-light" -> "Calibri Light"
        "sans-serif-condensed" -> "Arial Narrow"
        "monospace", "serif-monospace" -> "Courier New"
        "cursive" -> "Segoe Script"
        "casual" -> "Comic Sans MS"
        else -> name
    }

    private fun hex(css: String): String? {
        val c = css.trim().lowercase()
        Regex("^#([0-9a-f]{6})$").find(c)?.let { return it.groupValues[1].uppercase() }
        Regex("^#([0-9a-f])([0-9a-f])([0-9a-f])$").find(c)?.let { m -> return m.groupValues.drop(1).joinToString("") { it + it }.uppercase() }
        Regex("^rgba?\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)").find(c)?.let { m ->
            return m.groupValues.drop(1).joinToString("") { "%02X".format(it.toInt().coerceIn(0, 255)) }
        }
        return when (c) { "black" -> "000000"; "white" -> "FFFFFF"; "red" -> "FF0000"; "blue" -> "0000FF"
            "green" -> "008000"; "yellow" -> "FFFF00"; "gray", "grey" -> "808080"; "orange" -> "FFA500"; else -> null }
    }

    // ---------- imagens ----------

    private fun imageParagraph(img: Element, ctx: Ctx): String {
        val ib = ImageResolver.resolve(img.attr("src"), media) ?: return ""
        val usableW = (if (req.landscape) req.pageHmm else req.pageWmm) - req.marginInnerMm - req.marginOuterMm
        val sb = StringBuilder("<w:p><w:pPr>")
        if (ctx.pendingBreak) sb.append("<w:pageBreakBefore/>")
        sb.append("<w:jc w:val=\"center\"/></w:pPr>").append("<w:r>").append(drawing(ib, usableW, 9999.0, img.attr("alt"), img)).append("</w:r></w:p>")
        return sb.toString()
    }

    private fun imageRun(ib: ImageBytes, maxWmm: Double, maxHmm: Double, alt: String): String =
        "<w:r>" + drawing(ib, maxWmm, maxHmm, alt, null) + "</w:r>"

    private fun drawing(ib: ImageBytes, maxWmm: Double, maxHmm: Double, alt: String, el: Element?): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(ib.bytes, 0, ib.bytes.size, bounds)
        val iw = bounds.outWidth.coerceAtLeast(1).toDouble()
        val ih = bounds.outHeight.coerceAtLeast(1).toDouble()
        var wmm = iw * 25.4 / 150.0
        val styleW = el?.attr("style")?.let { Regex("width\\s*:\\s*([0-9.]+)%").find(it)?.groupValues?.get(1)?.toDouble() }
        if (styleW != null) wmm = maxWmm * styleW / 100.0
        var hmm = wmm * ih / iw
        val scale = minOf(1.0, maxWmm / wmm, maxHmm / hmm)
        wmm *= scale; hmm *= scale
        val name = "image${imageFiles.size + 1}.${ib.ext}"
        imageFiles[name] = ib.bytes
        val rid = "rIdImg${imageFiles.size}"
        rels.append("<Relationship Id=\"$rid\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/$name\"/>")
        val cx = (wmm * EMU_PER_MM).toLong()
        val cy = (hmm * EMU_PER_MM).toLong()
        val id = drawingId++
        return "<w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"$cx\" cy=\"$cy\"/>" +
            "<wp:docPr id=\"$id\" name=\"Imagem $id\" descr=\"${x(alt)}\"/>" +
            "<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect=\"1\"/></wp:cNvGraphicFramePr>" +
            "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
            "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"$id\" name=\"$name\"/><pic:cNvPicPr/></pic:nvPicPr>" +
            "<pic:blipFill><a:blip r:embed=\"$rid\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
            "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>" +
            "</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing>"
    }

    // ---------- tabelas ----------

    private fun table(t: Element): String {
        val rows = t.select("tr")
        if (rows.isEmpty()) return ""
        val cols = rows.maxOf { it.children().count { c -> c.tagName() in setOf("td", "th") } }.coerceAtLeast(1)
        val usableW = ((if (req.landscape) req.pageHmm else req.pageWmm) - req.marginInnerMm - req.marginOuterMm) * 56.6929
        val colW = (usableW / cols).toInt()
        val sb = StringBuilder("<w:tbl><w:tblPr><w:tblW w:w=\"${(colW * cols)}\" w:type=\"dxa\"/><w:tblBorders>")
        for (b in listOf("top", "left", "bottom", "right", "insideH", "insideV")) sb.append("<w:$b w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"999999\"/>")
        sb.append("</w:tblBorders><w:tblLayout w:type=\"fixed\"/></w:tblPr><w:tblGrid>")
        repeat(cols) { sb.append("<w:gridCol w:w=\"$colW\"/>") }
        sb.append("</w:tblGrid>")
        for (tr in rows) {
            sb.append("<w:tr>")
            val cells = tr.children().filter { it.tagName() in setOf("td", "th") }
            for (c in cells) {
                val th = c.tagName() == "th"
                val f = Fmt(bold = th)
                val runs = inlineChildren(c, f)
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"$colW\" w:type=\"dxa\"/>")
                if (th) sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"EEEEEE\"/>")
                sb.append("</w:tcPr>").append(paragraph(Para(align = alignOf(c)), runs.ifEmpty { listOf("") })).append("</w:tc>")
            }
            repeat(cols - cells.size) { sb.append("<w:tc><w:tcPr><w:tcW w:w=\"$colW\" w:type=\"dxa\"/></w:tcPr><w:p/></w:tc>") }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl>")
        return sb.toString()
    }

    // ---------- índice ----------

    private fun tocBlock(s: Section, breakBefore: Boolean): String {
        val sb = StringBuilder()
        sb.append(paragraph(Para(style = "Heading1", pageBreakBefore = breakBefore, keepNext = true), listOf(run(s.title.ifBlank { "Índice" }, Fmt()))))
        for (t in req.toc) {
            val lvl = t.level.coerceIn(1, 3)
            sb.append(paragraph(Para(indentLeftTw = (lvl - 1) * 360, spaceAfterTw = 80), listOf(run(t.title, Fmt(bold = lvl == 1)))))
        }
        return sb.toString()
    }

    // ---------- partes do pacote ----------

    private fun x(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
        .filter { it.code >= 32 || it == '\n' || it == '\t' }

    private fun contentTypes(): String {
        val exts = imageFiles.keys.map { it.substringAfterLast('.') }.toSet()
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
        sb.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>")
        for (e in exts) {
            val ct = when (e) { "png" -> "image/png"; "gif" -> "image/gif"; "webp" -> "image/webp"; else -> "image/jpeg" }
            sb.append("<Default Extension=\"$e\" ContentType=\"$ct\"/>")
        }
        sb.append("<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>")
        sb.append("<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>")
        sb.append("<Override PartName=\"/word/numbering.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml\"/>")
        sb.append("<Override PartName=\"/word/footer1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml\"/>")
        sb.append("<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/></Types>")
        return sb.toString()
    }

    private fun coreXml() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
        "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" " +
        "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><dc:title>${x(req.title)}</dc:title>" +
        "<dc:creator>${x(req.author)}</dc:creator><dc:language>${x(req.language)}</dc:language></cp:coreProperties>"

    private fun documentRels() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rIdStyles\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
        "<Relationship Id=\"rIdNum\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering\" Target=\"numbering.xml\"/>" +
        "<Relationship Id=\"rIdFooter\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer\" Target=\"footer1.xml\"/>" +
        rels + "</Relationships>"

    private fun footerXml() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<w:ftr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr>" +
        "<w:r><w:rPr><w:sz w:val=\"18\"/></w:rPr><w:fldChar w:fldCharType=\"begin\"/></w:r>" +
        "<w:r><w:rPr><w:sz w:val=\"18\"/></w:rPr><w:instrText xml:space=\"preserve\"> PAGE </w:instrText></w:r>" +
        "<w:r><w:rPr><w:sz w:val=\"18\"/></w:rPr><w:fldChar w:fldCharType=\"separate\"/></w:r>" +
        "<w:r><w:rPr><w:sz w:val=\"18\"/></w:rPr><w:t>1</w:t></w:r>" +
        "<w:r><w:rPr><w:sz w:val=\"18\"/></w:rPr><w:fldChar w:fldCharType=\"end\"/></w:r></w:p></w:ftr>"

    private fun stylesXml(): String {
        val font = when (req.fontFamily.lowercase()) {
            "", "sans" -> "Arial"; "mono" -> "Courier New"
            else -> wordFont(req.fontFamily.substringBefore(',').trim('"', '\'', ' '))
        }
        val sz = (req.fontSizePt * 2).toInt()
        val line = (req.lineHeight * 240).toInt()
        fun h(id: String, n: Int, size: Int) = "<w:style w:type=\"paragraph\" w:styleId=\"Heading$id\"><w:name w:val=\"heading $id\"/><w:basedOn w:val=\"Normal\"/>" +
            "<w:next w:val=\"Normal\"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before=\"${if (n == 1) 360 else 240}\" w:after=\"120\"/><w:outlineLvl w:val=\"${n - 1}\"/></w:pPr>" +
            "<w:rPr><w:b/><w:sz w:val=\"$size\"/><w:szCs w:val=\"$size\"/></w:rPr></w:style>"
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
            "<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"${x(font)}\" w:hAnsi=\"${x(font)}\" w:cs=\"${x(font)}\"/>" +
            "<w:sz w:val=\"$sz\"/><w:szCs w:val=\"$sz\"/><w:lang w:val=\"${x(req.language)}\"/></w:rPr></w:rPrDefault>" +
            "<w:pPrDefault><w:pPr><w:spacing w:after=\"120\" w:line=\"$line\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>" +
            "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/><w:qFormat/></w:style>" +
            h("1", 1, 36) + h("2", 2, 30) + h("3", 3, 26) +
            "<w:style w:type=\"paragraph\" w:styleId=\"Quote\"><w:name w:val=\"Quote\"/><w:basedOn w:val=\"Normal\"/><w:qFormat/>" +
            "<w:pPr><w:pBdr><w:left w:val=\"single\" w:sz=\"18\" w:space=\"8\" w:color=\"888888\"/></w:pBdr><w:ind w:left=\"720\" w:right=\"720\"/></w:pPr><w:rPr><w:i/></w:rPr></w:style>" +
            "</w:styles>"
    }

    private fun numberingXml(): String {
        fun lvls(fmt: String, text: (Int) -> String): String = (0..3).joinToString("") { i ->
            "<w:lvl w:ilvl=\"$i\"><w:start w:val=\"1\"/><w:numFmt w:val=\"$fmt\"/><w:lvlText w:val=\"${text(i)}\"/><w:lvlJc w:val=\"left\"/>" +
                "<w:pPr><w:ind w:left=\"${720 + i * 360}\" w:hanging=\"360\"/></w:pPr></w:lvl>"
        }
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:numbering xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
            "<w:abstractNum w:abstractNumId=\"0\"><w:multiLevelType w:val=\"hybridMultilevel\"/>${lvls("bullet") { "•" }}</w:abstractNum>" +
            "<w:abstractNum w:abstractNumId=\"1\"><w:multiLevelType w:val=\"hybridMultilevel\"/>${lvls("decimal") { "%${it + 1}." }}</w:abstractNum>" +
            "<w:num w:numId=\"1\"><w:abstractNumId w:val=\"0\"/></w:num><w:num w:numId=\"2\"><w:abstractNumId w:val=\"1\"/></w:num></w:numbering>"
    }
}
