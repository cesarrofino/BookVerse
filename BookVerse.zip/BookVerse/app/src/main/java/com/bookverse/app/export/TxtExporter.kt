package com.bookverse.app.export

import java.io.File

/** Exporta o livro como texto simples UTF-8 (capa e imagens são omitidas). */
object TxtExporter {
    fun export(req: ExportRequest, out: File) {
        val sb = StringBuilder()
        sb.append(req.title.uppercase()).append('\n')
        if (req.subtitle.isNotBlank()) sb.append(req.subtitle).append('\n')
        if (req.author.isNotBlank()) sb.append("\n").append(req.author).append('\n')
        sb.append("\n").append("=".repeat(40)).append("\n\n")

        for (s in req.sections) {
            if (s.type == "cover" || s.type == "backcover") continue
            if (s.type == "toc") {
                sb.append(s.title.ifBlank { "Índice" }.uppercase()).append("\n\n")
                for (t in req.toc) sb.append("  ".repeat((t.level - 1).coerceAtLeast(0))).append(t.title).append('\n')
                sb.append("\n\n")
                continue
            }
            val text = HtmlText.toPlain(s.html)
            if (s.title.isNotBlank() && !text.startsWith(s.title)) {
                sb.append(s.title.uppercase()).append("\n\n")
            }
            if (text.isNotEmpty()) sb.append(text).append("\n\n")
            sb.append("\n")
        }
        out.writeText(sb.toString().trimEnd() + "\n", Charsets.UTF_8)
    }
}
