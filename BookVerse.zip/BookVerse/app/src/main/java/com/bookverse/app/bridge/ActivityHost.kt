package com.bookverse.app.bridge

import android.app.Activity
import android.content.Intent
import android.net.Uri

/** Operações que precisam de uma Activity (seletores do sistema, fluxos de login). */
interface ActivityHost {
    val activity: Activity

    /** Abre a galeria ou a câmara. Devolve o Uri escolhido ou null se cancelado. */
    suspend fun pickImage(fromCamera: Boolean): Uri?

    /** Storage Access Framework: criar ficheiro de destino. */
    suspend fun createDocument(suggestedName: String, mime: String): Uri?

    /** Storage Access Framework: escolher ficheiro existente. */
    suspend fun openDocument(mimes: Array<String>): Uri?

    /** Lança o intent do Google Sign-In e devolve os dados do resultado. */
    suspend fun launchForResult(intent: Intent): Intent?

    /** Atualiza as barras do sistema para o tema atual. */
    fun setSystemBars(colorHex: String, darkIcons: Boolean)
}
