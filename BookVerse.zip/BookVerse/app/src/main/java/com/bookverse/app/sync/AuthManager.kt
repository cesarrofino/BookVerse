package com.bookverse.app.sync

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.bookverse.app.R
import com.bookverse.app.data.SettingsStore
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.OAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.tasks.await
import org.json.JSONObject

/**
 * Contas Firebase: email/palavra-passe, Google e GitHub. A sessão é gerida pelo Firebase Auth (persistente);
 * o uid fica também numa cópia cifrada para a biblioteca local abrir sem internet.
 */
class AuthManager(private val context: Context, private val settings: SettingsStore) {

    class AuthException(message: String) : Exception(message)

    /** True se o ficheiro google-services.json é um projeto Firebase real (não o marcador de posição). */
    val isConfigured: Boolean
        get() = try {
            FirebaseApp.getApps(context).isNotEmpty() &&
                FirebaseApp.getInstance().options.apiKey.let { it.isNotBlank() && !it.startsWith("PLACEHOLDER") }
        } catch (e: Exception) { false }

    private val auth: FirebaseAuth? get() = if (isConfigured) Firebase.auth else null

    /** uid atual; funciona offline porque o Firebase Auth restaura a sessão do disco, com cópia cifrada de reserva. */
    fun currentUid(): String = auth?.currentUser?.uid ?: settings.secureGet("uid")

    fun currentUser(): FirebaseUser? = auth?.currentUser

    fun userJson(): JSONObject {
        val u = auth?.currentUser
        val o = JSONObject()
        if (u != null) {
            o.put("signedIn", true).put("uid", u.uid).put("email", u.email ?: "")
                .put("name", u.displayName ?: "").put("photo", u.photoUrl?.toString() ?: "")
            o.put("provider", u.providerData.firstOrNull { it.providerId != "firebase" }?.providerId ?: "password")
        } else if (settings.secureGet("uid").isNotEmpty() && isConfigured) {
            // sessão em cache enquanto o Firebase ainda não restaurou (arranque offline)
            o.put("signedIn", true).put("uid", settings.secureGet("uid")).put("email", settings.secureGet("email"))
                .put("name", settings.secureGet("name")).put("photo", "").put("provider", "cache")
        } else o.put("signedIn", false)
        o.put("configured", isConfigured)
        return o
    }

    private fun remember(u: FirebaseUser?) {
        if (u == null) { listOf("uid", "email", "name").forEach { settings.secureRemove(it) }; return }
        settings.securePut("uid", u.uid)
        settings.securePut("email", u.email ?: "")
        settings.securePut("name", u.displayName ?: "")
    }

    private fun requireAuth(): FirebaseAuth =
        auth ?: throw AuthException("O Firebase ainda não está configurado. Consulte o README (secção Firebase).")

    suspend fun register(name: String, email: String, password: String): FirebaseUser {
        try {
            val a = requireAuth()
            val res = a.createUserWithEmailAndPassword(email.trim(), password).await()
            val u = res.user ?: throw AuthException("Falha ao criar a conta")
            if (name.isNotBlank()) {
                u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()).await()
            }
            remember(a.currentUser)
            saveProfile(u.uid, name.trim(), email.trim())
            return u
        } catch (e: AuthException) { throw e } catch (e: Exception) { throw AuthException(translate(e)) }
    }

    suspend fun login(email: String, password: String): FirebaseUser {
        try {
            val res = requireAuth().signInWithEmailAndPassword(email.trim(), password).await()
            val u = res.user ?: throw AuthException("Falha ao iniciar sessão")
            remember(u)
            return u
        } catch (e: AuthException) { throw e } catch (e: Exception) { throw AuthException(translate(e)) }
    }

    suspend fun resetPassword(email: String) {
        try { requireAuth().sendPasswordResetEmail(email.trim()).await() }
        catch (e: AuthException) { throw e } catch (e: Exception) { throw AuthException(translate(e)) }
    }

    /** Intent de início de sessão Google, a lançar pela Activity. */
    fun googleIntent(): Intent {
        requireAuth()
        val webClientId = context.getString(R.string.bv_web_client_id)
        if (webClientId.isBlank()) throw AuthException("Falta o Web Client ID do Google em res/values/firebase_config.xml (ver README).")
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(webClientId).requestEmail().build()
        return GoogleSignIn.getClient(context, gso).signInIntent
    }

    suspend fun finishGoogle(data: Intent?): FirebaseUser {
        try {
            val account = try {
                GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException::class.java)
            } catch (e: ApiException) {
                if (e.statusCode == 12501) throw AuthException("Início de sessão cancelado")
                throw AuthException("Falha no Google Sign-In (código ${e.statusCode}). Verifique o SHA-1 no Firebase.")
            }
            val cred = GoogleAuthProvider.getCredential(account.idToken, null)
            val u = requireAuth().signInWithCredential(cred).await().user ?: throw AuthException("Falha ao iniciar sessão")
            remember(u)
            saveProfile(u.uid, u.displayName ?: "", u.email ?: "")
            return u
        } catch (e: AuthException) { throw e } catch (e: Exception) { throw AuthException(translate(e)) }
    }

    /** Login com GitHub através do fluxo OAuth do Firebase (requer GitHub ativado na consola). */
    suspend fun loginGithub(activity: Activity): FirebaseUser {
        try {
            val a = requireAuth()
            val provider = OAuthProvider.newBuilder("github.com").setScopes(listOf("user:email")).build()
            val pending = a.pendingAuthResult
            val res = (pending ?: a.startActivityForSignInWithProvider(activity, provider)).await()
            val u = res.user ?: throw AuthException("Falha ao iniciar sessão")
            remember(u)
            saveProfile(u.uid, u.displayName ?: "", u.email ?: "")
            return u
        } catch (e: AuthException) { throw e } catch (e: Exception) { throw AuthException(translate(e)) }
    }

    suspend fun updateProfile(name: String, bio: String) {
        val u = requireAuth().currentUser ?: throw AuthException("Sem sessão iniciada")
        try {
            u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()).await()
            FirebaseFirestore.getInstance().collection("users").document(u.uid)
                .set(mapOf("displayName" to name.trim(), "bio" to bio.trim(), "updatedAt" to System.currentTimeMillis()),
                    com.google.firebase.firestore.SetOptions.merge()).await()
            remember(u)
        } catch (e: Exception) { throw AuthException(translate(e)) }
    }

    suspend fun loadBio(): String {
        val u = auth?.currentUser ?: return ""
        return try {
            FirebaseFirestore.getInstance().collection("users").document(u.uid).get().await().getString("bio") ?: ""
        } catch (e: Exception) { "" }
    }

    private suspend fun saveProfile(uid: String, name: String, email: String) {
        try {
            FirebaseFirestore.getInstance().collection("users").document(uid)
                .set(mapOf("displayName" to name, "email" to email, "updatedAt" to System.currentTimeMillis()),
                    com.google.firebase.firestore.SetOptions.merge()).await()
        } catch (_: Exception) { /* o perfil é sincronizado mais tarde */ }
    }

    /** Termina a sessão. Os livros locais NÃO são apagados. */
    fun logout() {
        auth?.signOut()
        try {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build()
            GoogleSignIn.getClient(context, gso).signOut()
        } catch (_: Exception) {}
        remember(null)
    }

    private fun translate(e: Exception): String {
        val m = e.message ?: ""
        return when {
            m.contains("INVALID_LOGIN_CREDENTIALS") || m.contains("password is invalid") || m.contains("no user record") ->
                "Email ou palavra-passe incorretos"
            m.contains("email address is already in use") -> "Este email já está registado"
            m.contains("badly formatted") -> "Email inválido"
            m.contains("at least 6 characters") || m.contains("WEAK_PASSWORD") -> "A palavra-passe deve ter pelo menos 6 caracteres"
            m.contains("network", ignoreCase = true) || m.contains("unreachable", ignoreCase = true) ->
                "Sem ligação à internet. Pode continuar a usar o BookVerse offline."
            m.contains("TOO_MANY_ATTEMPTS") || m.contains("blocked all requests") -> "Demasiadas tentativas. Tente mais tarde."
            m.contains("operation is not allowed") || m.contains("OPERATION_NOT_ALLOWED") ->
                "Este método de início de sessão não está ativado no Firebase."
            m.contains("canceled", ignoreCase = true) || m.contains("cancelled", ignoreCase = true) -> "Operação cancelada"
            else -> m.ifBlank { "Erro desconhecido" }
        }
    }
}
