package android.print

import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import java.io.File

/**
 * Auxiliar no pacote android.print (os callbacks de layout/escrita só são acessíveis aqui).
 * Escreve para ficheiro o resultado do PrintDocumentAdapter de uma WebView, sem diálogo de impressão.
 */
class PdfPrint(private val widthMils: Int, private val heightMils: Int) {

    fun write(adapter: PrintDocumentAdapter, target: File, onDone: (Throwable?) -> Unit) {
        val attrs = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize("bv_custom", "BookVerse", widthMils, heightMils))
            .setResolution(PrintAttributes.Resolution("bv_res", "bv", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()

        adapter.onLayout(null, attrs, CancellationSignal(), object : PrintDocumentAdapter.LayoutResultCallback() {
            override fun onLayoutFinished(info: PrintDocumentInfo?, changed: Boolean) {
                try {
                    val pfd = ParcelFileDescriptor.open(
                        target,
                        ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE or ParcelFileDescriptor.MODE_READ_WRITE
                    )
                    adapter.onWrite(arrayOf(PageRange.ALL_PAGES), pfd, CancellationSignal(),
                        object : PrintDocumentAdapter.WriteResultCallback() {
                            override fun onWriteFinished(pages: Array<out PageRange>?) {
                                try { pfd.close() } catch (_: Exception) {}
                                adapter.onFinish()
                                onDone(null)
                            }

                            override fun onWriteFailed(error: CharSequence?) {
                                try { pfd.close() } catch (_: Exception) {}
                                adapter.onFinish()
                                onDone(RuntimeException(error?.toString() ?: "Falha ao escrever o PDF"))
                            }
                        })
                } catch (e: Exception) {
                    onDone(e)
                }
            }

            override fun onLayoutFailed(error: CharSequence?) {
                onDone(RuntimeException(error?.toString() ?: "Falha ao preparar o PDF"))
            }
        }, null)
    }
}
