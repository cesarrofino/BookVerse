/* BookVerse — motor do editor de texto rico (contenteditable + histórico próprio) */
(function () {
  'use strict';
  const BV = window.BV;

  const BLOCK_SEL = 'p,div,h1,h2,h3,h4,li,blockquote,td,th';

  class Editor {
    constructor(root, opts) {
      this.root = root;
      this.opts = opts || {};
      this.hist = [];
      this.hi = -1;
      this.lastRange = null;
      this.pendingSize = null;
      root.setAttribute('contenteditable', 'true');
      root.setAttribute('spellcheck', 'true');
      root.setAttribute('autocapitalize', 'sentences');
      try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) {}
      this._commitDebounced = BV.debounce(() => this.commit(), 450);

      root.addEventListener('input', () => this._onInput());
      root.addEventListener('beforeinput', (e) => {
        if (e.inputType === 'historyUndo') { e.preventDefault(); this.undo(); }
        else if (e.inputType === 'historyRedo') { e.preventDefault(); this.redo(); }
      });
      root.addEventListener('paste', (e) => this._onPaste(e));
      root.addEventListener('keydown', (e) => this._onKey(e));
      this._selHandler = () => {
        const s = document.getSelection();
        if (s.rangeCount && root.contains(s.anchorNode)) { this.lastRange = s.getRangeAt(0).cloneRange(); if (this.opts.onSelection) this.opts.onSelection(); }
      };
      document.addEventListener('selectionchange', this._selHandler);
    }

    destroy() { document.removeEventListener('selectionchange', this._selHandler); this._commitDebounced.cancel(); }

    /* ---------- conteúdo ---------- */
    setHtml(html) {
      this.root.innerHTML = html && html.trim() ? html : '<p><br></p>';
      this._normalize();
      this.hist = []; this.hi = -1; this.lastRange = null;
      this._push();
    }
    getHtml() {
      const c = this.root.cloneNode(true);
      c.querySelectorAll('.bv-sel').forEach((e) => e.classList.remove('bv-sel'));
      c.querySelectorAll('[contenteditable]').forEach((e) => e.removeAttribute('contenteditable'));
      c.querySelectorAll('font[size]').forEach((f) => { const s = document.createElement('span'); while (f.firstChild) s.appendChild(f.firstChild); f.replaceWith(s); });
      return c.innerHTML;
    }
    _normalize() {
      const r = this.root;
      r.querySelectorAll('.pagebreak').forEach((e) => { e.setAttribute('contenteditable', 'false'); e.innerHTML = ''; });
      if (!r.firstChild) r.innerHTML = '<p><br></p>';
      // texto solto no topo → parágrafos
      for (const n of Array.from(r.childNodes)) {
        if (n.nodeType === 3 && n.nodeValue.trim()) { const p = document.createElement('p'); r.insertBefore(p, n); p.appendChild(n); }
      }
    }
    _onInput() {
      this._fixFont();
      if (this.root.firstChild && this.root.firstChild.nodeType === 3) { this._normalize(); }
      if (this.opts.onChange) this.opts.onChange();
      this._commitDebounced();
    }
    _fixFont() {
      if (this.pendingSize) this.root.querySelectorAll('span[style*="xxx-large"]').forEach((e) => { e.style.fontSize = this.pendingSize + 'pt'; });
      this.root.querySelectorAll('font').forEach((f) => {
        const s = document.createElement('span');
        if (f.getAttribute('size') === '7' && this.pendingSize) s.style.fontSize = this.pendingSize + 'pt';
        if (f.getAttribute('face')) s.style.fontFamily = f.getAttribute('face');
        if (f.getAttribute('color')) s.style.color = f.getAttribute('color');
        while (f.firstChild) s.appendChild(f.firstChild);
        f.replaceWith(s);
      });
      // span.style com font-size herdado em spans aninhados: simplificação para manter o HTML limpo
      this.root.querySelectorAll('span[style*="font-size"] span[style*="font-size"]').forEach((inner) => {
        const outer = inner.parentElement; if (outer && outer.childNodes.length === 1) { outer.style.fontSize = inner.style.fontSize; while (inner.firstChild) outer.insertBefore(inner.firstChild, inner); inner.remove(); }
      });
    }

    async _onPaste(e) {
      e.preventDefault();
      const cd = e.clipboardData;
      const html = cd && cd.getData('text/html');
      const text = cd && cd.getData('text/plain');
      this.commit();
      if (html && html.trim()) {
        const clean = BV.model.sanitize(html.replace(/<!--[\s\S]*?-->/g, ''));
        document.execCommand('insertHTML', false, clean);
      } else if (text) {
        this.insertPlain(text);
      }
      this._onInput();
    }
    insertPlain(text) {
      const html = text.split(/\r?\n/).map((l) => (l.trim() ? '<p>' + BV.esc(l) + '</p>' : '')).filter(Boolean).join('');
      if (text.indexOf('\n') < 0) document.execCommand('insertText', false, text);
      else document.execCommand('insertHTML', false, html);
    }

    _onKey(e) {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod) return;
      const k = e.key.toLowerCase();
      if (k === 'z') { e.preventDefault(); e.shiftKey ? this.redo() : this.undo(); }
      else if (k === 'y') { e.preventDefault(); this.redo(); }
      else if (k === 'b') { e.preventDefault(); this.toggle('bold'); }
      else if (k === 'i') { e.preventDefault(); this.toggle('italic'); }
      else if (k === 'u') { e.preventDefault(); this.toggle('underline'); }
    }

    /* ---------- seleção ---------- */
    focus() { this.root.focus({ preventScroll: true }); }
    restore() {
      this.focus();
      const s = document.getSelection();
      if (s.rangeCount && this.root.contains(s.anchorNode)) return;   // a seleção atual já está no editor
      if (this.lastRange) { s.removeAllRanges(); s.addRange(this.lastRange); }
    }
    hasSelection() { const s = document.getSelection(); return s.rangeCount > 0 && !s.isCollapsed && this.root.contains(s.anchorNode); }
    selectedText() { const s = document.getSelection(); return s.rangeCount && this.root.contains(s.anchorNode) ? s.toString() : ''; }
    selectAll() {
      this.focus();
      const r = document.createRange(); r.selectNodeContents(this.root);
      const s = document.getSelection(); s.removeAllRanges(); s.addRange(r); this.lastRange = r.cloneRange();
    }
    _pathOf(node) { const p = []; while (node && node !== this.root) { p.unshift(Array.prototype.indexOf.call(node.parentNode.childNodes, node)); node = node.parentNode; } return p; }
    _nodeAt(path) { let n = this.root; for (const i of path) { n = n && n.childNodes[i]; } return n; }
    _saveSel() {
      const s = document.getSelection();
      if (!s.rangeCount || !this.root.contains(s.anchorNode)) return null;
      const r = s.getRangeAt(0);
      return { sp: this._pathOf(r.startContainer), so: r.startOffset, ep: this._pathOf(r.endContainer), eo: r.endOffset };
    }
    _loadSel(st) {
      if (!st) return;
      try {
        const a = this._nodeAt(st.sp), b = this._nodeAt(st.ep);
        if (!a || !b) return;
        const r = document.createRange();
        r.setStart(a, Math.min(st.so, a.nodeType === 3 ? a.nodeValue.length : a.childNodes.length));
        r.setEnd(b, Math.min(st.eo, b.nodeType === 3 ? b.nodeValue.length : b.childNodes.length));
        const s = document.getSelection(); s.removeAllRanges(); s.addRange(r);
      } catch (e) { /* ignora */ }
    }

    /* ---------- histórico ---------- */
    _push() {
      const html = this.root.innerHTML;
      if (this.hi >= 0 && this.hist[this.hi].html === html) { this.hist[this.hi].sel = this._saveSel(); return; }
      this.hist = this.hist.slice(0, this.hi + 1);
      this.hist.push({ html, sel: this._saveSel() });
      if (this.hist.length > 200) this.hist.shift();
      this.hi = this.hist.length - 1;
      if (this.opts.onHistory) this.opts.onHistory();
    }
    commit() { this._commitDebounced.cancel(); this._push(); }
    canUndo() { return this.hi > 0 || (this.hi === 0 && this.root.innerHTML !== this.hist[0].html); }
    canRedo() { return this.hi < this.hist.length - 1; }
    undo() {
      this.commit();
      if (this.hi <= 0) return;
      this.hi--; this._apply();
    }
    redo() {
      if (this.hi >= this.hist.length - 1) return;
      this.hi++; this._apply();
    }
    _apply() {
      const st = this.hist[this.hi];
      this.root.innerHTML = st.html;
      this._normalize();
      this.focus(); this._loadSel(st.sel);
      if (this.opts.onChange) this.opts.onChange();
      if (this.opts.onHistory) this.opts.onHistory();
    }

    /* ---------- comandos ---------- */
    _run(fn) {
      this.restore();
      this.commit();
      try { document.execCommand('styleWithCSS', false, true); } catch (e) {}
      fn();
      this._fixFont();
      this._push();
      if (this.opts.onChange) this.opts.onChange();
      if (this.opts.onSelection) this.opts.onSelection();
    }
    exec(cmd, val) { this._run(() => document.execCommand(cmd, false, val == null ? null : val)); }
    toggle(cmd) { this.exec(cmd); }
    state(cmd) { try { return document.queryCommandState(cmd); } catch (e) { return false; } }

    setFont(family) { this.exec('fontName', family); }
    setSizePt(pt) {
      this.pendingSize = pt;
      this._run(() => {
        document.execCommand('fontSize', false, '7');
        const made = [];
        this.root.querySelectorAll('font[size="7"], span[style*="xxx-large"]').forEach((f) => {
          if (f.tagName === 'FONT') {
            const sp = document.createElement('span');
            while (f.firstChild) sp.appendChild(f.firstChild);
            f.replaceWith(sp); sp.style.fontSize = pt + 'pt'; made.push(sp);
          } else { f.style.fontSize = pt + 'pt'; made.push(f); }
        });
        // remove tamanhos redundantes de spans aninhados
        this.root.querySelectorAll('span[style*="font-size"] span[style*="font-size"]').forEach((inner) => {
          inner.style.fontSize = '';
          if (!inner.getAttribute('style')) { const i = made.indexOf(inner); while (inner.firstChild) inner.parentNode.insertBefore(inner.firstChild, inner); inner.remove(); if (i >= 0) made.splice(i, 1); }
        });
        const live = made.filter((m) => m.isConnected);
        if (live.length) {   // mantém o texto selecionado para comandos seguintes
          const r = document.createRange(); r.setStartBefore(live[0]); r.setEndAfter(live[live.length - 1]);
          const sel = document.getSelection(); sel.removeAllRanges(); sel.addRange(r); this.lastRange = r.cloneRange();
        }
      });
    }
    setColor(c) { this.exec('foreColor', c); }
    setHighlight(c) { this.exec('hiliteColor', c || 'transparent'); }
    setBlock(tag) { this.exec('formatBlock', '<' + tag + '>'); }
    align(kind) { this.exec({ left: 'justifyLeft', center: 'justifyCenter', right: 'justifyRight', justify: 'justifyFull' }[kind]); }
    list(kind) { this.exec(kind === 'ol' ? 'insertOrderedList' : 'insertUnorderedList'); }
    indent(more) { this.exec(more ? 'indent' : 'outdent'); }
    clearFormat() { this.exec('removeFormat'); }

    /** Blocos (parágrafos, títulos, itens) abrangidos pela seleção. */
    selectedBlocks() {
      const s = document.getSelection();
      if (!s.rangeCount) return [];
      const r = s.getRangeAt(0);
      const out = new Set();
      const climb = (n) => { while (n && n !== this.root) { if (n.nodeType === 1 && n.matches(BLOCK_SEL)) return n; n = n.parentNode; } return null; };
      const a = climb(r.startContainer), b = climb(r.endContainer);
      if (a) out.add(a);
      if (b) out.add(b);
      this.root.querySelectorAll(BLOCK_SEL).forEach((el) => { if (r.intersectsNode(el) && !el.querySelector(BLOCK_SEL.replace('div,', ''))) out.add(el); });
      return Array.from(out).filter((e) => this.root.contains(e) && e !== this.root);
    }
    setBlockStyle(prop, value) {
      this._run(() => {
        let blocks = this.selectedBlocks();
        if (!blocks.length) { const p = this.root.querySelector('p'); if (p) blocks = [p]; }
        blocks.forEach((b) => { b.style[prop] = value; if (!b.getAttribute('style')) b.removeAttribute('style'); });
      });
    }
    setLineHeight(v) { this.setBlockStyle('lineHeight', v); }
    setParaSpacing(pt) { this.setBlockStyle('marginBottom', pt + 'pt'); }
    setFirstLineIndent(mm) { this.setBlockStyle('textIndent', mm ? mm + 'mm' : ''); }

    /* ---------- inserções ---------- */
    insertHtml(html) { this._run(() => document.execCommand('insertHTML', false, html)); this._normalize(); }
    insertImage(url, opts) {
      opts = opts || {};
      const w = opts.width || 80;
      const al = opts.align || 'center';
      const margin = al === 'left' ? '0.7em auto 0.7em 0' : al === 'right' ? '0.7em 0 0.7em auto' : '0.7em auto';
      this.insertHtml('<img src="' + BV.esc(url) + '" alt="' + BV.esc(opts.alt || '') + '" style="width:' + w + '%;display:block;margin:' + margin + '"><p><br></p>');
    }
    insertTable(rows, cols, header) {
      let h = '<table><tbody>';
      for (let r = 0; r < rows; r++) {
        h += '<tr>';
        for (let c = 0; c < cols; c++) h += (header && r === 0 ? '<th><br></th>' : '<td><br></td>');
        h += '</tr>';
      }
      h += '</tbody></table><p><br></p>';
      this.insertHtml(h);
    }
    insertQuote() { this.setBlock('blockquote'); }
    insertSeparator(kind) { this.insertHtml(kind === 'orn' ? '<hr class="orn"><p><br></p>' : '<hr><p><br></p>'); }
    insertLink(url, text) {
      this._run(() => {
        if (this.hasSelection()) document.execCommand('createLink', false, url);
        else document.execCommand('insertHTML', false, '<a href="' + BV.esc(url) + '">' + BV.esc(text || url) + '</a>&nbsp;');
      });
    }
    insertPageBreak() { this.insertHtml('<div class="pagebreak" contenteditable="false"></div><p><br></p>'); }
    removeLink() { this.exec('unlink'); }

    /* tabelas */
    currentCell() {
      const s = document.getSelection(); let n = s.anchorNode;
      while (n && n !== this.root) { if (n.nodeType === 1 && (n.tagName === 'TD' || n.tagName === 'TH')) return n; n = n.parentNode; }
      return null;
    }
    tableOp(op) {
      this.restore();
      const cell = this.currentCell(); if (!cell) return false;
      this.commit();
      const row = cell.parentElement, table = row.closest('table'), idx = cell.cellIndex;
      const mk = (th) => { const c = document.createElement(th ? 'th' : 'td'); c.innerHTML = '<br>'; return c; };
      if (op === 'rowAbove' || op === 'rowBelow') {
        const nr = document.createElement('tr'); for (let i = 0; i < row.cells.length; i++) nr.appendChild(mk(false));
        row.parentNode.insertBefore(nr, op === 'rowAbove' ? row : row.nextSibling);
      } else if (op === 'colLeft' || op === 'colRight') {
        Array.from(table.rows).forEach((r) => { const ref = r.cells[idx]; const c = mk(ref && ref.tagName === 'TH'); r.insertBefore(c, op === 'colLeft' ? ref : ref && ref.nextSibling); });
      } else if (op === 'delRow') { row.remove(); if (!table.rows.length) table.remove(); }
      else if (op === 'delCol') { Array.from(table.rows).forEach((r) => r.cells[idx] && r.cells[idx].remove()); if (!table.rows[0] || !table.rows[0].cells.length) table.remove(); }
      else if (op === 'delTable') table.remove();
      this._normalize(); this._push();
      if (this.opts.onChange) this.opts.onChange();
      return true;
    }

    /** Remove da seleção o conteúdo e devolve o HTML (para mover para outro capítulo). */
    extractSelectionHtml() {
      this.restore();
      const s = document.getSelection();
      if (!s.rangeCount || s.isCollapsed) return '';
      this.commit();
      const frag = s.getRangeAt(0).extractContents();
      const d = document.createElement('div'); d.appendChild(frag);
      this._normalize();
      if (!this.root.textContent.trim() && !this.root.querySelector('img,table,hr')) this.root.innerHTML = '<p><br></p>';
      this._push();
      if (this.opts.onChange) this.opts.onChange();
      return d.innerHTML;
    }

    /* ---------- localizar / substituir ---------- */
    _textNodes() {
      const w = document.createTreeWalker(this.root, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (n.parentElement && n.parentElement.closest('.pagebreak') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) });
      const out = []; let n; while ((n = w.nextNode())) out.push(n); return out;
    }
    findAll(q, cs, whole) {
      this.matches = [];
      if (!q) return 0;
      const esc = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp(whole ? '(?<![\\p{L}\\p{N}])' + esc + '(?![\\p{L}\\p{N}])' : esc, cs ? 'gu' : 'giu');
      for (const node of this._textNodes()) {
        let m; const t = node.nodeValue; re.lastIndex = 0;
        while ((m = re.exec(t))) { this.matches.push({ node, start: m.index, end: m.index + m[0].length }); if (!m[0].length) re.lastIndex++; }
      }
      this.mi = -1;
      return this.matches.length;
    }
    gotoMatch(i) {
      if (!this.matches || !this.matches.length) return null;
      this.mi = (i + this.matches.length) % this.matches.length;
      const m = this.matches[this.mi];
      const r = document.createRange(); r.setStart(m.node, m.start); r.setEnd(m.node, m.end);
      this.focus();
      const s = document.getSelection(); s.removeAllRanges(); s.addRange(r);
      const rect = r.getBoundingClientRect();
      const sc = this.opts.scroller;
      if (sc) { const b = sc.getBoundingClientRect(); if (rect.top < b.top + 60 || rect.bottom > b.bottom - 120) sc.scrollTop += rect.top - b.top - b.height / 3; }
      return this.mi;
    }
    findNext(back) { return this.gotoMatch(this.mi + (back ? -1 : 1)); }
    replaceCurrent(rep) {
      if (this.mi == null || this.mi < 0 || !this.matches[this.mi]) return false;
      this.gotoMatch(this.mi);
      this.commit(); document.execCommand('insertText', false, rep); this._push();
      if (this.opts.onChange) this.opts.onChange();
      return true;
    }
    replaceAll(q, rep, cs, whole) {
      const n = this.findAll(q, cs, whole);
      if (!n) return 0;
      this.commit();
      // de trás para a frente para não invalidar os offsets
      for (let i = this.matches.length - 1; i >= 0; i--) {
        const m = this.matches[i];
        m.node.nodeValue = m.node.nodeValue.slice(0, m.start) + rep + m.node.nodeValue.slice(m.end);
      }
      this._push();
      if (this.opts.onChange) this.opts.onChange();
      this.matches = []; return n;
    }

    /* ---------- estado da barra de ferramentas ---------- */
    stateInfo() {
      const s = document.getSelection();
      const info = { bold: false, italic: false, underline: false, strike: false, ul: false, ol: false, align: 'left', block: 'p', font: '', size: 0, inTable: false, link: false };
      if (!s.rangeCount || !this.root.contains(s.anchorNode)) return info;
      info.bold = this.state('bold'); info.italic = this.state('italic'); info.underline = this.state('underline'); info.strike = this.state('strikeThrough');
      info.ul = this.state('insertUnorderedList'); info.ol = this.state('insertOrderedList');
      info.align = this.state('justifyCenter') ? 'center' : this.state('justifyRight') ? 'right' : this.state('justifyFull') ? 'justify' : 'left';
      let n = s.anchorNode; if (n.nodeType === 3) n = n.parentElement;
      if (n) {
        const cs = getComputedStyle(n);
        info.font = cs.fontFamily; info.size = Math.round(parseFloat(cs.fontSize) * 0.75 * 2) / 2;
        const blk = n.closest('h1,h2,h3,blockquote,p,li'); info.block = blk ? blk.tagName.toLowerCase() : 'p';
        info.inTable = !!n.closest('td,th'); info.link = !!n.closest('a');
      }
      return info;
    }

    wordCount() { return BV.model.countWords(this.root.innerHTML); }
    charCount() { return BV.model.countChars(this.root.innerHTML, true); }
    selectionWordCount() { const t = this.selectedText().trim(); return t ? t.split(/\s+/).length : 0; }
  }

  BV.Editor = Editor;
})();
