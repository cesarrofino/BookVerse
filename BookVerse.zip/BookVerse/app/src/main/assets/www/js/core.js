/* BookVerse — núcleo: ponte nativa, helpers de DOM, ícones, diálogos */
(function () {
  'use strict';
  const BV = (window.BV = window.BV || {});

  /* ---------- ponte JS → Kotlin ---------- */
  let seq = 0;
  const pending = {};
  window.__bvResolve = function (id, ok, value) {
    const p = pending[id];
    if (!p) return;
    delete pending[id];
    if (ok) p.res(value); else p.rej(new Error(typeof value === 'string' ? value : 'Erro'));
  };
  BV.native = function (method, args) {
    return new Promise((res, rej) => {
      if (!window.Android) { rej(new Error('Esta função só está disponível dentro da aplicação Android.')); return; }
      const id = ++seq;
      pending[id] = { res, rej };
      try { window.Android.call(id, method, JSON.stringify(args || {})); }
      catch (e) { delete pending[id]; rej(e); }
    });
  };

  /* ---------- DOM ---------- */
  BV.h = function (tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) for (const k of Object.keys(attrs)) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'value') el.value = v;
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
    BV.append(el, kids);
    return el;
  };
  BV.append = function (el, kids) {
    for (const k of kids.flat(Infinity)) {
      if (k == null || k === false) continue;
      el.appendChild(k.nodeType ? k : document.createTextNode(String(k)));
    }
    return el;
  };
  BV.$ = (s, r) => (r || document).querySelector(s);
  BV.$$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  BV.clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };
  BV.esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  BV.uid = () => (crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); }));
  BV.shortId = () => Math.random().toString(36).slice(2, 10);
  BV.debounce = function (fn, ms) { let t; const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; d.flush = (...a) => { clearTimeout(t); fn(...a); }; d.cancel = () => clearTimeout(t); return d; };
  BV.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  BV.nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));

  /* ---------- ícones (traço) ---------- */
  const P = {
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5v14z"/><path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>', library: '<path d="M4 4h4v16H4zM10 4h4v16h-4z"/><path d="M16 6l4 1-3 13-4-1z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>', back: '<path d="M15 18l-6-6 6-6"/>', forward: '<path d="M9 18l6-6-6-6"/>',
    close: '<path d="M18 6L6 18M6 6l12 12"/>', check: '<path d="M20 6L9 17l-5-5"/>', more: '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',
    bold: '<path d="M6 4h7a4 4 0 0 1 0 8H6zM6 12h8a4 4 0 0 1 0 8H6z"/>', italic: '<path d="M19 4h-9M14 20H5M15 4L9 20"/>',
    underline: '<path d="M6 3v7a6 6 0 0 0 12 0V3M4 21h16"/>', strike: '<path d="M16 4H9a3 3 0 0 0-2.8 4M4 12h16M8 20h7a3.5 3.5 0 0 0 3-5"/>',
    alignL: '<path d="M3 6h18M3 12h12M3 18h16"/>', alignC: '<path d="M3 6h18M7 12h10M5 18h14"/>', alignR: '<path d="M3 6h18M9 12h12M5 18h16"/>', alignJ: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    ul: '<path d="M9 6h12M9 12h12M9 18h12"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/>',
    ol: '<path d="M10 6h11M10 12h11M10 18h11M4 5l1-1v4M3.5 13.5c.5-1 2.5-1 2.5 0s-2.5 1.5-2.5 2.5H6M3.5 20c1 .5 2.5.3 2.5-.8S4.8 18 4 18"/>',
    undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>', redo: '<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>', camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
    table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16M15 4v16"/>', quote: '<path d="M3 21c3 0 7-1 7-8V5H4v7h4M14 21c3 0 7-1 7-8V5h-6v7h4"/>',
    minus: '<path d="M5 12h14"/>', link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
    pagebreak: '<path d="M4 12h3M10 12h4M17 12h3"/><path d="M7 8V3h10v5M7 16v5h10v-5"/>', header: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/>',
    footer: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 15h18"/>', heading: '<path d="M6 4v16M18 4v16M6 12h12"/>',
    chapters: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>', copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    paste: '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/>',
    selectall: '<rect x="3" y="3" width="18" height="18" rx="2" stroke-dasharray="3 3"/><path d="M8 12l3 3 5-6"/>',
    trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>', duplicate: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M4 16V5a1 1 0 0 1 1-1h11"/>',
    star: '<path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/>', archive: '<rect x="3" y="3" width="18" height="5" rx="1"/><path d="M5 8v11a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8M10 12h4"/>',
    share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>', upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
    eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>', palette: '<circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.3-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.4A4.6 4.6 0 0 0 22 11c0-5-4.5-9-10-9z"/>',
    cloud: '<path d="M18 10h-1.3A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>', refresh: '<path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 15-3.4L23 10M1 14l4.5 4.4A9 9 0 0 0 20.5 15"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/>', sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>', folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    pages2: '<rect x="2" y="4" width="9" height="16" rx="1"/><rect x="13" y="4" width="9" height="16" rx="1"/>', page1: '<rect x="5" y="3" width="14" height="18" rx="1"/>',
    zoomIn: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M11 8v6M8 11h6"/>', zoomOut: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M8 11h6"/>',
    text: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>', shape: '<rect x="3" y="3" width="10" height="10" rx="1"/><circle cx="16" cy="16" r="5"/>', layers: '<path d="M12 2l10 5-10 5L2 7z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/>',
    up: '<path d="M18 15l-6-6-6 6"/>', down: '<path d="M6 9l6 6 6-6"/>', drag: '<circle cx="9" cy="6" r="1.2"/><circle cx="15" cy="6" r="1.2"/><circle cx="9" cy="12" r="1.2"/><circle cx="15" cy="12" r="1.2"/><circle cx="9" cy="18" r="1.2"/><circle cx="15" cy="18" r="1.2"/>',
    history: '<path d="M3 3v5h5"/><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/><path d="M12 7v5l4 2"/>', font: '<path d="M4 20l8-16 8 16M7 14h10"/>', fill: '<path d="M19 11L9 1 3 7l10 10z"/><path d="M5 19a2 2 0 1 0 4 0c0-1.5-2-3.5-2-3.5S5 17.5 5 19z" transform="translate(11 -1)"/>',
    highlight: '<path d="M9 11l-6 6v3h9l3-3"/><path d="M22 12l-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4"/>', indent: '<path d="M3 6h18M11 12h10M11 18h10M3 9l3 3-3 3"/>', outdent: '<path d="M3 6h18M11 12h10M11 18h10M6 9l-3 3 3 3"/>',
    lineh: '<path d="M21 6H10M21 12H10M21 18H10M5 4v16M3 6l2-2 2 2M3 18l2 2 2-2"/>', book2: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    sparkle: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4"/>', logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>', mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 6L2 7"/>',
    github: '<path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.9a3.4 3.4 0 0 0-1-2.6c3.1-.3 6.4-1.5 6.4-7a5.4 5.4 0 0 0-1.5-3.7 5 5 0 0 0-.1-3.7s-1.2-.3-3.9 1.5a13.4 13.4 0 0 0-7 0C6.2 2.8 5 3.1 5 3.1a5 5 0 0 0-.1 3.7A5.4 5.4 0 0 0 3.5 10.5c0 5.4 3.3 6.6 6.4 7a3.4 3.4 0 0 0-1 2.6V22"/>',
    flip: '<path d="M3 7h13l-3-3M21 17H8l3 3"/>', rotate: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5"/>', front: '<path d="M12 2l10 5-10 5L2 7z"/>', align: '<path d="M4 4v16M20 4v16M8 8h8v8H8z"/>', cog: '<circle cx="12" cy="12" r="3"/>'
  };
  BV.icon = function (name, cls) {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'ic' + (cls ? ' ' + cls : ''));
    s.setAttribute('aria-hidden', 'true');
    s.innerHTML = P[name] || P.cog;
    return s;
  };
  BV.hasIcon = (n) => !!P[n];

  /* ---------- avisos e diálogos ---------- */
  BV.toast = function (msg, type) {
    const box = document.getElementById('toasts');
    const el = BV.h('div', { class: 'toast ' + (type || '') }, msg);
    box.appendChild(el);
    setTimeout(() => { el.style.transition = 'opacity .3s'; el.style.opacity = '0'; setTimeout(() => el.remove(), 320); }, type === 'error' ? 4800 : 2600);
  };
  BV.error = (e) => { console.error(e); BV.toast((e && e.message) || String(e), 'error'); };

  BV.modal = function (opts) {
    const close = (v) => { ov.remove(); if (opts.onClose) opts.onClose(v); };
    const body = BV.h('div', { class: 'modal-b' }, opts.body);
    const modal = BV.h('div', { class: 'modal', role: 'dialog' },
      BV.h('div', { class: 'modal-h' }, BV.h('h3', null, opts.title || ''), BV.h('button', { class: 'icon-btn', 'aria-label': 'Fechar', onclick: () => close(null) }, BV.icon('close'))),
      body,
      opts.actions && opts.actions.length ? BV.h('div', { class: 'modal-f' }, opts.actions.map((a) =>
        BV.h('button', { class: 'btn ' + (a.primary ? 'primary' : a.danger ? 'danger' : ''), onclick: async () => { if (a.onClick) { const r = await a.onClick(close); if (r === false) return; } if (!a.keepOpen) close(a.value); } }, a.label))) : null);
    const ov = BV.h('div', { class: 'overlay', onclick: (e) => { if (e.target === ov && !opts.persistent) close(null); } }, modal);
    ov.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(null); });
    document.body.appendChild(ov);
    BV._modals = (BV._modals || []); BV._modals.push({ ov, close });
    const rm = ov.remove.bind(ov); ov.remove = () => { BV._modals = BV._modals.filter((m) => m.ov !== ov); rm(); };
    return { close, el: modal, body };
  };
  BV.closeTopModal = function () {
    const m = (BV._modals || []).slice(-1)[0];
    if (m) { m.close(null); return true; }
    return false;
  };

  BV.confirm = (msg, opts) => new Promise((res) => {
    opts = opts || {};
    BV.modal({ title: opts.title || BV.t('Confirmar'), body: BV.h('p', { style: { margin: '4px 0 8px', color: 'var(--text-2)' } }, msg),
      actions: [{ label: BV.t('Cancelar'), value: false }, { label: opts.ok || BV.t('Confirmar'), primary: !opts.danger, danger: !!opts.danger, value: true }],
      onClose: (v) => res(v === true) });
  });

  BV.prompt = (label, value, opts) => new Promise((res) => {
    opts = opts || {};
    const input = BV.h('input', { class: 'input', value: value || '', placeholder: opts.placeholder || '', type: opts.type || 'text' });
    const m = BV.modal({ title: opts.title || label, body: BV.h('div', { class: 'field' }, opts.title ? BV.h('label', null, label) : null, input),
      actions: [{ label: BV.t('Cancelar'), value: null }, { label: opts.ok || 'OK', primary: true, onClick: (close) => { close(input.value); return false; } }],
      onClose: (v) => res(v) });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { m.close(input.value); } });
    setTimeout(() => { input.focus(); input.select(); }, 60);
  });

  /** Lista de ações numa folha. items: [{icon,label,sub,danger,onClick}] */
  BV.menu = function (title, items) {
    let m;
    const list = BV.h('div', { class: 'menu-list' }, items.filter(Boolean).map((it) =>
      BV.h('button', { class: 'menu-item' + (it.danger ? ' danger' : ''), onclick: () => { m.close(); setTimeout(() => it.onClick && it.onClick(), 30); } },
        it.icon ? BV.icon(it.icon) : null, BV.h('span', null, it.label, it.sub ? BV.h('small', null, it.sub) : null))));
    m = BV.modal({ title, body: list });
    return m;
  };

  BV.busy = function (msg) {
    const el = BV.h('div', { class: 'busy' }, BV.h('div', { class: 'spinner' }), BV.h('div', null, msg || ''));
    document.body.appendChild(el);
    return { update: (m) => { el.lastChild.textContent = m; }, done: () => el.remove() };
  };

  /* ---------- formatação ---------- */
  BV.fmtDate = function (ts) {
    if (!ts) return '';
    const d = new Date(ts), now = new Date();
    const diff = (now - d) / 1000;
    if (diff < 60) return BV.t('agora mesmo');
    if (diff < 3600) return BV.t('há') + ' ' + Math.floor(diff / 60) + ' min';
    if (d.toDateString() === now.toDateString()) return BV.t('hoje') + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return d.toLocaleDateString(BV.lang === 'en' ? 'en-GB' : 'pt-PT', { day: '2-digit', month: 'short', year: 'numeric' });
  };
  BV.fmtBytes = function (n) {
    if (!n) return '0 B';
    const u = ['B', 'KB', 'MB', 'GB']; let i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return n.toFixed(i ? 1 : 0) + ' ' + u[i];
  };
  BV.fmtNum = (n) => (n || 0).toLocaleString(BV.lang === 'en' ? 'en-GB' : 'pt-PT');

  BV.t = (s) => (BV.dict && BV.lang !== 'pt' && BV.dict[BV.lang] && BV.dict[BV.lang][s]) || s;
  BV.lang = 'pt';
})();
