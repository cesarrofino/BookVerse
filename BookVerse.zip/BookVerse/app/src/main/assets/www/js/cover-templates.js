/* BookVerse — modelos de capa por categoria literária (gerados por código, sem imagens externas) */
(function () {
  'use strict';
  const BV = window.BV, C = BV.cover;
  const T = C.newText, S = C.newShape;

  const fit = (str, base) => { const n = (str || '').length; return Math.round(base * (n <= 12 ? 1 : n <= 24 ? 0.8 : n <= 40 ? 0.64 : 0.5)); };
  const titleOf = (c) => c.title || 'Título do livro';

  function std(c, o) {
    // elementos de texto padrão: título, subtítulo, autor
    const w = c.w, h = c.h, els = [];
    els.push(T({ id: 'title', role: 'title', x: w * 0.1, y: h * o.ty, w: w * 0.8, h: h * (o.th || 0.22), text: titleOf(c), font: o.font || 'serif', size: fit(titleOf(c), o.size || 130), color: o.color, bold: o.bold !== false, italic: !!o.italic, upper: !!o.upper, spacing: o.spacing || 0, shadow: !!o.shadow, outline: !!o.outline, outlineColor: o.outlineColor || '#000', lineH: 1.08, align: o.align || 'center' }));
    if (c.subtitle) els.push(T({ id: 'subtitle', role: 'subtitle', x: w * 0.12, y: h * (o.ty + (o.th || 0.22) + 0.01), w: w * 0.76, h: h * 0.08, text: c.subtitle, font: o.subFont || o.font || 'serif', size: Math.round(w * 0.04), color: o.sub || o.color, italic: true, align: o.align || 'center', valign: 'top', opacity: 0.9 }));
    els.push(T({ id: 'author', role: 'author', x: w * 0.1, y: h * (o.ay || 0.86), w: w * 0.8, h: h * 0.07, text: c.author || 'Nome do autor', font: o.authorFont || 'sans-serif', size: Math.round(w * 0.045), color: o.authorColor || o.color, upper: true, spacing: 6, bold: true, align: o.align || 'center' }));
    return els;
  }
  const mk = (c, bg, fx, shapes, textOpts, tail) => {
    const d = C.newDesign(c.w, c.h);
    d.bg = bg; d.fx = Object.assign({ vignette: 0, blur: 0, gray: false, tint: '', tintAlpha: 0 }, fx || {});
    d.els = [].concat(shapes || [], std(c, textOpts), tail || []);
    return d;
  };


  /** Coração feito com um quadrado rodado e dois círculos. */
  const heart = (cx, cy, sz, fill, o) => {
    const k = 0.3536 * sz, opt = Object.assign({ fill }, o || {});
    return [
      S(Object.assign({ shape: 'rect', x: cx - sz / 2, y: cy - sz / 2, w: sz, h: sz, rot: 45 }, opt)),
      S(Object.assign({ shape: 'circle', x: cx - k - sz / 2, y: cy - k - sz / 2, w: sz, h: sz }, opt)),
      S(Object.assign({ shape: 'circle', x: cx + k - sz / 2, y: cy - k - sz / 2, w: sz, h: sz }, opt))];
  };
  const dots = (c, n, seed, col, minS, maxS) => Array.from({ length: n }, (_, i) => {
    const a = Math.sin((i + seed) * 12.9898) * 43758.5453, b = Math.sin((i + seed) * 78.233) * 12345.6789, d = Math.sin((i + seed) * 37.719) * 9631.12;
    const rx = a - Math.floor(a), ry = b - Math.floor(b), rs = d - Math.floor(d);
    const sz = minS + rs * (maxS - minS);
    return S({ shape: i % 4 === 0 ? 'star' : 'circle', x: rx * (c.w - sz), y: ry * (c.h - sz), w: sz, h: sz, fill: Array.isArray(col) ? col[i % col.length] : col, opacity: 0.5 + (i % 3) * 0.2 });
  });

  const LIST = [
    { id: 'rose', name: 'Rosa', category: 'Romance', make: (c) => mk(c, { type: 'gradient', from: '#9d174d', to: '#fb7185', angle: 160 }, { vignette: 0.25 }, [
      S({ shape: 'circle', x: c.w * 0.18, y: c.h * 0.14, w: c.w * 0.64, h: c.w * 0.64, fill: '#ffffff', opacity: 0.14 }),
      S({ shape: 'ring', x: c.w * 0.1, y: c.h * 0.08, w: c.w * 0.8, h: c.w * 0.8, fill: '#ffffff', strokeW: 6, opacity: 0.5 }),
      S({ shape: 'star', x: c.w * 0.44, y: c.h * 0.38, w: c.w * 0.12, h: c.w * 0.12, fill: '#ffe4e6', opacity: 0.9 })], { ty: 0.6, font: 'cursive', size: 150, color: '#fff1f2', shadow: true, bold: false, ay: 0.9 }) },
    { id: 'noir-romance', name: 'Paixão', category: 'Romance', make: (c) => mk(c, { type: 'gradient', from: '#1f0a14', to: '#7f1d1d', angle: 180 }, { vignette: 0.4 }, [
      S({ shape: 'rect', x: c.w * 0.07, y: c.h * 0.05, w: c.w * 0.86, h: c.h * 0.9, fill: 'rgba(0,0,0,0)', stroke: '#fda4af', strokeW: 4, fill2: '' }),
      S({ shape: 'diamond', x: c.w * 0.44, y: c.h * 0.3, w: c.w * 0.12, h: c.w * 0.16, fill: '#fb7185' })], { ty: 0.45, font: 'serif', italic: true, size: 140, color: '#ffe4e6', ay: 0.85, authorColor: '#fda4af' }) },
    { id: 'classic', name: 'Clássico', category: 'Ficção', make: (c) => mk(c, { type: 'solid', color: '#10243e' }, { vignette: 0.3 }, [
      S({ shape: 'rect', x: c.w * 0.06, y: c.h * 0.04, w: c.w * 0.88, h: c.h * 0.92, fill: 'rgba(0,0,0,0)', stroke: '#d4af37', strokeW: 5 }),
      S({ shape: 'rect', x: c.w * 0.09, y: c.h * 0.07, w: c.w * 0.82, h: c.h * 0.86, fill: 'rgba(0,0,0,0)', stroke: '#d4af37', strokeW: 2 }),
      S({ shape: 'line', x: c.w * 0.3, y: c.h * 0.58, w: c.w * 0.4, h: 12, fill: '#d4af37', strokeW: 4 })], { ty: 0.3, font: 'serif', size: 140, color: '#f5e6b3', ay: 0.8, authorColor: '#d4af37' }) },
    { id: 'modern-fiction', name: 'Moderno', category: 'Ficção', make: (c) => mk(c, { type: 'solid', color: '#f8fafc' }, {}, [
      S({ shape: 'rect', x: 0, y: 0, w: c.w, h: c.h * 0.55, fill: '#2563eb', fill2: '#1e3a8a', angle: 160 }),
      S({ shape: 'circle', x: c.w * 0.55, y: c.h * 0.32, w: c.w * 0.5, h: c.w * 0.5, fill: '#f59e0b' })], { ty: 0.62, font: 'sans-serif', size: 120, color: '#0f172a', ay: 0.9, authorColor: '#334155', align: 'left' }) },
    { id: 'fantasy', name: 'Reino Místico', category: 'Fantasia', make: (c) => mk(c, { type: 'gradient', from: '#312e81', to: '#0f0a2e', angle: 170 }, { vignette: 0.45 }, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.1, w: c.w * 0.6, h: c.w * 0.6, fill: '#a78bfa', fill2: '#4c1d95', angle: 140, opacity: 0.55 }),
      S({ shape: 'ring', x: c.w * 0.12, y: c.h * 0.05, w: c.w * 0.76, h: c.w * 0.76, fill: '#fde68a', strokeW: 4, opacity: 0.8 }),
      S({ shape: 'star', x: c.w * 0.08, y: c.h * 0.4, w: c.w * 0.06, h: c.w * 0.06, fill: '#fde68a' }), S({ shape: 'star', x: c.w * 0.86, y: c.h * 0.28, w: c.w * 0.05, h: c.w * 0.05, fill: '#fde68a' }),
      S({ shape: 'star', x: c.w * 0.72, y: c.h * 0.5, w: c.w * 0.04, h: c.w * 0.04, fill: '#ffffff' })], { ty: 0.56, font: 'serif', size: 150, color: '#fde68a', shadow: true, upper: true, spacing: 3, ay: 0.89, authorColor: '#ddd6fe' }) },
    { id: 'horror', name: 'Pesadelo', category: 'Terror', make: (c) => mk(c, { type: 'solid', color: '#050505' }, { vignette: 0.85 }, [
      S({ shape: 'triangle', x: c.w * 0.25, y: c.h * 0.12, w: c.w * 0.5, h: c.w * 0.55, fill: '#7f1d1d', fill2: '#050505', angle: 180 }),
      S({ shape: 'circle', x: c.w * 0.42, y: c.h * 0.36, w: c.w * 0.16, h: c.w * 0.16, fill: '#dc2626' })], { ty: 0.56, font: 'serif', size: 150, color: '#dc2626', upper: true, spacing: 4, shadow: true, ay: 0.9, authorColor: '#d4d4d4' }) },
    { id: 'suspense', name: 'Sombra', category: 'Suspense', make: (c) => mk(c, { type: 'gradient', from: '#111827', to: '#374151', angle: 200 }, { vignette: 0.5 }, [
      S({ shape: 'rect', x: -c.w * 0.1, y: c.h * 0.2, w: c.w * 1.3, h: c.h * 0.06, fill: '#facc15', rot: -12 }),
      S({ shape: 'rect', x: -c.w * 0.1, y: c.h * 0.3, w: c.w * 1.3, h: c.h * 0.02, fill: '#facc15', rot: -12, opacity: 0.6 })], { ty: 0.45, font: 'sans-serif-condensed', size: 170, color: '#f9fafb', upper: true, spacing: 5, ay: 0.88, authorColor: '#facc15' }) },
    { id: 'biography', name: 'Retrato', category: 'Biografia', make: (c) => mk(c, { type: 'solid', color: '#f3ead8' }, {}, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.08, w: c.w * 0.6, h: c.w * 0.6, fill: '#d6c3a0', stroke: '#7c5e2f', strokeW: 8 }),
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.75, w: c.w * 0.8, h: 6, fill: '#7c5e2f' })], { ty: 0.52, font: 'serif', size: 130, color: '#3f2d12', ay: 0.8, authorColor: '#7c5e2f' }) },
    { id: 'education', name: 'Saber', category: 'Educação', make: (c) => mk(c, { type: 'solid', color: '#0ea5e9' }, {}, [
      S({ shape: 'rect', x: 0, y: 0, w: c.w, h: c.h * 0.12, fill: '#075985' }), S({ shape: 'rect', x: 0, y: c.h * 0.88, w: c.w, h: c.h * 0.12, fill: '#075985' }),
      S({ shape: 'round', x: c.w * 0.08, y: c.h * 0.2, w: c.w * 0.84, h: c.h * 0.42, fill: '#ffffff', opacity: 0.95 })], { ty: 0.26, th: 0.3, font: 'sans-serif', size: 120, color: '#075985', ay: 0.9, authorColor: '#e0f2fe' }) },
    { id: 'tech', name: 'Circuito', category: 'Tecnologia', make: (c) => {
      const lines = []; for (let i = 0; i < 9; i++) lines.push(S({ shape: 'rect', x: 0, y: c.h * (0.08 + i * 0.045), w: c.w * (0.3 + 0.07 * ((i * 5) % 7)), h: 6, fill: '#22d3ee', opacity: 0.55 }));
      lines.push(S({ shape: 'circle', x: c.w * 0.72, y: c.h * 0.1, w: c.w * 0.18, h: c.w * 0.18, fill: '#22d3ee', opacity: 0.25 }));
      return mk(c, { type: 'gradient', from: '#020617', to: '#0f172a', angle: 160 }, { vignette: 0.3 }, lines, { ty: 0.5, font: 'monospace', size: 120, color: '#e0f2fe', align: 'left', ay: 0.88, authorColor: '#22d3ee' }); } },
    { id: 'selfhelp', name: 'Amanhecer', category: 'Desenvolvimento pessoal', make: (c) => mk(c, { type: 'gradient', from: '#f97316', to: '#fde047', angle: 0 }, {}, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.58, w: c.w * 0.6, h: c.w * 0.6, fill: '#fff7ed', opacity: 0.85 }),
      S({ shape: 'rect', x: 0, y: c.h * 0.78, w: c.w, h: c.h * 0.22, fill: '#7c2d12' })], { ty: 0.12, font: 'sans-serif', size: 150, color: '#7c2d12', upper: true, ay: 0.87, authorColor: '#ffedd5' }) },
    { id: 'poetry', name: 'Verso', category: 'Poesia', make: (c) => mk(c, { type: 'solid', color: '#fbf8f1' }, {}, [
      S({ shape: 'ring', x: c.w * 0.15, y: c.h * 0.15, w: c.w * 0.7, h: c.w * 0.7, fill: '#9ca3af', strokeW: 3 }),
      S({ shape: 'line', x: c.w * 0.4, y: c.h * 0.62, w: c.w * 0.2, h: 12, fill: '#9ca3af', strokeW: 3 })], { ty: 0.34, th: 0.2, font: 'serif', italic: true, bold: false, size: 130, color: '#1f2937', ay: 0.8, authorColor: '#6b7280' }) },
    { id: 'history', name: 'Pergaminho', category: 'História', make: (c) => mk(c, { type: 'gradient', from: '#78350f', to: '#451a03', angle: 180 }, { vignette: 0.55 }, [
      S({ shape: 'rect', x: c.w * 0.07, y: c.h * 0.05, w: c.w * 0.86, h: c.h * 0.9, fill: 'rgba(0,0,0,0)', stroke: '#fcd34d', strokeW: 4 }),
      S({ shape: 'diamond', x: c.w * 0.45, y: c.h * 0.1, w: c.w * 0.1, h: c.w * 0.14, fill: '#fcd34d' })], { ty: 0.34, font: 'serif', size: 140, color: '#fef3c7', upper: true, spacing: 3, ay: 0.82, authorColor: '#fcd34d' }) },
    { id: 'religion', name: 'Luz', category: 'Religião', make: (c) => mk(c, { type: 'gradient', from: '#1e3a8a', to: '#0b1226', angle: 180 }, { vignette: 0.3 }, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.06, w: c.w * 0.6, h: c.w * 0.6, fill: '#fde68a', opacity: 0.2 }),
      S({ shape: 'rect', x: c.w * 0.47, y: c.h * 0.12, w: c.w * 0.06, h: c.h * 0.26, fill: '#fcd34d' }), S({ shape: 'rect', x: c.w * 0.36, y: c.h * 0.19, w: c.w * 0.28, h: c.w * 0.06, fill: '#fcd34d' })], { ty: 0.5, font: 'serif', size: 140, color: '#fef3c7', ay: 0.86, authorColor: '#fcd34d' }) },
    { id: 'minimal', name: 'Minimalista', category: 'Outros', make: (c) => mk(c, { type: 'solid', color: '#ffffff' }, {}, [
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.1, w: c.w * 0.14, h: c.h * 0.34, fill: '#2563eb' })], { ty: 0.5, font: 'sans-serif', size: 130, color: '#111827', align: 'left', ay: 0.88, authorColor: '#2563eb' }) },
    { id: 'bold-blue', name: 'Azul Intenso', category: 'Outros', make: (c) => mk(c, { type: 'gradient', from: '#1d4ed8', to: '#0b1226', angle: 160 }, { vignette: 0.3 }, [
      S({ shape: 'circle', x: c.w * 0.5, y: -c.h * 0.05, w: c.w * 0.7, h: c.w * 0.7, fill: '#60a5fa', opacity: 0.3 }),
      S({ shape: 'triangle', x: c.w * 0.05, y: c.h * 0.55, w: c.w * 0.3, h: c.w * 0.3, fill: '#93c5fd', opacity: 0.35 })], { ty: 0.38, font: 'sans-serif', size: 140, color: '#ffffff', upper: true, ay: 0.88, authorColor: '#bfdbfe' }) },
    { id: 'sunset', name: 'Pôr do Sol', category: 'Romance', make: (c) => mk(c, { type: 'gradient', from: '#7c3aed', to: '#fb923c', angle: 180 }, { vignette: 0.2 }, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.3, w: c.w * 0.6, h: c.w * 0.6, fill: '#fde68a', fill2: '#fb7185', angle: 180 }),
      S({ shape: 'rect', x: 0, y: c.h * 0.58, w: c.w, h: c.h * 0.42, fill: '#1e1b4b', fill2: '#0b0a2a', angle: 180 }),
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.6, w: c.w * 0.8, h: 4, fill: '#fda4af', opacity: 0.7 })], { ty: 0.68, font: 'serif', italic: true, size: 135, color: '#fff7ed', ay: 0.9, authorColor: '#fdba74', shadow: true }) },
    { id: 'ocean', name: 'Oceano', category: 'Ficção', make: (c) => mk(c, { type: 'gradient', from: '#0e7490', to: '#082f49', angle: 180 }, { vignette: 0.3 }, [
      S({ shape: 'ring', x: c.w * -0.2, y: c.h * 0.55, w: c.w * 1.4, h: c.w * 1.4, fill: '#67e8f9', strokeW: 5, opacity: 0.35 }),
      S({ shape: 'ring', x: c.w * -0.05, y: c.h * 0.62, w: c.w * 1.1, h: c.w * 1.1, fill: '#67e8f9', strokeW: 4, opacity: 0.3 }),
      S({ shape: 'ring', x: c.w * 0.1, y: c.h * 0.7, w: c.w * 0.8, h: c.w * 0.8, fill: '#67e8f9', strokeW: 3, opacity: 0.25 }),
      S({ shape: 'circle', x: c.w * 0.7, y: c.h * 0.08, w: c.w * 0.16, h: c.w * 0.16, fill: '#e0f2fe', opacity: 0.85 })], { ty: 0.25, font: 'sans-serif', size: 125, color: '#ecfeff', upper: true, spacing: 4, ay: 0.9, authorColor: '#a5f3fc' }) },
    { id: 'forest', name: 'Floresta', category: 'Fantasia', make: (c) => mk(c, { type: 'gradient', from: '#065f46', to: '#022c22', angle: 180 }, { vignette: 0.45 }, [
      S({ shape: 'circle', x: c.w * 0.58, y: c.h * 0.06, w: c.w * 0.26, h: c.w * 0.26, fill: '#fef9c3', opacity: 0.9 }),
      S({ shape: 'triangle', x: c.w * 0.02, y: c.h * 0.5, w: c.w * 0.4, h: c.h * 0.4, fill: '#064e3b' }),
      S({ shape: 'triangle', x: c.w * 0.26, y: c.h * 0.56, w: c.w * 0.36, h: c.h * 0.34, fill: '#047857', opacity: 0.9 }),
      S({ shape: 'triangle', x: c.w * 0.54, y: c.h * 0.48, w: c.w * 0.44, h: c.h * 0.42, fill: '#064e3b' }),
      S({ shape: 'rect', x: 0, y: c.h * 0.88, w: c.w, h: c.h * 0.12, fill: '#022c22' })], { ty: 0.14, font: 'serif', size: 135, color: '#ecfccb', ay: 0.92, authorColor: '#bef264', shadow: true }) },
    { id: 'neon', name: 'Neon', category: 'Tecnologia', make: (c) => mk(c, { type: 'solid', color: '#0b0221' }, { vignette: 0.35 }, [
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.12, w: c.w * 0.8, h: 8, fill: '#f0abfc' }),
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.12, w: c.w * 0.8, h: 28, fill: '#e879f9', opacity: 0.25 }),
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.78, w: c.w * 0.8, h: 8, fill: '#22d3ee' }),
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.78 - 20, w: c.w * 0.8, h: 28, fill: '#22d3ee', opacity: 0.25 }),
      S({ shape: 'ring', x: c.w * 0.3, y: c.h * 0.26, w: c.w * 0.4, h: c.w * 0.4, fill: '#22d3ee', strokeW: 8, opacity: 0.8 })], { ty: 0.5, font: 'sans-serif', size: 120, color: '#f5d0fe', upper: true, spacing: 5, shadow: true, ay: 0.88, authorColor: '#67e8f9' }) },
    { id: 'gold-luxe', name: 'Ouro e Preto', category: 'Ficção', make: (c) => mk(c, { type: 'solid', color: '#0a0a0a' }, { vignette: 0.2 }, [
      S({ shape: 'rect', x: c.w * 0.08, y: c.h * 0.06, w: c.w * 0.84, h: c.h * 0.88, fill: 'rgba(0,0,0,0)', stroke: '#c9a227', strokeW: 3 }),
      S({ shape: 'diamond', x: c.w * 0.44, y: c.h * 0.16, w: c.w * 0.12, h: c.w * 0.16, fill: '#c9a227', fill2: '#f5e08a', angle: 90 }),
      S({ shape: 'line', x: c.w * 0.25, y: c.h * 0.62, w: c.w * 0.5, h: 10, fill: '#c9a227', strokeW: 3 })], { ty: 0.34, font: 'serif', size: 130, color: '#f5e08a', upper: true, spacing: 6, ay: 0.78, authorColor: '#c9a227' }) },
    { id: 'pastel', name: 'Pastel', category: 'Poesia', make: (c) => mk(c, { type: 'solid', color: '#fde2e4' }, {}, [
      S({ shape: 'circle', x: c.w * 0.05, y: c.h * 0.06, w: c.w * 0.5, h: c.w * 0.5, fill: '#bde0fe', opacity: 0.9 }),
      S({ shape: 'circle', x: c.w * 0.45, y: c.h * 0.18, w: c.w * 0.45, h: c.w * 0.45, fill: '#cdb4db', opacity: 0.85 }),
      S({ shape: 'circle', x: c.w * 0.25, y: c.h * 0.3, w: c.w * 0.32, h: c.w * 0.32, fill: '#ffc8dd', opacity: 0.9 })], { ty: 0.62, font: 'cursive', size: 150, color: '#5b4b6b', bold: false, ay: 0.9, authorColor: '#8b6f9c' }) },
    { id: 'blood-moon', name: 'Lua Sangrenta', category: 'Terror', make: (c) => mk(c, { type: 'gradient', from: '#1a0505', to: '#000000', angle: 180 }, { vignette: 0.7 }, [
      S({ shape: 'circle', x: c.w * 0.15, y: c.h * 0.1, w: c.w * 0.7, h: c.w * 0.7, fill: '#b91c1c', fill2: '#450a0a', angle: 135 }),
      S({ shape: 'triangle', x: c.w * 0.0, y: c.h * 0.62, w: c.w * 0.5, h: c.h * 0.3, fill: '#000000' }),
      S({ shape: 'triangle', x: c.w * 0.4, y: c.h * 0.66, w: c.w * 0.6, h: c.h * 0.26, fill: '#000000' })], { ty: 0.62, font: 'serif', size: 140, color: '#fecaca', upper: true, spacing: 3, shadow: true, ay: 0.92, authorColor: '#ef4444' }) },
    { id: 'geo', name: 'Geométrico', category: 'Educação', make: (c) => mk(c, { type: 'solid', color: '#ffffff' }, {}, [
      S({ shape: 'rect', x: 0, y: 0, w: c.w * 0.5, h: c.h * 0.36, fill: '#2563eb' }),
      S({ shape: 'circle', x: c.w * 0.5, y: 0, w: c.w * 0.5, h: c.w * 0.5, fill: '#f59e0b' }),
      S({ shape: 'triangle', x: 0, y: c.h * 0.36, w: c.w * 0.5, h: c.w * 0.5, fill: '#ef4444' }),
      S({ shape: 'rect', x: c.w * 0.5, y: c.w * 0.5, w: c.w * 0.5, h: c.h * 0.14, fill: '#10b981' })], { ty: 0.62, font: 'sans-serif', size: 120, color: '#111827', align: 'left', ay: 0.9, authorColor: '#2563eb' }) },
    { id: 'split', name: 'Contraste', category: 'Biografia', make: (c) => mk(c, { type: 'solid', color: '#111827' }, {}, [
      S({ shape: 'rect', x: c.w * 0.08, y: c.h * 0.08, w: c.w * 0.84, h: c.h * 0.5, fill: '#f3ead8' }),
      S({ shape: 'rect', x: c.w * 0.14, y: c.h * 0.14, w: c.w * 0.72, h: c.h * 0.38, fill: 'rgba(0,0,0,0)', stroke: '#111827', strokeW: 3 })], { ty: 0.66, font: 'serif', size: 125, color: '#f3ead8', ay: 0.9, authorColor: '#d6c7a1', align: 'left' }) },
    { id: 'dawn', name: 'Aurora', category: 'Desenvolvimento pessoal', make: (c) => mk(c, { type: 'gradient', from: '#0ea5e9', to: '#a78bfa', angle: 160 }, { vignette: 0.15 }, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.58, w: c.w * 0.6, h: c.w * 0.6, fill: '#fef3c7', opacity: 0.55 }),
      S({ shape: 'circle', x: c.w * 0.3, y: c.h * 0.64, w: c.w * 0.4, h: c.w * 0.4, fill: '#fde68a', opacity: 0.8 })], { ty: 0.18, font: 'sans-serif', size: 135, color: '#ffffff', shadow: true, ay: 0.9, authorColor: '#f0f9ff' }) },
    { id: 'kraft', name: 'Papel Kraft', category: 'História', make: (c) => mk(c, { type: 'solid', color: '#cdae7c' }, { vignette: 0.35 }, [
      S({ shape: 'rect', x: c.w * 0.07, y: c.h * 0.05, w: c.w * 0.86, h: c.h * 0.9, fill: 'rgba(0,0,0,0)', stroke: '#5b3a1a', strokeW: 4 }),
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.08, w: c.w * 0.8, h: c.h * 0.84, fill: 'rgba(0,0,0,0)', stroke: '#5b3a1a', strokeW: 1.5 }),
      S({ shape: 'star', x: c.w * 0.44, y: c.h * 0.58, w: c.w * 0.12, h: c.w * 0.12, fill: '#5b3a1a' })], { ty: 0.25, font: 'serif', size: 135, color: '#3b2410', upper: true, spacing: 4, ay: 0.8, authorColor: '#5b3a1a' }) },
    { id: 'mono', name: 'Preto e Branco', category: 'Outros', make: (c) => mk(c, { type: 'solid', color: '#0a0a0a' }, {}, [
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.1, w: c.w * 0.8, h: 10, fill: '#ffffff' }),
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.84, w: c.w * 0.8, h: 10, fill: '#ffffff' })], { ty: 0.14, th: 0.4, font: 'sans-serif', size: 150, color: '#ffffff', upper: true, align: 'left', spacing: 2, ay: 0.88, authorColor: '#d4d4d4' }) },
    { id: 'galaxy', name: 'Galáxia', category: 'Fantasia', make: (c) => mk(c, { type: 'gradient', from: '#020617', to: '#4c1d95', angle: 200 }, { vignette: 0.4 },
      Array.from({ length: 34 }, (_, i) => {
        const a = Math.sin(i * 12.9898) * 43758.5453, b = Math.sin(i * 78.233) * 12345.6789;
        const rx = a - Math.floor(a), ry = b - Math.floor(b), sz = 4 + (i % 4) * 4;
        return S({ shape: i % 5 === 0 ? 'star' : 'circle', x: rx * c.w * 0.94, y: ry * c.h * 0.94, w: sz, h: sz, fill: '#ffffff', opacity: 0.4 + (i % 3) * 0.2 });
      }).concat([S({ shape: 'ring', x: c.w * 0.18, y: c.h * 0.12, w: c.w * 0.64, h: c.w * 0.64, fill: '#c4b5fd', strokeW: 4, opacity: 0.6 }),
        S({ shape: 'circle', x: c.w * 0.33, y: c.h * 0.12 + c.w * 0.15, w: c.w * 0.34, h: c.w * 0.34, fill: '#7c3aed', fill2: '#f0abfc', angle: 135, opacity: 0.9 })]), { ty: 0.58, font: 'sans-serif', size: 125, color: '#ede9fe', upper: true, spacing: 4, shadow: true, ay: 0.9, authorColor: '#c4b5fd' }) },
    { id: 'wave', name: 'Ondas', category: 'Outros', make: (c) => mk(c, { type: 'gradient', from: '#f97316', to: '#be123c', angle: 160 }, { vignette: 0.2 },
      [0, 1, 2, 3, 4].map((i) => S({ shape: 'ring', x: c.w * (0.5 - 0.22 - i * 0.09), y: c.h * (0.2 - i * 0.02), w: c.w * (0.44 + i * 0.18), h: c.w * (0.44 + i * 0.18), fill: '#ffffff', strokeW: 4, opacity: 0.5 - i * 0.08 })), { ty: 0.6, font: 'sans-serif', size: 135, color: '#fff7ed', shadow: true, ay: 0.9, authorColor: '#fed7aa' }) },

    /* ---- Romance ---- */
    { id: 'love-letter', name: 'Carta de Amor', category: 'Romance', make: (c) => mk(c, { type: 'solid', color: '#fdf2e9' }, { vignette: 0.15 }, [
      S({ shape: 'rect', x: c.w * 0.07, y: c.h * 0.05, w: c.w * 0.86, h: c.h * 0.9, fill: 'rgba(0,0,0,0)', stroke: '#b91c1c', strokeW: 3 })].concat(heart(c.w / 2, c.h * 0.3, c.w * 0.26, '#dc2626', { opacity: 0.95 })), { ty: 0.55, font: 'cursive', size: 150, color: '#7f1d1d', bold: false, ay: 0.88, authorColor: '#b91c1c' }) },
    { id: 'rose-gold', name: 'Rosé Dourado', category: 'Romance', make: (c) => mk(c, { type: 'gradient', from: '#fbcfe8', to: '#e9a7b8', angle: 160 }, { vignette: 0.12 }, [
      S({ shape: 'ring', x: c.w * 0.12, y: c.h * 0.1, w: c.w * 0.76, h: c.w * 0.76, fill: '#b8860b', strokeW: 4, opacity: 0.8 }),
      S({ shape: 'ring', x: c.w * 0.16, y: c.h * 0.1 + c.w * 0.04, w: c.w * 0.68, h: c.w * 0.68, fill: '#b8860b', strokeW: 2, opacity: 0.6 }),
      S({ shape: 'line', x: c.w * 0.3, y: c.h * 0.7, w: c.w * 0.4, h: 10, fill: '#b8860b', strokeW: 3 })], { ty: 0.76, th: 0.14, font: 'serif', italic: true, size: 120, color: '#5b2335', ay: 0.9, authorColor: '#8a5a1f' }) },
    { id: 'romance-night', name: 'Noite a Dois', category: 'Romance', make: (c) => mk(c, { type: 'gradient', from: '#0f172a', to: '#4c1d95', angle: 180 }, { vignette: 0.3 },
      dots(c, 22, 3, '#ffffff', 5, 14).concat([
        S({ shape: 'circle', x: c.w * 0.18, y: c.h * 0.16, w: c.w * 0.38, h: c.w * 0.38, fill: '#f9a8d4', opacity: 0.85 }),
        S({ shape: 'circle', x: c.w * 0.44, y: c.h * 0.16, w: c.w * 0.38, h: c.w * 0.38, fill: '#c4b5fd', opacity: 0.85 })]), { ty: 0.56, font: 'serif', italic: true, size: 135, color: '#fdf2f8', shadow: true, ay: 0.9, authorColor: '#f9a8d4' }) },
    { id: 'red-passion', name: 'Coração Vermelho', category: 'Romance', make: (c) => mk(c, { type: 'solid', color: '#7f1d1d' }, { vignette: 0.45 },
      heart(c.w / 2, c.h * 0.3, c.w * 0.4, '#fecaca', { opacity: 0.25 }).concat(heart(c.w / 2, c.h * 0.3, c.w * 0.26, '#fff1f2')), { ty: 0.56, font: 'serif', size: 140, color: '#fff1f2', upper: true, spacing: 3, ay: 0.9, authorColor: '#fecaca' }) },
    { id: 'blush', name: 'Rubor', category: 'Romance', make: (c) => mk(c, { type: 'solid', color: '#ffe4e6' }, {}, [
      S({ shape: 'circle', x: c.w * 0.1, y: c.h * 0.08, w: c.w * 0.8, h: c.w * 0.8, fill: '#fb7185', fill2: '#fda4af', angle: 135, opacity: 0.9 }),
      S({ shape: 'circle', x: c.w * 0.62, y: c.h * 0.4, w: c.w * 0.2, h: c.w * 0.2, fill: '#fff1f2', opacity: 0.9 })], { ty: 0.64, font: 'cursive', size: 150, color: '#9f1239', bold: false, ay: 0.9, authorColor: '#be123c' }) },

    /* ---- Poesia ---- */
    { id: 'verse-ink', name: 'Tinta', category: 'Poesia', make: (c) => mk(c, { type: 'solid', color: '#fbf8f1' }, {}, [
      S({ shape: 'ring', x: c.w * 0.2, y: c.h * 0.12, w: c.w * 0.6, h: c.w * 0.6, fill: '#111827', strokeW: 3 }),
      S({ shape: 'line', x: c.w * 0.46, y: c.h * 0.12 + c.w * 0.6, w: 6, h: c.h * 0.12, fill: '#111827', strokeW: 3 })], { ty: 0.56, font: 'serif', italic: true, size: 135, color: '#111827', bold: false, ay: 0.9, authorColor: '#6b7280' }) },
    { id: 'moon-poem', name: 'Poema da Lua', category: 'Poesia', make: (c) => mk(c, { type: 'solid', color: '#0b1a3a' }, { vignette: 0.3 },
      dots(c, 18, 11, '#e0e7ff', 4, 10).concat([
        S({ shape: 'circle', x: c.w * 0.3, y: c.h * 0.12, w: c.w * 0.4, h: c.w * 0.4, fill: '#fef3c7' }),
        S({ shape: 'circle', x: c.w * 0.4, y: c.h * 0.1, w: c.w * 0.36, h: c.w * 0.36, fill: '#0b1a3a' })]), { ty: 0.54, font: 'serif', italic: true, size: 135, color: '#fef3c7', bold: false, ay: 0.9, authorColor: '#c7d2fe' }) },
    { id: 'petal', name: 'Pétalas', category: 'Poesia', make: (c) => mk(c, { type: 'solid', color: '#f5f3ff' }, {},
      dots(c, 16, 5, ['#c4b5fd', '#ddd6fe', '#f5d0fe', '#fbcfe8'], 60, 200).map((e) => Object.assign(e, { shape: 'circle', opacity: 0.55 })), { ty: 0.4, font: 'serif', italic: true, size: 140, color: '#4c1d95', bold: false, ay: 0.88, authorColor: '#7c3aed' }) },
    { id: 'sunrise-verse', name: 'Alvorada', category: 'Poesia', make: (c) => mk(c, { type: 'gradient', from: '#fef3c7', to: '#fda4af', angle: 180 }, {}, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.42, w: c.w * 0.6, h: c.w * 0.6, fill: '#f97316', fill2: '#fbbf24', angle: 180 }),
      S({ shape: 'rect', x: 0, y: c.h * 0.42 + c.w * 0.3, w: c.w, h: c.h, fill: '#fff7ed' })], { ty: 0.62, font: 'serif', italic: true, size: 125, color: '#7c2d12', bold: false, ay: 0.9, authorColor: '#c2410c' }) },
    { id: 'quill', name: 'Pena', category: 'Poesia', make: (c) => mk(c, { type: 'solid', color: '#1c2b22' }, { vignette: 0.35 }, [
      S({ shape: 'rect', x: c.w * 0.08, y: c.h * 0.06, w: c.w * 0.84, h: c.h * 0.88, fill: 'rgba(0,0,0,0)', stroke: '#d4b26a', strokeW: 2 }),
      S({ shape: 'star', x: c.w * 0.44, y: c.h * 0.16, w: c.w * 0.12, h: c.w * 0.12, fill: '#d4b26a' }),
      S({ shape: 'line', x: c.w * 0.3, y: c.h * 0.62, w: c.w * 0.4, h: 10, fill: '#d4b26a', strokeW: 3 })], { ty: 0.34, font: 'serif', italic: true, size: 135, color: '#f1e3b8', bold: false, ay: 0.78, authorColor: '#d4b26a' }) },

    /* ---- Infantil ---- */
    { id: 'kids-sun', name: 'Dia Feliz', category: 'Infantil', make: (c) => mk(c, { type: 'solid', color: '#7dd3fc' }, {}, [
      S({ shape: 'circle', x: c.w * 0.62, y: c.h * 0.05, w: c.w * 0.3, h: c.w * 0.3, fill: '#fde047' }),
      S({ shape: 'circle', x: c.w * 0.04, y: c.h * 0.12, w: c.w * 0.22, h: c.w * 0.12, fill: '#ffffff', opacity: 0.95 }),
      S({ shape: 'circle', x: c.w * 0.14, y: c.h * 0.1, w: c.w * 0.2, h: c.w * 0.14, fill: '#ffffff', opacity: 0.95 }),
      S({ shape: 'circle', x: -c.w * 0.1, y: c.h * 0.76, w: c.w * 0.8, h: c.w * 0.6, fill: '#4ade80' }),
      S({ shape: 'circle', x: c.w * 0.4, y: c.h * 0.8, w: c.w * 0.8, h: c.w * 0.6, fill: '#22c55e' })], { ty: 0.34, font: 'cursive', size: 160, color: '#ffffff', outline: true, outlineColor: '#f97316', shadow: false, ay: 0.9, authorColor: '#14532d' }) },
    { id: 'kids-rainbow', name: 'Arco-íris', category: 'Infantil', make: (c) => mk(c, { type: 'solid', color: '#fef9c3' }, {}, [
      ['#ef4444', 0.92], ['#f97316', 0.8], ['#facc15', 0.68], ['#22c55e', 0.56], ['#3b82f6', 0.44], ['#8b5cf6', 0.32]].map(([col, f]) => S({ shape: 'ring', x: c.w * (0.5 - f / 2), y: c.h * 0.42 - c.w * f / 2, w: c.w * f, h: c.w * f, fill: col, strokeW: c.w * 0.055 }))
      .concat([S({ shape: 'rect', x: 0, y: c.h * 0.42, w: c.w, h: c.h * 0.58, fill: '#fef9c3' }),
        S({ shape: 'circle', x: c.w * 0.02, y: c.h * 0.37, w: c.w * 0.28, h: c.w * 0.16, fill: '#ffffff' }), S({ shape: 'circle', x: c.w * 0.72, y: c.h * 0.37, w: c.w * 0.28, h: c.w * 0.16, fill: '#ffffff' })]), { ty: 0.52, font: 'cursive', size: 160, color: '#7c3aed', outline: true, outlineColor: '#ffffff', ay: 0.9, authorColor: '#b45309' }) },
    { id: 'kids-stars', name: 'Estrelinhas', category: 'Infantil', make: (c) => mk(c, { type: 'gradient', from: '#312e81', to: '#7c3aed', angle: 180 }, {},
      dots(c, 28, 21, ['#fde047', '#fbcfe8', '#a5f3fc', '#ffffff'], 18, 56).concat([
        S({ shape: 'circle', x: c.w * 0.3, y: c.h * 0.12, w: c.w * 0.4, h: c.w * 0.4, fill: '#fde047' }),
        S({ shape: 'circle', x: c.w * 0.4, y: c.h * 0.1, w: c.w * 0.36, h: c.w * 0.36, fill: '#4c1d95' })]), { ty: 0.56, font: 'cursive', size: 160, color: '#fde047', outline: true, outlineColor: '#4c1d95', ay: 0.9, authorColor: '#fbcfe8' }) },
    { id: 'kids-bear', name: 'Ursinho', category: 'Infantil', make: (c) => mk(c, { type: 'solid', color: '#fde68a' }, {}, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.1, w: c.w * 0.2, h: c.w * 0.2, fill: '#b45309' }), S({ shape: 'circle', x: c.w * 0.6, y: c.h * 0.1, w: c.w * 0.2, h: c.w * 0.2, fill: '#b45309' }),
      S({ shape: 'circle', x: c.w * 0.25, y: c.h * 0.13, w: c.w * 0.1, h: c.w * 0.1, fill: '#fcd9a8' }), S({ shape: 'circle', x: c.w * 0.65, y: c.h * 0.13, w: c.w * 0.1, h: c.w * 0.1, fill: '#fcd9a8' }),
      S({ shape: 'circle', x: c.w * 0.16, y: c.h * 0.14, w: c.w * 0.68, h: c.w * 0.68, fill: '#d97706' }),
      S({ shape: 'circle', x: c.w * 0.34, y: c.h * 0.14 + c.w * 0.34, w: c.w * 0.32, h: c.w * 0.26, fill: '#fcd9a8' }),
      S({ shape: 'circle', x: c.w * 0.3, y: c.h * 0.14 + c.w * 0.2, w: c.w * 0.07, h: c.w * 0.07, fill: '#1f2937' }), S({ shape: 'circle', x: c.w * 0.63, y: c.h * 0.14 + c.w * 0.2, w: c.w * 0.07, h: c.w * 0.07, fill: '#1f2937' }),
      S({ shape: 'circle', x: c.w * 0.45, y: c.h * 0.14 + c.w * 0.37, w: c.w * 0.1, h: c.w * 0.07, fill: '#1f2937' })], { ty: 0.68, font: 'cursive', size: 150, color: '#7c2d12', bold: true, ay: 0.9, authorColor: '#92400e' }) },
    { id: 'kids-balloons', name: 'Balões', category: 'Infantil', make: (c) => mk(c, { type: 'solid', color: '#e0f2fe' }, {}, [
      ['#ef4444', 0.12, 0.1, 0.26], ['#3b82f6', 0.4, 0.06, 0.3], ['#facc15', 0.68, 0.12, 0.24], ['#22c55e', 0.26, 0.28, 0.22]].reduce((a, [col, x, y, sz]) => a.concat([
        S({ shape: 'rect', x: c.w * (x + sz / 2) - 2, y: c.h * y + c.w * sz * 1.2, w: 4, h: c.h * 0.22, fill: '#64748b', opacity: 0.7 }),
        S({ shape: 'circle', x: c.w * x, y: c.h * y, w: c.w * sz, h: c.w * sz * 1.2, fill: col }),
        S({ shape: 'circle', x: c.w * (x + sz * 0.2), y: c.h * y + c.w * sz * 0.15, w: c.w * sz * 0.18, h: c.w * sz * 0.18, fill: '#ffffff', opacity: 0.6 })]), []), { ty: 0.6, font: 'cursive', size: 160, color: '#1d4ed8', outline: true, outlineColor: '#ffffff', ay: 0.9, authorColor: '#0369a1' }) },
    { id: 'kids-dino', name: 'Dinossauro', category: 'Infantil', make: (c) => mk(c, { type: 'solid', color: '#bbf7d0' }, {}, [
      S({ shape: 'circle', x: c.w * 0.12, y: c.h * 0.14, w: c.w * 0.76, h: c.w * 0.76, fill: '#16a34a' }),
      S({ shape: 'triangle', x: c.w * 0.2, y: c.h * 0.08, w: c.w * 0.14, h: c.w * 0.14, fill: '#f97316' }), S({ shape: 'triangle', x: c.w * 0.43, y: c.h * 0.05, w: c.w * 0.14, h: c.w * 0.14, fill: '#f97316' }), S({ shape: 'triangle', x: c.w * 0.66, y: c.h * 0.08, w: c.w * 0.14, h: c.w * 0.14, fill: '#f97316' }),
      S({ shape: 'circle', x: c.w * 0.3, y: c.h * 0.14 + c.w * 0.22, w: c.w * 0.14, h: c.w * 0.14, fill: '#ffffff' }), S({ shape: 'circle', x: c.w * 0.56, y: c.h * 0.14 + c.w * 0.22, w: c.w * 0.14, h: c.w * 0.14, fill: '#ffffff' }),
      S({ shape: 'circle', x: c.w * 0.35, y: c.h * 0.14 + c.w * 0.26, w: c.w * 0.06, h: c.w * 0.06, fill: '#111827' }), S({ shape: 'circle', x: c.w * 0.61, y: c.h * 0.14 + c.w * 0.26, w: c.w * 0.06, h: c.w * 0.06, fill: '#111827' }),
      S({ shape: 'rect', x: c.w * 0.36, y: c.h * 0.14 + c.w * 0.5, w: c.w * 0.28, h: c.w * 0.06, fill: '#14532d', radius: 20 })], { ty: 0.68, font: 'cursive', size: 150, color: '#14532d', outline: true, outlineColor: '#ffffff', ay: 0.9, authorColor: '#166534' }) },
    { id: 'kids-patch', name: 'Colorido', category: 'Infantil', make: (c) => mk(c, { type: 'solid', color: '#fff7ed' }, {},
      ['#ef4444', '#f97316', '#facc15', '#22c55e', '#3b82f6', '#8b5cf6', '#ec4899', '#14b8a6', '#f59e0b'].map((col, i) => S({ shape: 'rect', x: c.w * (0.1 + (i % 3) * 0.27), y: c.h * (0.08 + Math.floor(i / 3) * 0.13), w: c.w * 0.25, h: c.h * 0.12, fill: col, radius: 28 })), { ty: 0.54, font: 'cursive', size: 160, color: '#1f2937', outline: true, outlineColor: '#ffffff', ay: 0.9, authorColor: '#ea580c' }) },
    { id: 'kids-night', name: 'Hora de Dormir', category: 'Infantil', make: (c) => mk(c, { type: 'gradient', from: '#1e3a8a', to: '#0f172a', angle: 180 }, {},
      dots(c, 14, 40, '#fef9c3', 8, 26).concat([
        S({ shape: 'circle', x: c.w * 0.5, y: c.h * 0.08, w: c.w * 0.36, h: c.w * 0.36, fill: '#fef9c3' }),
        S({ shape: 'circle', x: c.w * 0.6, y: c.h * 0.06, w: c.w * 0.32, h: c.w * 0.32, fill: '#1e3a8a' }),
        S({ shape: 'circle', x: c.w * 0.05, y: c.h * 0.7, w: c.w * 0.5, h: c.w * 0.3, fill: '#e2e8f0', opacity: 0.9 }), S({ shape: 'circle', x: c.w * 0.3, y: c.h * 0.72, w: c.w * 0.6, h: c.w * 0.32, fill: '#cbd5e1', opacity: 0.9 })]), { ty: 0.4, font: 'cursive', size: 155, color: '#fef9c3', outline: true, outlineColor: '#1e3a8a', ay: 0.92, authorColor: '#bfdbfe' }) },

    /* ---- Outros géneros ---- */
    { id: 'haunted', name: 'Casa Assombrada', category: 'Terror', make: (c) => mk(c, { type: 'gradient', from: '#1e1b4b', to: '#020617', angle: 180 }, { vignette: 0.6 }, [
      S({ shape: 'circle', x: c.w * 0.55, y: c.h * 0.08, w: c.w * 0.3, h: c.w * 0.3, fill: '#fef3c7', opacity: 0.9 }),
      S({ shape: 'rect', x: c.w * 0.22, y: c.h * 0.52, w: c.w * 0.56, h: c.h * 0.26, fill: '#000000' }),
      S({ shape: 'triangle', x: c.w * 0.18, y: c.h * 0.4, w: c.w * 0.64, h: c.h * 0.14, fill: '#000000' }),
      S({ shape: 'rect', x: c.w * 0.3, y: c.h * 0.6, w: c.w * 0.08, h: c.h * 0.05, fill: '#facc15' }), S({ shape: 'rect', x: c.w * 0.62, y: c.h * 0.6, w: c.w * 0.08, h: c.h * 0.05, fill: '#facc15' }),
      S({ shape: 'rect', x: 0, y: c.h * 0.78, w: c.w, h: c.h * 0.22, fill: '#000000' })], { ty: 0.14, font: 'serif', size: 135, color: '#e2e8f0', upper: true, spacing: 3, shadow: true, ay: 0.9, authorColor: '#94a3b8' }) },
    { id: 'detective', name: 'Detetive', category: 'Suspense', make: (c) => mk(c, { type: 'solid', color: '#1f2937' }, { vignette: 0.4 }, [
      S({ shape: 'rect', x: -c.w * 0.1, y: c.h * 0.18, w: c.w * 1.2, h: c.h * 0.05, fill: '#facc15', rot: -12 }),
      S({ shape: 'rect', x: -c.w * 0.1, y: c.h * 0.26, w: c.w * 1.2, h: c.h * 0.05, fill: '#facc15', rot: -12 }),
      S({ shape: 'ring', x: c.w * 0.3, y: c.h * 0.4, w: c.w * 0.34, h: c.w * 0.34, fill: '#e5e7eb', strokeW: 12 }),
      S({ shape: 'rect', x: c.w * 0.6, y: c.h * 0.4 + c.w * 0.32, w: c.w * 0.05, h: c.w * 0.18, fill: '#e5e7eb', rot: -35 })], { ty: 0.66, font: 'sans-serif', size: 120, color: '#f9fafb', upper: true, spacing: 3, ay: 0.9, authorColor: '#facc15' }) },
    { id: 'memoir', name: 'Memórias', category: 'Biografia', make: (c) => mk(c, { type: 'solid', color: '#e7e5e4' }, { vignette: 0.15 }, [
      S({ shape: 'rect', x: c.w * 0.2, y: c.h * 0.08, w: c.w * 0.6, h: c.h * 0.4, fill: '#ffffff', rot: -4 }),
      S({ shape: 'rect', x: c.w * 0.24, y: c.h * 0.1, w: c.w * 0.52, h: c.h * 0.32, fill: '#a8a29e', rot: -4 })], { ty: 0.58, font: 'serif', size: 130, color: '#292524', ay: 0.88, authorColor: '#78716c' }) },
    { id: 'faith', name: 'Fé', category: 'Religião', make: (c) => mk(c, { type: 'gradient', from: '#0c4a6e', to: '#1e293b', angle: 180 }, { vignette: 0.3 }, [
      S({ shape: 'circle', x: c.w * 0.15, y: c.h * 0.06, w: c.w * 0.7, h: c.w * 0.7, fill: '#fde68a', opacity: 0.2 }),
      S({ shape: 'circle', x: c.w * 0.25, y: c.h * 0.06 + c.w * 0.1, w: c.w * 0.5, h: c.w * 0.5, fill: '#fde68a', opacity: 0.25 }),
      S({ shape: 'rect', x: c.w * 0.47, y: c.h * 0.1, w: c.w * 0.06, h: c.w * 0.5, fill: '#fef3c7' }),
      S({ shape: 'rect', x: c.w * 0.35, y: c.h * 0.1 + c.w * 0.14, w: c.w * 0.3, h: c.w * 0.06, fill: '#fef3c7' })], { ty: 0.62, font: 'serif', size: 130, color: '#fef3c7', ay: 0.9, authorColor: '#fcd34d', shadow: true }) },
    { id: 'code', name: 'Código', category: 'Tecnologia', make: (c) => mk(c, { type: 'solid', color: '#0d1117' }, {},
      [0.08, 0.12, 0.16, 0.2, 0.24, 0.28].map((y, i) => S({ shape: 'rect', x: c.w * (0.1 + (i % 3) * 0.05), y: c.h * y, w: c.w * (0.3 + ((i * 37) % 40) / 100), h: 14, fill: i % 2 ? '#22c55e' : '#38bdf8', opacity: 0.8, radius: 7 })), { ty: 0.44, font: 'monospace', size: 110, color: '#4ade80', align: 'left', ay: 0.88, authorColor: '#8b949e' }) },
    { id: 'empire', name: 'Império', category: 'História', make: (c) => mk(c, { type: 'solid', color: '#3f1d0b' }, { vignette: 0.45 }, [
      S({ shape: 'rect', x: 0, y: c.h * 0.08, w: c.w, h: c.h * 0.03, fill: '#d4a437' }), S({ shape: 'rect', x: 0, y: c.h * 0.12, w: c.w, h: c.h * 0.01, fill: '#d4a437' }),
      S({ shape: 'rect', x: 0, y: c.h * 0.87, w: c.w, h: c.h * 0.01, fill: '#d4a437' }), S({ shape: 'rect', x: 0, y: c.h * 0.89, w: c.w, h: c.h * 0.03, fill: '#d4a437' }),
      S({ shape: 'star', x: c.w * 0.4, y: c.h * 0.2, w: c.w * 0.2, h: c.w * 0.2, fill: '#d4a437' })], { ty: 0.45, font: 'serif', size: 135, color: '#f3dca0', upper: true, spacing: 4, ay: 0.78, authorColor: '#d4a437' }) },
    { id: 'notebook', name: 'Caderno', category: 'Educação', make: (c) => mk(c, { type: 'solid', color: '#fffbeb' }, {},
      Array.from({ length: 16 }, (_, i) => S({ shape: 'rect', x: 0, y: c.h * (0.08 + i * 0.056), w: c.w, h: 3, fill: '#93c5fd', opacity: 0.7 })).concat([S({ shape: 'rect', x: c.w * 0.14, y: 0, w: 4, h: c.h, fill: '#fca5a5' })]), { ty: 0.34, font: 'cursive', size: 150, color: '#1d4ed8', bold: false, ay: 0.86, authorColor: '#475569' }) },
    { id: 'skyline', name: 'Cidade', category: 'Ficção', make: (c) => mk(c, { type: 'gradient', from: '#0f172a', to: '#475569', angle: 180 }, { vignette: 0.3 }, [
      S({ shape: 'circle', x: c.w * 0.6, y: c.h * 0.14, w: c.w * 0.22, h: c.w * 0.22, fill: '#fde68a', opacity: 0.9 })].concat(
      [[0.04, 0.55], [0.17, 0.46], [0.3, 0.6], [0.43, 0.42], [0.56, 0.58], [0.7, 0.48], [0.83, 0.62]].map(([x, y]) => S({ shape: 'rect', x: c.w * x, y: c.h * y, w: c.w * 0.12, h: c.h * (1 - y), fill: '#020617' }))), { ty: 0.2, font: 'sans-serif', size: 125, color: '#f1f5f9', upper: true, spacing: 4, ay: 0.92, authorColor: '#fde68a' }) },
    { id: 'growth', name: 'Crescer', category: 'Desenvolvimento pessoal', make: (c) => mk(c, { type: 'solid', color: '#ecfccb' }, {}, [
      S({ shape: 'triangle', x: c.w * 0.3, y: c.h * 0.1, w: c.w * 0.4, h: c.w * 0.4, fill: '#16a34a' }),
      S({ shape: 'triangle', x: c.w * 0.25, y: c.h * 0.1 + c.w * 0.16, w: c.w * 0.5, h: c.w * 0.5, fill: '#22c55e' }),
      S({ shape: 'triangle', x: c.w * 0.2, y: c.h * 0.1 + c.w * 0.34, w: c.w * 0.6, h: c.w * 0.5, fill: '#4ade80' }),
      S({ shape: 'rect', x: c.w * 0.46, y: c.h * 0.1 + c.w * 0.82, w: c.w * 0.08, h: c.h * 0.06, fill: '#92400e' })], { ty: 0.66, font: 'sans-serif', size: 125, color: '#14532d', ay: 0.9, authorColor: '#166534' }) },
    { id: 'focus', name: 'Foco', category: 'Desenvolvimento pessoal', make: (c) => mk(c, { type: 'solid', color: '#ffffff' }, {}, [
      S({ shape: 'ring', x: c.w * 0.18, y: c.h * 0.12, w: c.w * 0.64, h: c.w * 0.64, fill: '#ef4444', strokeW: 6, opacity: 0.4 }),
      S({ shape: 'ring', x: c.w * 0.29, y: c.h * 0.12 + c.w * 0.11, w: c.w * 0.42, h: c.w * 0.42, fill: '#ef4444', strokeW: 6, opacity: 0.7 }),
      S({ shape: 'circle', x: c.w * 0.41, y: c.h * 0.12 + c.w * 0.23, w: c.w * 0.18, h: c.w * 0.18, fill: '#ef4444' })], { ty: 0.6, font: 'sans-serif', size: 125, color: '#111827', upper: true, spacing: 3, ay: 0.9, authorColor: '#ef4444' }) },
    { id: 'duo', name: 'Duas Cores', category: 'Outros', make: (c) => mk(c, { type: 'solid', color: '#fef08a' }, {}, [
      S({ shape: 'rect', x: 0, y: 0, w: c.w, h: c.h * 0.5, fill: '#1e293b' }),
      S({ shape: 'circle', x: c.w * 0.3, y: c.h * 0.5 - c.w * 0.2, w: c.w * 0.4, h: c.w * 0.4, fill: '#f43f5e' })], { ty: 0.1, font: 'sans-serif', size: 125, color: '#fef08a', upper: true, spacing: 3, ay: 0.88, authorColor: '#1e293b' }) },
    { id: 'blank', name: 'Em branco', category: 'Outros', make: (c) => { const d = C.newDesign(c.w, c.h); d.bg = { type: 'solid', color: '#111827' }; return d; } }
  ];
  C.TEMPLATES = LIST;

  /** Modelos ordenados com os da categoria do livro primeiro. */
  C.templatesFor = function (category) {
    return LIST.slice().sort((a, b) => (b.category === category) - (a.category === category));
  };

  C.ctxFor = function (book, size) {
    return { w: size.w, h: size.h, title: book.title, subtitle: book.subtitle, author: book.author };
  };
  C.fromTemplate = function (tpl, book, size) { return tpl.make(C.ctxFor(book, size)); };

  /** Contracapa coerente com a frente: mesmo fundo/efeitos + sinopse, autor e ISBN. */
  C.makeBack = function (front, book) {
    const w = front.w, h = front.h, d = C.newDesign(w, h);
    d.bg = JSON.parse(JSON.stringify(front.bg)); d.fx = Object.assign({}, front.fx);
    d.els = front.els.filter((e) => e.type === 'shape' && (e.stroke || e.shape === 'rect') && e.w > w * 0.8 && e.h > h * 0.6).map((e) => JSON.parse(JSON.stringify(e)));
    const dark = C.isDark(d.bg.type === 'gradient' ? d.bg.from : d.bg.color);
    const fg = dark ? '#f1f5f9' : '#1f2937', muted = dark ? '#cbd5e1' : '#475569';
    d.els.push(T({ id: 'bk-head', role: 'blurb-title', x: w * 0.12, y: h * 0.1, w: w * 0.76, h: h * 0.08, text: book.title, font: 'serif', size: Math.round(w * 0.05), color: fg, bold: true, align: 'left', valign: 'top' }));
    d.els.push(T({ id: 'bk-desc', role: 'blurb', x: w * 0.12, y: h * 0.2, w: w * 0.76, h: h * 0.5, text: book.description || 'Escreva aqui a sinopse do livro: o que o leitor vai encontrar, a quem se destina e porque vale a pena lê-lo.', font: 'serif', size: Math.round(w * 0.038), color: fg, align: 'left', valign: 'top', lineH: 1.4 }));
    d.els.push(T({ id: 'bk-author', role: 'author', x: w * 0.12, y: h * 0.74, w: w * 0.76, h: h * 0.05, text: book.author || '', font: 'sans-serif', size: Math.round(w * 0.034), color: muted, upper: true, spacing: 4, bold: true, align: 'left', valign: 'top' }));
    d.els.push(S({ id: 'bk-isbn-box', shape: 'rect', x: w * 0.12, y: h * 0.82, w: w * 0.4, h: h * 0.1, fill: '#ffffff', radius: 8 }));
    d.els.push(T({ id: 'bk-isbn', role: 'isbn', x: w * 0.12, y: h * 0.82, w: w * 0.4, h: h * 0.1, text: book.isbn ? 'ISBN ' + book.isbn : 'ISBN', font: 'monospace', size: Math.round(w * 0.03), color: '#111827', align: 'center' }));
    return d;
  };

  /** Lombada: título e autor na vertical. */
  C.makeSpine = function (front, book, w, h) {
    const d = C.newDesign(w, h);
    d.bg = JSON.parse(JSON.stringify(front.bg)); d.fx = Object.assign({}, front.fx);
    const dark = C.isDark(d.bg.type === 'gradient' ? d.bg.from : d.bg.color);
    const fg = dark ? '#f8fafc' : '#111827';
    const tl = h * 0.62;
    d.els.push(T({ id: 'sp-title', role: 'title', x: w / 2 - tl / 2, y: h * 0.4 - w * 0.5 + (w * 0.5 - w * 0.33) , w: tl, h: w * 0.66, text: book.title, font: 'serif', size: Math.round(w * 0.42), color: fg, bold: true, rot: 90, align: 'left', valign: 'middle' }));
    d.els.push(T({ id: 'sp-author', role: 'author', x: w / 2 - h * 0.14, y: h * 0.86 - w * 0.2, w: h * 0.28, h: w * 0.4, text: book.author || '', font: 'sans-serif', size: Math.round(w * 0.3), color: fg, upper: true, spacing: 3, rot: 90, align: 'center', valign: 'middle' }));
    return d;
  };
})();
