/* BookVerse — modelos de capa por categoria literária (gerados por código, sem imagens externas) */
(function () {
  'use strict';
  const BV = window.BV, C = BV.cover;
  const T = C.newText, S = C.newShape;

  const fit = (str, base) => { const n = (str || '').length; return Math.round(base * (n <= 12 ? 1 : n <= 24 ? 0.8 : n <= 40 ? 0.64 : 0.5)); };
  const titleOf = (c) => c.title || 'Título do livro';

  function std(c, o) {
    // elementos de texto padrão: título, subtítulo, autor
    const w = c.w, h = c.h, els = [];
    els.push(T({ id: 'title', role: 'title', x: w * 0.1, y: h * o.ty, w: w * 0.8, h: h * (o.th || 0.22), text: titleOf(c), font: o.font || 'serif', size: fit(titleOf(c), o.size || 130), color: o.color, bold: o.bold !== false, italic: !!o.italic, upper: !!o.upper, spacing: o.spacing || 0, shadow: !!o.shadow, outline: !!o.outline, outlineColor: o.outlineColor || '#000', lineH: 1.08, align: o.align || 'center' }));
    if (c.subtitle) els.push(T({ id: 'subtitle', role: 'subtitle', x: w * 0.12, y: h * (o.ty + (o.th || 0.22) + 0.01), w: w * 0.76, h: h * 0.08, text: c.subtitle, font: o.subFont || o.font || 'serif', size: Math.round(w * 0.04), color: o.sub || o.color, italic: true, align: o.align || 'center', valign: 'top', opacity: 0.9 }));
    els.push(T({ id: 'author', role: 'author', x: w * 0.1, y: h * (o.ay || 0.86), w: w * 0.8, h: h * 0.07, text: c.author || 'Nome do autor', font: o.authorFont || 'sans-serif', size: Math.round(w * 0.045), color: o.authorColor || o.color, upper: true, spacing: 6, bold: true, align: o.align || 'center' }));
    return els;
  }
  const mk = (c, bg, fx, shapes, textOpts, tail) => {
    const d = C.newDesign(c.w, c.h);
    d.bg = bg; d.fx = Object.assign({ vignette: 0, blur: 0, gray: false, tint: '', tintAlpha: 0 }, fx || {});
    d.els = [].concat(shapes || [], std(c, textOpts), tail || []);
    return d;
  };

  const LIST = [
    { id: 'rose', name: 'Rosa', category: 'Romance', make: (c) => mk(c, { type: 'gradient', from: '#9d174d', to: '#fb7185', angle: 160 }, { vignette: 0.25 }, [
      S({ shape: 'circle', x: c.w * 0.18, y: c.h * 0.14, w: c.w * 0.64, h: c.w * 0.64, fill: '#ffffff', opacity: 0.14 }),
      S({ shape: 'ring', x: c.w * 0.1, y: c.h * 0.08, w: c.w * 0.8, h: c.w * 0.8, fill: '#ffffff', strokeW: 6, opacity: 0.5 }),
      S({ shape: 'star', x: c.w * 0.44, y: c.h * 0.38, w: c.w * 0.12, h: c.w * 0.12, fill: '#ffe4e6', opacity: 0.9 })], { ty: 0.6, font: 'cursive', size: 150, color: '#fff1f2', shadow: true, bold: false, ay: 0.9 }) },
    { id: 'noir-romance', name: 'Paixão', category: 'Romance', make: (c) => mk(c, { type: 'gradient', from: '#1f0a14', to: '#7f1d1d', angle: 180 }, { vignette: 0.4 }, [
      S({ shape: 'rect', x: c.w * 0.07, y: c.h * 0.05, w: c.w * 0.86, h: c.h * 0.9, fill: 'rgba(0,0,0,0)', stroke: '#fda4af', strokeW: 4, fill2: '' }),
      S({ shape: 'diamond', x: c.w * 0.44, y: c.h * 0.3, w: c.w * 0.12, h: c.w * 0.16, fill: '#fb7185' })], { ty: 0.45, font: 'serif', italic: true, size: 140, color: '#ffe4e6', ay: 0.85, authorColor: '#fda4af' }) },
    { id: 'classic', name: 'Clássico', category: 'Ficção', make: (c) => mk(c, { type: 'solid', color: '#10243e' }, { vignette: 0.3 }, [
      S({ shape: 'rect', x: c.w * 0.06, y: c.h * 0.04, w: c.w * 0.88, h: c.h * 0.92, fill: 'rgba(0,0,0,0)', stroke: '#d4af37', strokeW: 5 }),
      S({ shape: 'rect', x: c.w * 0.09, y: c.h * 0.07, w: c.w * 0.82, h: c.h * 0.86, fill: 'rgba(0,0,0,0)', stroke: '#d4af37', strokeW: 2 }),
      S({ shape: 'line', x: c.w * 0.3, y: c.h * 0.58, w: c.w * 0.4, h: 12, fill: '#d4af37', strokeW: 4 })], { ty: 0.3, font: 'serif', size: 140, color: '#f5e6b3', ay: 0.8, authorColor: '#d4af37' }) },
    { id: 'modern-fiction', name: 'Moderno', category: 'Ficção', make: (c) => mk(c, { type: 'solid', color: '#f8fafc' }, {}, [
      S({ shape: 'rect', x: 0, y: 0, w: c.w, h: c.h * 0.55, fill: '#2563eb', fill2: '#1e3a8a', angle: 160 }),
      S({ shape: 'circle', x: c.w * 0.55, y: c.h * 0.32, w: c.w * 0.5, h: c.w * 0.5, fill: '#f59e0b' })], { ty: 0.62, font: 'sans-serif', size: 120, color: '#0f172a', ay: 0.9, authorColor: '#334155', align: 'left' }) },
    { id: 'fantasy', name: 'Reino Místico', category: 'Fantasia', make: (c) => mk(c, { type: 'gradient', from: '#312e81', to: '#0f0a2e', angle: 170 }, { vignette: 0.45 }, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.1, w: c.w * 0.6, h: c.w * 0.6, fill: '#a78bfa', fill2: '#4c1d95', angle: 140, opacity: 0.55 }),
      S({ shape: 'ring', x: c.w * 0.12, y: c.h * 0.05, w: c.w * 0.76, h: c.w * 0.76, fill: '#fde68a', strokeW: 4, opacity: 0.8 }),
      S({ shape: 'star', x: c.w * 0.08, y: c.h * 0.4, w: c.w * 0.06, h: c.w * 0.06, fill: '#fde68a' }), S({ shape: 'star', x: c.w * 0.86, y: c.h * 0.28, w: c.w * 0.05, h: c.w * 0.05, fill: '#fde68a' }),
      S({ shape: 'star', x: c.w * 0.72, y: c.h * 0.5, w: c.w * 0.04, h: c.w * 0.04, fill: '#ffffff' })], { ty: 0.56, font: 'serif', size: 150, color: '#fde68a', shadow: true, upper: true, spacing: 3, ay: 0.89, authorColor: '#ddd6fe' }) },
    { id: 'horror', name: 'Pesadelo', category: 'Terror', make: (c) => mk(c, { type: 'solid', color: '#050505' }, { vignette: 0.85 }, [
      S({ shape: 'triangle', x: c.w * 0.25, y: c.h * 0.12, w: c.w * 0.5, h: c.w * 0.55, fill: '#7f1d1d', fill2: '#050505', angle: 180 }),
      S({ shape: 'circle', x: c.w * 0.42, y: c.h * 0.36, w: c.w * 0.16, h: c.w * 0.16, fill: '#dc2626' })], { ty: 0.56, font: 'serif', size: 150, color: '#dc2626', upper: true, spacing: 4, shadow: true, ay: 0.9, authorColor: '#d4d4d4' }) },
    { id: 'suspense', name: 'Sombra', category: 'Suspense', make: (c) => mk(c, { type: 'gradient', from: '#111827', to: '#374151', angle: 200 }, { vignette: 0.5 }, [
      S({ shape: 'rect', x: -c.w * 0.1, y: c.h * 0.2, w: c.w * 1.3, h: c.h * 0.06, fill: '#facc15', rot: -12 }),
      S({ shape: 'rect', x: -c.w * 0.1, y: c.h * 0.3, w: c.w * 1.3, h: c.h * 0.02, fill: '#facc15', rot: -12, opacity: 0.6 })], { ty: 0.45, font: 'sans-serif-condensed', size: 170, color: '#f9fafb', upper: true, spacing: 5, ay: 0.88, authorColor: '#facc15' }) },
    { id: 'biography', name: 'Retrato', category: 'Biografia', make: (c) => mk(c, { type: 'solid', color: '#f3ead8' }, {}, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.08, w: c.w * 0.6, h: c.w * 0.6, fill: '#d6c3a0', stroke: '#7c5e2f', strokeW: 8 }),
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.75, w: c.w * 0.8, h: 6, fill: '#7c5e2f' })], { ty: 0.52, font: 'serif', size: 130, color: '#3f2d12', ay: 0.8, authorColor: '#7c5e2f' }) },
    { id: 'education', name: 'Saber', category: 'Educação', make: (c) => mk(c, { type: 'solid', color: '#0ea5e9' }, {}, [
      S({ shape: 'rect', x: 0, y: 0, w: c.w, h: c.h * 0.12, fill: '#075985' }), S({ shape: 'rect', x: 0, y: c.h * 0.88, w: c.w, h: c.h * 0.12, fill: '#075985' }),
      S({ shape: 'round', x: c.w * 0.08, y: c.h * 0.2, w: c.w * 0.84, h: c.h * 0.42, fill: '#ffffff', opacity: 0.95 })], { ty: 0.26, th: 0.3, font: 'sans-serif', size: 120, color: '#075985', ay: 0.9, authorColor: '#e0f2fe' }) },
    { id: 'tech', name: 'Circuito', category: 'Tecnologia', make: (c) => {
      const lines = []; for (let i = 0; i < 9; i++) lines.push(S({ shape: 'rect', x: 0, y: c.h * (0.08 + i * 0.045), w: c.w * (0.3 + 0.07 * ((i * 5) % 7)), h: 6, fill: '#22d3ee', opacity: 0.55 }));
      lines.push(S({ shape: 'circle', x: c.w * 0.72, y: c.h * 0.1, w: c.w * 0.18, h: c.w * 0.18, fill: '#22d3ee', opacity: 0.25 }));
      return mk(c, { type: 'gradient', from: '#020617', to: '#0f172a', angle: 160 }, { vignette: 0.3 }, lines, { ty: 0.5, font: 'monospace', size: 120, color: '#e0f2fe', align: 'left', ay: 0.88, authorColor: '#22d3ee' }); } },
    { id: 'selfhelp', name: 'Amanhecer', category: 'Desenvolvimento pessoal', make: (c) => mk(c, { type: 'gradient', from: '#f97316', to: '#fde047', angle: 0 }, {}, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.58, w: c.w * 0.6, h: c.w * 0.6, fill: '#fff7ed', opacity: 0.85 }),
      S({ shape: 'rect', x: 0, y: c.h * 0.78, w: c.w, h: c.h * 0.22, fill: '#7c2d12' })], { ty: 0.12, font: 'sans-serif', size: 150, color: '#7c2d12', upper: true, ay: 0.87, authorColor: '#ffedd5' }) },
    { id: 'poetry', name: 'Verso', category: 'Poesia', make: (c) => mk(c, { type: 'solid', color: '#fbf8f1' }, {}, [
      S({ shape: 'ring', x: c.w * 0.15, y: c.h * 0.15, w: c.w * 0.7, h: c.w * 0.7, fill: '#9ca3af', strokeW: 3 }),
      S({ shape: 'line', x: c.w * 0.4, y: c.h * 0.62, w: c.w * 0.2, h: 12, fill: '#9ca3af', strokeW: 3 })], { ty: 0.34, th: 0.2, font: 'serif', italic: true, bold: false, size: 130, color: '#1f2937', ay: 0.8, authorColor: '#6b7280' }) },
    { id: 'history', name: 'Pergaminho', category: 'História', make: (c) => mk(c, { type: 'gradient', from: '#78350f', to: '#451a03', angle: 180 }, { vignette: 0.55 }, [
      S({ shape: 'rect', x: c.w * 0.07, y: c.h * 0.05, w: c.w * 0.86, h: c.h * 0.9, fill: 'rgba(0,0,0,0)', stroke: '#fcd34d', strokeW: 4 }),
      S({ shape: 'diamond', x: c.w * 0.45, y: c.h * 0.1, w: c.w * 0.1, h: c.w * 0.14, fill: '#fcd34d' })], { ty: 0.34, font: 'serif', size: 140, color: '#fef3c7', upper: true, spacing: 3, ay: 0.82, authorColor: '#fcd34d' }) },
    { id: 'religion', name: 'Luz', category: 'Religião', make: (c) => mk(c, { type: 'gradient', from: '#1e3a8a', to: '#0b1226', angle: 180 }, { vignette: 0.3 }, [
      S({ shape: 'circle', x: c.w * 0.2, y: c.h * 0.06, w: c.w * 0.6, h: c.w * 0.6, fill: '#fde68a', opacity: 0.2 }),
      S({ shape: 'rect', x: c.w * 0.47, y: c.h * 0.12, w: c.w * 0.06, h: c.h * 0.26, fill: '#fcd34d' }), S({ shape: 'rect', x: c.w * 0.36, y: c.h * 0.19, w: c.w * 0.28, h: c.w * 0.06, fill: '#fcd34d' })], { ty: 0.5, font: 'serif', size: 140, color: '#fef3c7', ay: 0.86, authorColor: '#fcd34d' }) },
    { id: 'minimal', name: 'Minimalista', category: 'Outros', make: (c) => mk(c, { type: 'solid', color: '#ffffff' }, {}, [
      S({ shape: 'rect', x: c.w * 0.1, y: c.h * 0.1, w: c.w * 0.14, h: c.h * 0.34, fill: '#2563eb' })], { ty: 0.5, font: 'sans-serif', size: 130, color: '#111827', align: 'left', ay: 0.88, authorColor: '#2563eb' }) },
    { id: 'bold-blue', name: 'Azul Intenso', category: 'Outros', make: (c) => mk(c, { type: 'gradient', from: '#1d4ed8', to: '#0b1226', angle: 160 }, { vignette: 0.3 }, [
      S({ shape: 'circle', x: c.w * 0.5, y: -c.h * 0.05, w: c.w * 0.7, h: c.w * 0.7, fill: '#60a5fa', opacity: 0.3 }),
      S({ shape: 'triangle', x: c.w * 0.05, y: c.h * 0.55, w: c.w * 0.3, h: c.w * 0.3, fill: '#93c5fd', opacity: 0.35 })], { ty: 0.38, font: 'sans-serif', size: 140, color: '#ffffff', upper: true, ay: 0.88, authorColor: '#bfdbfe' }) },
    { id: 'blank', name: 'Em branco', category: 'Outros', make: (c) => { const d = C.newDesign(c.w, c.h); d.bg = { type: 'solid', color: '#111827' }; return d; } }
  ];
  C.TEMPLATES = LIST;

  /** Modelos ordenados com os da categoria do livro primeiro. */
  C.templatesFor = function (category) {
    return LIST.slice().sort((a, b) => (b.category === category) - (a.category === category));
  };

  C.ctxFor = function (book, size) {
    return { w: size.w, h: size.h, title: book.title, subtitle: book.subtitle, author: book.author };
  };
  C.fromTemplate = function (tpl, book, size) { return tpl.make(C.ctxFor(book, size)); };

  /** Contracapa coerente com a frente: mesmo fundo/efeitos + sinopse, autor e ISBN. */
  C.makeBack = function (front, book) {
    const w = front.w, h = front.h, d = C.newDesign(w, h);
    d.bg = JSON.parse(JSON.stringify(front.bg)); d.fx = Object.assign({}, front.fx);
    d.els = front.els.filter((e) => e.type === 'shape' && (e.stroke || e.shape === 'rect') && e.w > w * 0.8 && e.h > h * 0.6).map((e) => JSON.parse(JSON.stringify(e)));
    const dark = C.isDark(d.bg.type === 'gradient' ? d.bg.from : d.bg.color);
    const fg = dark ? '#f1f5f9' : '#1f2937', muted = dark ? '#cbd5e1' : '#475569';
    d.els.push(T({ id: 'bk-head', role: 'blurb-title', x: w * 0.12, y: h * 0.1, w: w * 0.76, h: h * 0.08, text: book.title, font: 'serif', size: Math.round(w * 0.05), color: fg, bold: true, align: 'left', valign: 'top' }));
    d.els.push(T({ id: 'bk-desc', role: 'blurb', x: w * 0.12, y: h * 0.2, w: w * 0.76, h: h * 0.5, text: book.description || 'Escreva aqui a sinopse do livro: o que o leitor vai encontrar, a quem se destina e porque vale a pena lê-lo.', font: 'serif', size: Math.round(w * 0.038), color: fg, align: 'left', valign: 'top', lineH: 1.4 }));
    d.els.push(T({ id: 'bk-author', role: 'author', x: w * 0.12, y: h * 0.74, w: w * 0.76, h: h * 0.05, text: book.author || '', font: 'sans-serif', size: Math.round(w * 0.034), color: muted, upper: true, spacing: 4, bold: true, align: 'left', valign: 'top' }));
    d.els.push(S({ id: 'bk-isbn-box', shape: 'rect', x: w * 0.12, y: h * 0.82, w: w * 0.4, h: h * 0.1, fill: '#ffffff', radius: 8 }));
    d.els.push(T({ id: 'bk-isbn', role: 'isbn', x: w * 0.12, y: h * 0.82, w: w * 0.4, h: h * 0.1, text: book.isbn ? 'ISBN ' + book.isbn : 'ISBN', font: 'monospace', size: Math.round(w * 0.03), color: '#111827', align: 'center' }));
    return d;
  };

  /** Lombada: título e autor na vertical. */
  C.makeSpine = function (front, book, w, h) {
    const d = C.newDesign(w, h);
    d.bg = JSON.parse(JSON.stringify(front.bg)); d.fx = Object.assign({}, front.fx);
    const dark = C.isDark(d.bg.type === 'gradient' ? d.bg.from : d.bg.color);
    const fg = dark ? '#f8fafc' : '#111827';
    const tl = h * 0.62;
    d.els.push(T({ id: 'sp-title', role: 'title', x: w / 2 - tl / 2, y: h * 0.4 - w * 0.5 + (w * 0.5 - w * 0.33) , w: tl, h: w * 0.66, text: book.title, font: 'serif', size: Math.round(w * 0.42), color: fg, bold: true, rot: 90, align: 'left', valign: 'middle' }));
    d.els.push(T({ id: 'sp-author', role: 'author', x: w / 2 - h * 0.14, y: h * 0.86 - w * 0.2, w: h * 0.28, h: w * 0.4, text: book.author || '', font: 'sans-serif', size: Math.round(w * 0.3), color: fg, upper: true, spacing: 3, rot: 90, align: 'center', valign: 'middle' }));
    return d;
  };
})();
