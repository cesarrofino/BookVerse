/* BookVerse — diálogos do editor */
(function () {
  'use strict';
  const BV = window.BV;
  const h = BV.h, icon = BV.icon, t = (s) => BV.t(s);

  /* ----- campos de formulário reutilizáveis ----- */
  BV.field = function (label, control, hint) {
    return h('div', { class: 'field' }, label ? h('label', null, label) : null, control, hint ? h('small', { style: { color: 'var(--muted)' } }, hint) : null);
  };
  BV.select = function (options, value, onchange) {
    const s = h('select', { class: 'input', onchange: () => onchange && onchange(s.value) },
      options.map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o]; return h('option', { value: v, selected: String(v) === String(value) }, t(l)); }));
    return s;
  };
  BV.switchEl = function (checked, onchange) {
    const i = h('input', { type: 'checkbox', onchange: () => onchange && onchange(i.checked) });
    i.checked = !!checked;
    return h('label', { class: 'switch' }, i, h('i'));
  };

  /* ----- fonte, tamanho, cor ----- */
  BV.fontMenu = function (ed) {
    BV.menu(t('Tipo de letra'), BV.model.FONTS.map(([k, l]) => ({ label: t(l), onClick: () => ed.setFont(k) })));
  };
  BV.sizeDialog = function (ed) {
    const sizes = [8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 24, 28, 32, 40, 48, 64];
    const input = h('input', { class: 'input', type: 'number', min: 6, max: 96, step: 0.5, placeholder: 'pt' });
    const m = BV.modal({ title: t('Tamanho da fonte'), body: h('div', null,
      h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '12px' } }, sizes.map((s) => h('button', { class: 'chip', onclick: () => { ed.setSizePt(s); m.close(); } }, s + ' pt'))),
      BV.field(t('Personalizado (pt)'), input)),
      actions: [{ label: t('Aplicar'), primary: true, onClick: () => { const v = parseFloat(input.value); if (v >= 6 && v <= 96) ed.setSizePt(v); else return false; } }] });
  };
  const SWATCHES = ['#000000', '#374151', '#6b7280', '#9ca3af', '#ffffff', '#ef4444', '#f97316', '#f59e0b', '#eab308', '#84cc16', '#22c55e', '#14b8a6', '#06b6d4', '#3b82f6', '#6366f1', '#8b5cf6', '#d946ef', '#ec4899', '#7f1d1d', '#1e3a8a', '#14532d', '#78350f', '#fef08a', '#bbf7d0', '#bfdbfe', '#fbcfe8'];
  BV.colorDialog = function (title, initial, cb, allowNone) {
    const custom = h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(initial) ? initial : '#000000' });
    const m = BV.modal({ title, body: h('div', null,
      h('div', { class: 'swatches' }, SWATCHES.map((c) => h('button', { class: 'swatch', style: { background: c }, 'aria-label': c, onclick: () => { cb(c); m.close(); } }))),
      h('div', { class: 'row', style: { alignItems: 'center', marginTop: '14px' } }, h('span', { style: { flex: 'none', color: 'var(--muted)' } }, t('Personalizada')), custom,
        h('button', { class: 'btn sm', style: { flex: 'none' }, onclick: () => { cb(custom.value); m.close(); } }, t('Aplicar')))),
      actions: allowNone ? [{ label: t('Sem cor'), onClick: () => { cb(null); } }] : [] });
  };

  /* ----- parágrafo ----- */
  BV.blockMenu = function (ed) {
    BV.menu(t('Estilo do parágrafo'), [
      { icon: 'text', label: t('Parágrafo normal'), onClick: () => ed.setBlock('p') },
      { icon: 'heading', label: t('Título de secção (Título 2)'), onClick: () => ed.setBlock('h2') },
      { icon: 'heading', label: t('Subtítulo (Título 3)'), onClick: () => ed.setBlock('h3') },
      { icon: 'quote', label: t('Citação'), onClick: () => ed.setBlock('blockquote') }]);
  };
  BV.spacingDialog = function (ed, kind) {
    const cfg = {
      line: { title: t('Espaçamento entre linhas'), opts: [1, 1.15, 1.3, 1.5, 1.75, 2, 2.5], fmt: (v) => v + '×', apply: (v) => ed.setLineHeight(String(v)) },
      para: { title: t('Espaçamento entre parágrafos'), opts: [0, 4, 8, 12, 16, 24], fmt: (v) => v + ' pt', apply: (v) => ed.setParaSpacing(v) },
      indent: { title: t('Recuo da primeira linha'), opts: [0, 5, 8, 10, 12, 15], fmt: (v) => (v ? v + ' mm' : t('Nenhum')), apply: (v) => ed.setFirstLineIndent(v) }
    }[kind];
    const m = BV.modal({ title: cfg.title, body: h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '8px' } },
      cfg.opts.map((v) => h('button', { class: 'chip', onclick: () => { cfg.apply(v); m.close(); } }, cfg.fmt(v)))) });
  };

  /* ----- inserir ----- */
  BV.tableDialog = function (ed) {
    const rows = h('input', { class: 'input', type: 'number', min: 1, max: 30, value: 3 });
    const cols = h('input', { class: 'input', type: 'number', min: 1, max: 8, value: 3 });
    const head = BV.switchEl(true);
    BV.modal({ title: t('Inserir tabela'), body: h('div', null, h('div', { class: 'row' }, BV.field(t('Linhas'), rows), BV.field(t('Colunas'), cols)),
      h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' } }, h('span', null, t('Primeira linha como cabeçalho')), head)),
      actions: [{ label: t('Inserir'), primary: true, onClick: () => { const r = Math.min(30, Math.max(1, +rows.value || 3)), c = Math.min(8, Math.max(1, +cols.value || 3)); ed.insertTable(r, c, head.querySelector('input').checked); } }] });
  };
  BV.separatorMenu = function (ed) {
    BV.menu(t('Separador'), [{ icon: 'minus', label: t('Linha'), onClick: () => ed.insertSeparator('line') }, { icon: 'sparkle', label: t('Ornamento  ∗ ∗ ∗'), onClick: () => ed.insertSeparator('orn') }]);
  };
  BV.linkDialog = function (ed) {
    const sel = ed.selectedText() || (ed.lastRange ? ed.lastRange.toString() : '');
    const text = h('input', { class: 'input', value: sel, placeholder: t('Texto do link') });
    const url = h('input', { class: 'input', type: 'url', placeholder: 'https://…', value: 'https://' });
    BV.modal({ title: t('Inserir link'), body: h('div', null, sel ? null : BV.field(t('Texto'), text), BV.field('URL', url)),
      actions: [{ label: t('Remover link'), onClick: () => { ed.removeLink(); } },
        { label: t('Inserir'), primary: true, onClick: () => { const u = url.value.trim(); if (!/^(https?:\/\/|mailto:)/i.test(u)) { BV.toast(t('Introduza um endereço válido (http, https ou mailto)'), 'error'); return false; } ed.insertLink(u, text.value.trim() || u); } }] });
  };

  /* ----- localizar e substituir (barra flutuante: mantém a seleção visível) ----- */
  BV.findDialog = function (ed) {
    const host = BV.$('.ed-main'); const old = BV.$('.find-bar', host); if (old) { old.remove(); return; }
    const q = h('input', { class: 'input', placeholder: t('Localizar…'), enterkeyhint: 'search' });
    const r = h('input', { class: 'input', placeholder: t('Substituir por…') });
    const count = h('span', { class: 'chip' }, '0/0');
    const cs = h('input', { type: 'checkbox' });
    const run = () => { const n = ed.findAll(q.value, cs.checked); count.textContent = (n ? '1' : '0') + '/' + n; if (n) ed.gotoMatch(0); };
    const step = (back) => { if (!ed.matches || !ed.matches.length) run(); else { const i = ed.findNext(back); count.textContent = (i + 1) + '/' + ed.matches.length; } };
    q.addEventListener('input', BV.debounce(run, 250));
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') step(e.shiftKey); });
    const bar = h('div', { class: 'find-bar glass' },
      h('div', { class: 'row', style: { alignItems: 'center' } }, q, count,
        h('button', { class: 'icon-btn', onclick: () => step(true) }, icon('up')), h('button', { class: 'icon-btn', onclick: () => step(false) }, icon('down')),
        h('button', { class: 'icon-btn', onclick: () => bar.remove() }, icon('close'))),
      h('div', { class: 'row', style: { alignItems: 'center', marginTop: '6px' } }, r,
        h('button', { class: 'btn sm', style: { flex: 'none' }, onclick: () => { if (ed.replaceCurrent(r.value)) { const n = ed.findAll(q.value, cs.checked); count.textContent = (n ? '1' : '0') + '/' + n; if (n) ed.gotoMatch(Math.max(0, Math.min(ed.mi || 0, n - 1))); } } }, t('Substituir')),
        h('button', { class: 'btn sm', style: { flex: 'none' }, onclick: () => { const n = ed.replaceAll(q.value, r.value, cs.checked); count.textContent = '0/0'; BV.toast(n + ' ' + t('substituições'), 'ok'); } }, t('Todas'))),
      h('label', { class: 'cs-label' }, cs, ' ', t('Distinguir maiúsculas')));
    cs.addEventListener('change', run);
    host.appendChild(bar);
    const sel = ed.selectedText(); if (sel && sel.length < 60) { q.value = sel; run(); }
    setTimeout(() => q.focus(), 50);
  };

  /* ----- cabeçalho e rodapé ----- */
  BV.headerFooterDialog = function (book, done) {
    const L = book.doc.layout;
    const hEn = BV.switchEl(L.header.enabled), fEn = BV.switchEl(L.footer.enabled), pn = BV.switchEl(L.footer.pageNumbers);
    const hMode = BV.select([['title', 'Título do livro'], ['author', 'Nome do autor'], ['custom', 'Texto personalizado']], L.header.mode);
    const hText = h('input', { class: 'input', value: L.header.text, placeholder: t('Texto do cabeçalho') });
    const fText = h('input', { class: 'input', value: L.footer.text, placeholder: t('Texto do rodapé (opcional)') });
    const row = (l, c) => h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '6px 0 12px' } }, h('span', null, l), c);
    BV.modal({ title: t('Cabeçalho e rodapé'), body: h('div', null,
      h('h4', { style: { margin: '4px 0' } }, t('Cabeçalho')), row(t('Mostrar cabeçalho'), hEn), BV.field(t('Conteúdo'), hMode), BV.field(t('Texto personalizado'), hText),
      h('h4', { style: { margin: '12px 0 4px' } }, t('Rodapé')), row(t('Mostrar rodapé'), fEn), row(t('Numeração de páginas'), pn), BV.field(t('Texto'), fText),
      h('small', { style: { color: 'var(--muted)' } }, t('O cabeçalho não aparece na primeira página de cada capítulo nem nas páginas iniciais.'))),
      actions: [{ label: t('Guardar'), primary: true, onClick: () => {
        L.header = { enabled: hEn.querySelector('input').checked, mode: hMode.value, text: hText.value };
        L.footer = { enabled: fEn.querySelector('input').checked, pageNumbers: pn.querySelector('input').checked, text: fText.value };
        done && done();
      } }] });
  };

  /* ----- página, margens e tipografia ----- */
  BV.layoutDialog = function (book, done) {
    const L = book.doc.layout, M = L.margins;
    const size = BV.select(Object.keys(BV.model.PAGE_SIZES), L.pageSize);
    const orient = BV.select([['portrait', 'Vertical'], ['landscape', 'Horizontal']], L.landscape ? 'landscape' : 'portrait');
    const num = (v, min, max, step) => h('input', { class: 'input', type: 'number', min, max, step: step || 1, value: v });
    const mt = num(M.top, 5, 60), mb = num(M.bottom, 5, 60), mi = num(M.inner, 5, 60), mo = num(M.outer, 5, 60);
    const font = BV.select(BV.model.FONTS, L.fontFamily);
    const fs = num(L.fontSizePt, 6, 40, 0.5), lh = num(L.lineHeight, 1, 3, 0.05), ps = num(L.paraSpacingPt, 0, 40), fi = num(L.firstLineIndentMm || 0, 0, 30);
    BV.modal({ title: t('Página, margens e tipografia'), body: h('div', null,
      h('div', { class: 'row' }, BV.field(t('Tamanho da página'), size), BV.field(t('Orientação'), orient)),
      h('h4', { style: { margin: '4px 0 8px' } }, t('Margens (mm)')),
      h('div', { class: 'row' }, BV.field(t('Superior'), mt), BV.field(t('Inferior'), mb)),
      h('div', { class: 'row' }, BV.field(t('Interior'), mi), BV.field(t('Exterior'), mo)),
      h('h4', { style: { margin: '4px 0 8px' } }, t('Texto')),
      BV.field(t('Tipo de letra'), font),
      h('div', { class: 'row' }, BV.field(t('Tamanho (pt)'), fs), BV.field(t('Entrelinha'), lh)),
      h('div', { class: 'row' }, BV.field(t('Espaço entre parágrafos (pt)'), ps), BV.field(t('Recuo 1.ª linha (mm)'), fi))),
      actions: [{ label: t('Aplicar'), primary: true, onClick: () => {
        const pg = BV.model.PAGE_SIZES[size.value];
        const m = { top: +mt.value, bottom: +mb.value, inner: +mi.value, outer: +mo.value };
        const w = orient.value === 'landscape' ? pg[1] : pg[0], hh = orient.value === 'landscape' ? pg[0] : pg[1];
        if (m.inner + m.outer > w - 40 || m.top + m.bottom > hh - 40) { BV.toast(t('Margens demasiado grandes para este tamanho de página'), 'error'); return false; }
        Object.assign(L, { pageSize: size.value, landscape: orient.value === 'landscape', margins: m, fontFamily: font.value,
          fontSizePt: +fs.value || 12, lineHeight: +lh.value || 1.5, paraSpacingPt: +ps.value || 0, firstLineIndentMm: +fi.value || 0 });
        done && done();
      } }] });
  };

  /* ----- estrutura do livro ----- */
  BV.structureDialog = function (book, done) {
    const d = book.doc;
    const rows = BV.model.STRUCTURE.map((s) => {
      if (s.key === 'chapters') return h('div', { class: 'struct-row' }, h('span', null, t(s.label), h('small', null, t('Sempre incluídos'))), h('span', { class: 'chip' }, d.chapters.length));
      const sw = BV.switchEl(d.structure[s.key], (v) => { d.structure[s.key] = v; });
      return h('div', { class: 'struct-row' }, h('span', null, t(s.label), h('small', null, s.kind === 'auto' ? t('Gerado automaticamente') : t('Página editável'))), sw);
    });
    BV.modal({ title: t('Estrutura do livro'), body: h('div', null,
      h('p', { style: { color: 'var(--text-2)', margin: '0 0 10px' } }, t('Ative ou desative cada elemento. O índice é gerado a partir dos capítulos e títulos.')), rows),
      actions: [{ label: t('Concluir'), primary: true, onClick: () => { done && done(); } }] });
  };

  /* ----- versões ----- */
  BV.versionsDialog = async function (book, onRestore) {
    let list = [];
    try { await BV.store.saveNow(); list = await BV.native('books.versions', { id: book.id }); } catch (e) { BV.error(e); return; }
    const body = list.length ? h('div', { class: 'menu-list' }, list.map((v) => h('div', { class: 'ver-row' },
      h('div', null, h('strong', null, v.label), h('small', { style: { display: 'block', color: 'var(--muted)' } }, BV.fmtDate(v.createdAt) + ' · ' + BV.fmtNum(v.wordCount) + ' ' + t('palavras'))),
      h('button', { class: 'btn sm', onclick: async () => {
        if (!(await BV.confirm(t('Restaurar esta versão? O estado atual fica guardado como nova versão.')))) return;
        try { const nb = await BV.native('books.restoreVersion', { vid: v.vid }); BV.closeTopModal(); nb.doc = BV.model.normalizeDoc(nb.doc, BV.store.settings); BV.toast(t('Versão restaurada'), 'ok'); onRestore && onRestore(nb); } catch (e) { BV.error(e); }
      } }, t('Restaurar')))))
      : h('div', { class: 'empty' }, t('Ainda não existem versões anteriores. São criadas automaticamente enquanto escreve.'));
    BV.modal({ title: t('Versões anteriores'), body, actions: [{ label: t('Guardar versão agora'), onClick: async () => { try { await BV.native('books.snapshot', { id: book.id, label: 'Versão manual' }); BV.toast(t('Versão guardada'), 'ok'); } catch (e) { BV.error(e); } } }] });
  };

  /* ----- informações do livro (formulário partilhado com "novo livro") ----- */
  BV.bookForm = function (b) {
    const f = {};
    const inp = (k, ph, type) => (f[k] = h('input', { class: 'input', value: b[k] || '', placeholder: ph || '', type: type || 'text', autocomplete: 'off' }));
    f.description = h('textarea', { class: 'input', rows: 4, placeholder: t('Sobre o que é este livro?') }, b.description || '');
    f.category = BV.select(BV.model.CATEGORIES, b.category || 'Outros');
    f.language = BV.select(BV.model.LANGUAGES, b.language || 'pt');
    const el = h('div', null,
      BV.field(t('Título') + ' *', inp('title', t('O título do seu livro'))), BV.field(t('Subtítulo'), inp('subtitle')),
      BV.field(t('Nome do autor'), inp('author')), BV.field(t('Descrição'), f.description),
      h('div', { class: 'row' }, BV.field(t('Categoria'), f.category), BV.field(t('Idioma'), f.language)),
      h('div', { class: 'row' }, BV.field(t('Editora'), inp('publisher')), BV.field(t('Ano de publicação'), inp('year', '', 'number'))),
      BV.field(t('Direitos autorais'), inp('copyright', '© 2026 Nome do autor. Todos os direitos reservados.')), BV.field(t('ISBN (opcional)'), inp('isbn')));
    const read = () => ({ title: f.title.value.trim(), subtitle: f.subtitle.value.trim(), author: f.author.value.trim(), description: f.description.value.trim(),
      category: f.category.value, language: f.language.value, publisher: f.publisher.value.trim(), year: f.year.value.trim(), copyright: f.copyright.value.trim(), isbn: f.isbn.value.trim() });
    return { el, read, fields: f };
  };
  BV.bookInfoDialog = function (book, done) {
    const form = BV.bookForm(book);
    BV.modal({ title: t('Informações do livro'), body: form.el, actions: [{ label: t('Guardar'), primary: true, onClick: () => {
      const v = form.read(); if (!v.title) { BV.toast(t('O título é obrigatório'), 'error'); return false; }
      Object.assign(book, v); done && done();
    } }] });
  };
})();
