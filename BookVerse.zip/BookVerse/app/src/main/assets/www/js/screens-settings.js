/* BookVerse — definições, conta, sincronização, backup e armazenamento */
(function () {
  'use strict';
  const BV = window.BV, store = BV.store;
  const h = BV.h, icon = BV.icon, t = (s) => BV.t(s);
  const St = (BV.settingsScreen = {});

  const PRIVACY = [
    ['Dados guardados no dispositivo', 'Os seus livros, capas e imagens são guardados localmente, numa base de dados privada da aplicação. Nada é enviado para a internet sem iniciar sessão.'],
    ['Sincronização opcional', 'Se criar uma conta, os seus livros são sincronizados com o Firebase (Google) na sua área privada: apenas a sua conta consegue ler ou escrever nesses dados. Pode eliminar os dados da nuvem a qualquer momento nas definições.'],
    ['Sem publicidade nem rastreio', 'O BookVerse não contém publicidade, análise de utilização nem inteligência artificial. Não partilhamos os seus dados com terceiros.'],
    ['Permissões', 'A aplicação só usa a internet (para a sincronização) e os seletores do sistema para escolher imagens, guardar ou abrir ficheiros. Não pede acesso geral ao armazenamento.'],
    ['Os seus direitos', 'Pode exportar tudo através de um backup, apagar a sua cópia na nuvem e eliminar a aplicação para remover os dados locais.']
  ];

  const row = (label, sub, control, cls) => h('div', { class: 'set-row' + (cls ? ' ' + cls : '') }, h('div', { class: 'set-l' }, h('div', null, label), sub ? h('small', null, sub) : null), control || null);
  const group = (title, ...rows) => h('div', { class: 'set-group' }, h('h4', null, title), h('div', { class: 'card' }, rows));

  St.render = async function (params) {
    params = params || {};
    const s = BV.clear(BV.$('#screen-settings'));
    const S = store.settings;
    const set = (k) => (v) => { store.setSetting(k, v); if (k === 'autosaveSeconds') store.updateAutosaveDelay(); };

    const themeSeg = h('div', { class: 'seg' }, [['light', 'Claro', 'sun'], ['dark', 'Escuro', 'moon'], ['auto', 'Automático', 'cog']].map(([k, l]) =>
      h('button', { class: S.theme === k ? 'on' : '', onclick: () => { store.setSetting('theme', k); BV.applyTheme(); St.render(); } }, t(l))));
    const num = (k, min, max, step) => { const i = h('input', { class: 'input mini', type: 'number', min, max, step: step || 1, value: S[k], onchange: () => { const v = parseFloat(i.value); if (v >= min && v <= max) set(k)(String(v)); else i.value = S[k]; } }); return i; };

    const user = store.user;
    const acct = h('div', { class: 'card acct', onclick: () => BV.go('account') }, BV.avatar(52),
      h('div', { class: 'grow' }, h('strong', null, user.signedIn ? (user.name || user.email) : t('Sem sessão iniciada')),
        h('small', null, user.signedIn ? user.email : t('Entre para sincronizar os seus livros entre dispositivos'))), icon('forward'));

    const syncBox = h('div', { class: 'card', id: 'sync-card' });
    s.append(h('div', { class: 'topbar' }, h('button', { class: 'icon-btn', onclick: () => BV.go('home') }, icon('back')), h('h2', null, t('Definições'))),
      h('div', { class: 'scroll set-scroll' }, h('div', { class: 'set-wrap' }, acct,
        group(t('Aparência'), row(t('Tema'), null, themeSeg),
          row(t('Idioma da interface'), null, BV.select([['pt', 'Português'], ['en', 'English']], S.language, (v) => { store.setSetting('language', v); BV.setLang(v); St.render(); }))),
        group(t('Escrita'),
          row(t('Fonte padrão'), null, BV.select(BV.model.FONTS, S.defaultFont, set('defaultFont'))),
          row(t('Tamanho padrão da fonte (pt)'), null, num('defaultFontSize', 8, 32, 0.5)),
          row(t('Espaçamento entre linhas'), null, num('lineHeight', 1, 3, 0.05)),
          row(t('Espaço entre parágrafos (pt)'), null, num('paragraphSpacing', 0, 40)),
          row(t('Margens padrão (mm)'), t('Aplicam-se a livros novos'), h('div', { class: 'mini-row' }, num('marginTop', 5, 60), num('marginBottom', 5, 60), num('marginInner', 5, 60), num('marginOuter', 5, 60)), 'stack'),
          row(t('Salvamento automático'), t('O trabalho é sempre guardado localmente primeiro'), BV.switchEl(S.autosave !== 'false', (v) => set('autosave')(String(v)))),
          row(t('Intervalo de gravação (s)'), null, num('autosaveSeconds', 1, 30))),
        group(t('Preferências de exportação'),
          row(t('Tamanho da página'), null, BV.select(Object.keys(BV.model.PAGE_SIZES), S.exportPageSize, set('exportPageSize'))),
          row(t('Orientação'), null, BV.select([['portrait', 'Vertical'], ['landscape', 'Horizontal']], S.exportOrientation, set('exportOrientation'))),
          row(t('Qualidade das imagens'), null, BV.select([['high', 'Alta'], ['medium', 'Média'], ['low', 'Baixa']], S.exportImageQuality, set('exportImageQuality'))),
          row(t('Incluir contracapa'), null, BV.switchEl(S.exportIncludeBackCover !== 'false', (v) => set('exportIncludeBackCover')(String(v))))),
        h('div', { class: 'set-group', id: 'sync-group' }, h('h4', null, t('Sincronização')), syncBox),
        group(t('Backup'),
          row(t('Criar backup'), t('Guarda todos os livros e imagens num ficheiro .bvbackup'), h('button', { class: 'btn sm', onclick: doBackup }, icon('download', 'sm'), t('Exportar'))),
          row(t('Restaurar backup'), t('Importa livros de um ficheiro .bvbackup'), h('button', { class: 'btn sm', onclick: doRestore }, icon('upload', 'sm'), t('Importar')))),
        h('div', { class: 'set-group' }, h('h4', null, t('Armazenamento')), h('div', { class: 'card', id: 'storage-card' })),
        group(t('Sobre'),
          row(t('Política de privacidade'), null, h('button', { class: 'btn sm', onclick: showPrivacy }, t('Ler'))),
          row(t('Sobre o BookVerse'), t('Criação, edição e publicação de livros digitais'), h('button', { class: 'btn sm', onclick: showAbout }, t('Ver'))),
          row(t('Versão instalada'), null, h('span', { class: 'chip', id: 'app-version' }, '…'))),
        h('div', { style: { height: '100px' } }))),
      BV.navBar('settings'));
    renderSync(syncBox); renderStorage(); loadVersion();
    if (params.section === 'sync') setTimeout(() => { const g = BV.$('#sync-group'); if (g) g.scrollIntoView({ behavior: 'smooth' }); }, 200);
  };

  async function loadVersion() { try { const i = await BV.native('app.info'); const el = BV.$('#app-version'); if (el) el.textContent = i.version + ' (' + i.code + ')'; } catch (e) { /* ignora */ } }

  async function renderStorage() {
    const box = BV.$('#storage-card'); if (!box) return;
    try {
      const i = await BV.native('storage.info');
      BV.append(BV.clear(box), [row(t('Livros'), null, h('span', { class: 'chip' }, i.books)), row(t('Imagens e capas'), null, h('span', { class: 'chip' }, BV.fmtBytes(i.media))), row(t('Base de dados'), null, h('span', { class: 'chip' }, BV.fmtBytes(i.database))),
        row(t('Ficheiros exportados'), t('Podem ser removidos sem afetar os livros'), h('span', { class: 'row-act' }, h('span', { class: 'chip' }, BV.fmtBytes(i.exports)), h('button', { class: 'btn sm', onclick: async () => { await BV.native('storage.clearExports'); BV.toast(t('Exportações removidas'), 'ok'); renderStorage(); } }, t('Limpar')))),
        row(t('Espaço livre no dispositivo'), null, h('span', { class: 'chip' }, BV.fmtBytes(i.free)))]);
    } catch (e) { box.textContent = e.message; }
  }

  async function doBackup() { try { const r = await BV.native('backup.export'); if (!r.cancelled) BV.toast(r.count + ' ' + t('livros guardados no backup'), 'ok'); } catch (e) { BV.error(e); } }
  async function doRestore() {
    try {
      const r = await BV.native('backup.import');
      if (!r.cancelled) { BV.toast(r.count + ' ' + t('livros importados'), 'ok'); renderStorage(); }
    } catch (e) { BV.error(e); }
  }
  function showPrivacy() { BV.modal({ title: t('Política de privacidade'), body: h('div', { class: 'selectable' }, PRIVACY.map(([a, b]) => h('div', { style: { marginBottom: '14px' } }, h('strong', null, t(a)), h('p', { style: { margin: '4px 0 0', color: 'var(--text-2)' } }, t(b))))) }); }
  function showAbout() { BV.modal({ title: 'BookVerse', body: h('div', null, BV.logo(44), h('p', { style: { color: 'var(--text-2)' } }, t('Aplicação para escrever, editar, desenhar capas, organizar, visualizar, exportar (PDF, EPUB, DOCX, TXT) e partilhar livros digitais. Funciona offline; a internet só é usada para contas e sincronização.')), h('p', { style: { color: 'var(--muted)' } }, t('Sem publicidade. Sem inteligência artificial.'))) }); }

  /* ---------- sincronização ---------- */
  function ago(ts) { return ts ? BV.fmtDate(ts) : t('nunca'); }
  async function renderSync(box) {
    box = box || BV.$('#sync-card'); if (!box) return;
    let st;
    try { st = await BV.native('sync.status'); } catch (e) { box.textContent = e.message; return; }
    const S = store.settings;
    const state = !st.configured ? t('Firebase não configurado') : !st.signedIn ? t('Sem sessão') : st.running ? t('A sincronizar…') : st.lastError ? t('Erro') : st.pending > 0 ? t('Pendente') : t('Sincronizado');
    const cls = !st.configured || !st.signedIn ? '' : st.running ? 'running' : st.lastError ? 'error' : st.pending > 0 ? 'pending' : 'synced';
    BV.append(BV.clear(box), [
      row(t('Estado'), st.lastError && st.signedIn ? st.lastError : (!st.configured ? t('Consulte o README para configurar o Firebase') : null), h('span', { class: 'chip' }, h('i', { class: 'sync-dot ' + cls }), state)),
      row(t('Alterações por enviar'), null, h('span', { class: 'chip' }, st.pending)),
      row(t('Última sincronização'), st.conflicts ? st.conflicts + ' ' + t('conflito(s) resolvido(s): as duas versões ficam em "Versões anteriores"') : null, h('span', { class: 'chip' }, ago(st.lastSyncAt))),
      row(t('Sincronização automática'), null, BV.switchEl(S.syncAuto !== 'false', (v) => store.setSetting('syncAuto', String(v)))),
      row(t('Só com Wi-Fi'), null, BV.switchEl(S.syncWifiOnly === 'true', (v) => store.setSetting('syncWifiOnly', String(v)))),
      row(t('Sincronizar agora'), null, h('button', { class: 'btn sm primary', onclick: syncNow, disabled: !st.configured || !st.signedIn }, icon('refresh', 'sm'), t('Sincronizar'))),
      st.signedIn ? row(t('Eliminar dados da nuvem'), t('Os livros neste dispositivo não são alterados'), h('button', { class: 'btn sm danger', onclick: wipeCloud }, icon('trash', 'sm'), t('Eliminar'))) : null]);
  }
  async function syncNow() {
    const b = BV.busy(t('A sincronizar…'));
    try { const r = await BV.native('sync.now'); b.done(); BV.toast(r.errors ? t('Sincronização com erros') + (r.message ? ': ' + r.message : '') : t('Sincronizado') + ' · ↑' + r.pushed + ' ↓' + r.pulled, r.errors ? 'error' : 'ok'); }
    catch (e) { b.done(); BV.error(e); }
    renderSync(); BV.updateSyncDots && BV.updateSyncDots();
  }
  async function wipeCloud() {
    if (!(await BV.confirm(t('Eliminar todos os livros guardados na nuvem? Os livros neste dispositivo mantêm-se.'), { danger: true, ok: t('Eliminar') }))) return;
    const b = BV.busy(t('A eliminar…'));
    try { await BV.native('sync.wipeCloud'); b.done(); BV.toast(t('Dados da nuvem eliminados'), 'ok'); } catch (e) { b.done(); BV.error(e); }
    renderSync();
  }

  /* ---------- conta e perfil ---------- */
  St.renderAccount = async function () {
    const s = BV.clear(BV.$('#screen-account'));
    await store.loadUser();
    const u = store.user;
    const top = h('div', { class: 'topbar' }, h('button', { class: 'icon-btn', onclick: () => BV.go('settings') }, icon('back')), h('h2', null, t('Conta e perfil')));
    const body = h('div', { class: 'form-wrap' });
    if (!u.configured) {
      body.append(h('div', { class: 'card pad' }, h('h3', null, t('Firebase não configurado')), h('p', { style: { color: 'var(--text-2)' } }, t('As contas e a sincronização precisam do ficheiro google-services.json do seu projeto Firebase. Siga as instruções do README. Entretanto, o BookVerse funciona normalmente offline.'))));
    } else if (u.signedIn) {
      const name = h('input', { class: 'input', value: u.name || '', placeholder: t('Nome do autor') });
      const bio = h('textarea', { class: 'input', rows: 3, placeholder: t('Uma breve biografia (usada como "Sobre o autor")') });
      BV.native('auth.bio').then((b) => { bio.value = b || ''; }).catch(() => {});
      body.append(h('div', { class: 'card pad center' }, BV.avatar(72), h('h3', { style: { marginTop: '10px' } }, u.name || u.email), h('small', { style: { color: 'var(--muted)' } }, u.email + ' · ' + u.provider)),
        h('div', { style: { height: '14px' } }), BV.field(t('Nome do autor'), name), BV.field(t('Biografia'), bio),
        h('button', { class: 'btn primary block', onclick: async () => { try { const nu = await BV.native('auth.updateProfile', { name: name.value, bio: bio.value }); store.setUser(nu); BV.toast(t('Perfil guardado'), 'ok'); } catch (e) { BV.error(e); } } }, icon('check'), t('Guardar perfil')),
        h('div', { style: { height: '10px' } }),
        h('button', { class: 'btn block', onclick: async () => { try { const r = await BV.native('sync.now'); BV.toast(t('Sincronizado') + ' · ↑' + r.pushed + ' ↓' + r.pulled, r.errors ? 'error' : 'ok'); } catch (e) { BV.error(e); } } }, icon('refresh'), t('Sincronizar agora')),
        h('div', { style: { height: '10px' } }),
        h('button', { class: 'btn block danger', onclick: async () => {
          if (!(await BV.confirm(t('Terminar sessão? Os livros ficam guardados e voltam a aparecer quando iniciar sessão.'), { ok: t('Terminar sessão') }))) return;
          try { await store.flush(); const nu = await BV.native('auth.logout'); store.setUser(nu); BV.toast(t('Sessão terminada')); BV.go('home'); } catch (e) { BV.error(e); }
        } }, icon('logout'), t('Terminar sessão')));
    } else {
      let mode = 'login';
      const box = h('div');
      const draw = () => {
        BV.clear(box);
        const name = h('input', { class: 'input', placeholder: t('Nome') , autocomplete: 'name' });
        const email = h('input', { class: 'input', type: 'email', placeholder: 'email@exemplo.com', autocomplete: 'email' });
        const pass = h('input', { class: 'input', type: 'password', placeholder: t('Palavra-passe'), autocomplete: mode === 'login' ? 'current-password' : 'new-password' });
        const run = async (method, args) => {
          const b = BV.busy(t('Aguarde…'));
          try { const nu = await BV.native(method, args); store.setUser(nu); b.done(); BV.toast(t('Sessão iniciada'), 'ok'); BV.go('home'); } catch (e) { b.done(); BV.error(e); }
        };
        box.append(h('div', { class: 'seg block' }, [['login', 'Entrar'], ['register', 'Criar conta']].map(([k, l]) => h('button', { class: mode === k ? 'on' : '', onclick: () => { mode = k; draw(); } }, t(l)))), h('div', { style: { height: '14px' } }),
          mode === 'register' ? BV.field(t('Nome'), name) : null, BV.field('Email', email), BV.field(t('Palavra-passe'), pass),
          h('button', { class: 'btn primary block', onclick: () => { if (!email.value || !pass.value) { BV.toast(t('Preencha o email e a palavra-passe'), 'error'); return; } run(mode === 'login' ? 'auth.login' : 'auth.register', { name: name.value, email: email.value, password: pass.value }); } }, icon('mail'), mode === 'login' ? t('Entrar') : t('Criar conta')),
          mode === 'login' ? h('button', { class: 'link', style: { margin: '10px auto', display: 'block' }, onclick: async () => { if (!email.value) { BV.toast(t('Escreva o seu email primeiro'), 'error'); return; } try { await BV.native('auth.reset', { email: email.value }); BV.toast(t('Enviámos um email para repor a palavra-passe'), 'ok'); } catch (e) { BV.error(e); } } }, t('Esqueci-me da palavra-passe')) : null,
          h('div', { class: 'or' }, t('ou')),
          h('button', { class: 'btn block', onclick: () => run('auth.google', {}) }, h('b', { style: { color: '#ea4335' } }, 'G'), t('Continuar com Google')),
          h('div', { style: { height: '10px' } }),
          h('button', { class: 'btn block', onclick: () => run('auth.github', {}) }, icon('github'), t('Continuar com GitHub')));
      };
      draw();
      body.append(h('div', { class: 'card pad' }, h('h3', null, t('Sincronize os seus livros')), h('p', { style: { color: 'var(--text-2)', margin: '6px 0 0' } }, t('Opcional. Entre para guardar cópias na nuvem, recuperar livros após reinstalar e usar vários dispositivos. Não precisa de conta para escrever e exportar.'))), h('div', { style: { height: '14px' } }), box);
    }
    s.append(top, h('div', { class: 'scroll form-scroll' }, body, h('div', { style: { height: '40px' } })));
  };

  /* ---------- indicador global de sincronização ---------- */
  BV.updateSyncDots = async function () {
    const el = document.getElementById('home-sync-dot'); if (!el) return;
    try {
      const st = await BV.native('sync.status');
      el.className = 'sync-dot ' + (!st.configured || !st.signedIn ? '' : st.running ? 'running' : st.lastError ? 'error' : st.pending > 0 ? 'pending' : 'synced');
    } catch (e) { /* ignora */ }
  };
})();
