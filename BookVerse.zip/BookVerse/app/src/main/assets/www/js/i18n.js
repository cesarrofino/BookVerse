/* BookVerse — traduções (a língua base da interface é o português). */
(function () {
  'use strict';
  const BV = window.BV;
  BV.dict = { en: {} };
  BV.addTranslations = (lang, map) => Object.assign((BV.dict[lang] = BV.dict[lang] || {}), map);
  BV.setLang = function (lang) {
    BV.lang = BV.dict[lang] || lang === 'pt' ? lang : 'pt';
    document.documentElement.lang = BV.lang;
  };
})();
