/* BookVerse — modelo e renderizador de capas em canvas (fonte única para ecrã, ficheiros e exportações) */
(function () {
  'use strict';
  const BV = window.BV;
  const C = (BV.cover = {});

  const imgCache = new Map();
  C.loadImage = function (url) {
    if (!url) return Promise.resolve(null);
    if (imgCache.has(url)) return imgCache.get(url);
    const p = new Promise((res) => {
      const im = new Image();
      im.onload = () => res(im); im.onerror = () => res(null);
      im.src = url;
    });
    imgCache.set(url, p);
    return p;
  };
  C.forgetImage = (url) => imgCache.delete(url);

  /** Dimensões base (px) de uma capa a partir do formato da página. */
  C.size = function (layout, which, spineMm) {
    const pg = BV.model.pageMm(layout);
    const w = 1200, h = Math.round(1200 * pg.h / pg.w);
    if (which === 'spine') return { w: Math.max(60, Math.round((spineMm || 12) * (1200 / pg.w))), h };
    return { w, h };
  };

  C.newDesign = function (w, h) {
    return { w, h, bg: { type: 'solid', color: '#0b1226' }, fx: { vignette: 0, blur: 0, gray: false, tint: '', tintAlpha: 0 }, els: [] };
  };

  C.newText = function (o) {
    return Object.assign({ id: BV.shortId(), type: 'text', x: 100, y: 200, w: 1000, h: 200, rot: 0, text: 'Texto', font: 'serif', size: 90, color: '#ffffff',
      bold: false, italic: false, align: 'center', valign: 'middle', spacing: 0, lineH: 1.15, upper: false, opacity: 1,
      shadow: false, shadowColor: '#000000', outline: false, outlineColor: '#000000', outlineW: 4 }, o);
  };
  C.newShape = function (o) {
    return Object.assign({ id: BV.shortId(), type: 'shape', shape: 'rect', x: 300, y: 500, w: 600, h: 600, rot: 0, fill: '#3b82f6', fill2: '', angle: 90,
      stroke: '', strokeW: 6, radius: 0, opacity: 1 }, o);
  };
  C.newImage = function (o) {
    return Object.assign({ id: BV.shortId(), type: 'image', x: 150, y: 300, w: 900, h: 900, rot: 0, url: '', fit: 'cover', radius: 0, opacity: 1, filter: 'none', border: 0, borderColor: '#ffffff' }, o);
  };

  function rr(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function linGrad(ctx, x, y, w, h, c1, c2, angleDeg) {
    const a = (angleDeg || 0) * Math.PI / 180, cx = x + w / 2, cy = y + h / 2;
    const len = Math.abs(w * Math.sin(a)) + Math.abs(h * Math.cos(a));
    const dx = Math.sin(a) * len / 2, dy = -Math.cos(a) * len / 2;
    const g = ctx.createLinearGradient(cx - dx, cy - dy, cx + dx, cy + dy);
    g.addColorStop(0, c1); g.addColorStop(1, c2);
    return g;
  }
  C.fontString = (e, size) => (e.italic ? 'italic ' : '') + (e.bold ? '700 ' : '400 ') + (size || e.size) + 'px ' + (e.font || 'serif');

  function wrap(ctx, text, maxW, spacing) {
    const lines = [];
    const measure = (s) => ctx.measureText(s).width + (spacing ? spacing * s.length : 0);
    for (const para of String(text).split('\n')) {
      const words = para.split(/\s+/).filter((x) => x.length);
      if (!words.length) { lines.push(''); continue; }
      let line = '';
      for (const w of words) {
        const test = line ? line + ' ' + w : w;
        if (measure(test) <= maxW || !line) line = test; else { lines.push(line); line = w; }
      }
      lines.push(line);
    }
    return lines;
  }
  function fillTextSpaced(ctx, s, x, y, spacing, align, stroke) {
    if (!spacing) { if (stroke) ctx.strokeText(s, x, y); ctx.fillText(s, x, y); return; }
    const total = ctx.measureText(s).width + spacing * (s.length - 1);
    let cx = align === 'center' ? x - total / 2 : align === 'right' ? x - total : x;
    const prev = ctx.textAlign; ctx.textAlign = 'left';
    for (const ch of s) { if (stroke) ctx.strokeText(ch, cx, y); ctx.fillText(ch, cx, y); cx += ctx.measureText(ch).width + spacing; }
    ctx.textAlign = prev;
  }

  function drawText(ctx, e) {
    ctx.save();
    ctx.globalAlpha = e.opacity == null ? 1 : e.opacity;
    ctx.font = C.fontString(e);
    ctx.textBaseline = 'alphabetic';
    ctx.textAlign = e.align === 'left' ? 'left' : e.align === 'right' ? 'right' : 'center';
    const text = e.upper ? String(e.text).toUpperCase() : String(e.text);
    const lines = wrap(ctx, text, e.w, e.spacing);
    const lh = e.size * (e.lineH || 1.15);
    const totalH = lines.length * lh;
    let y0 = e.valign === 'top' ? 0 : e.valign === 'bottom' ? e.h - totalH : (e.h - totalH) / 2;
    const x = e.align === 'left' ? 0 : e.align === 'right' ? e.w : e.w / 2;
    if (e.shadow) { ctx.shadowColor = e.shadowColor || '#000'; ctx.shadowBlur = Math.max(4, e.size * 0.12); ctx.shadowOffsetX = e.size * 0.04; ctx.shadowOffsetY = e.size * 0.05; }
    ctx.fillStyle = e.color;
    if (e.outline) { ctx.strokeStyle = e.outlineColor || '#000'; ctx.lineWidth = e.outlineW || 4; ctx.lineJoin = 'round'; }
    lines.forEach((ln, i) => { fillTextSpaced(ctx, ln, x, y0 + i * lh + e.size * 0.82 + (lh - e.size) / 2 - e.size * 0.05, e.spacing || 0, e.align, e.outline); });
    ctx.restore();
  }

  function shapePath(ctx, e) {
    const w = e.w, h = e.h;
    ctx.beginPath();
    switch (e.shape) {
      case 'circle': case 'ring': ctx.ellipse(w / 2, h / 2, w / 2, h / 2, 0, 0, Math.PI * 2); break;
      case 'triangle': ctx.moveTo(w / 2, 0); ctx.lineTo(w, h); ctx.lineTo(0, h); ctx.closePath(); break;
      case 'diamond': ctx.moveTo(w / 2, 0); ctx.lineTo(w, h / 2); ctx.lineTo(w / 2, h); ctx.lineTo(0, h / 2); ctx.closePath(); break;
      case 'star': { const cx = w / 2, cy = h / 2; for (let i = 0; i < 10; i++) { const r = i % 2 ? 0.42 : 1, a = -Math.PI / 2 + i * Math.PI / 5; const px = cx + Math.cos(a) * r * w / 2, py = cy + Math.sin(a) * r * h / 2; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.closePath(); break; }
      case 'line': ctx.rect(0, h / 2 - (e.strokeW || 6) / 2, w, e.strokeW || 6); break;
      case 'round': rr(ctx, 0, 0, w, h, Math.min(w, h) * 0.18); break;
      default: rr(ctx, 0, 0, w, h, e.radius || 0);
    }
  }
  function drawShape(ctx, e) {
    ctx.save();
    ctx.globalAlpha = e.opacity == null ? 1 : e.opacity;
    shapePath(ctx, e);
    if (e.shape === 'ring') {
      ctx.strokeStyle = e.fill; ctx.lineWidth = e.strokeW || 8; ctx.stroke();
    } else {
      ctx.fillStyle = e.fill2 ? linGrad(ctx, 0, 0, e.w, e.h, e.fill, e.fill2, e.angle) : e.fill;
      if (e.shape === 'line') ctx.fillStyle = e.fill;
      ctx.fill();
      if (e.stroke && e.shape !== 'line') { ctx.strokeStyle = e.stroke; ctx.lineWidth = e.strokeW || 4; ctx.stroke(); }
    }
    ctx.restore();
  }
  function drawImageEl(ctx, e, im) {
    ctx.save();
    ctx.globalAlpha = e.opacity == null ? 1 : e.opacity;
    if (!im) { ctx.fillStyle = 'rgba(128,128,128,.3)'; rr(ctx, 0, 0, e.w, e.h, e.radius || 0); ctx.fill(); ctx.restore(); return; }
    rr(ctx, 0, 0, e.w, e.h, e.radius || 0); ctx.clip();
    const f = e.filter;
    ctx.filter = f === 'grayscale' ? 'grayscale(1)' : f === 'sepia' ? 'sepia(.9)' : f === 'blur' ? 'blur(6px)' : f === 'bw' ? 'grayscale(1) contrast(1.4)' : 'none';
    const s = e.fit === 'contain' ? Math.min(e.w / im.width, e.h / im.height) : Math.max(e.w / im.width, e.h / im.height);
    const dw = im.width * s, dh = im.height * s;
    ctx.drawImage(im, (e.w - dw) / 2, (e.h - dh) / 2, dw, dh);
    ctx.filter = 'none';
    if (e.border) { rr(ctx, 0, 0, e.w, e.h, e.radius || 0); ctx.strokeStyle = e.borderColor || '#fff'; ctx.lineWidth = e.border * 2; ctx.stroke(); }
    ctx.restore();
  }

  async function drawBackground(ctx, d) {
    const bg = d.bg || { type: 'solid', color: '#0b1226' }, w = d.w, h = d.h, fx = d.fx || {};
    if (bg.type === 'gradient') { ctx.fillStyle = linGrad(ctx, 0, 0, w, h, bg.from, bg.to, bg.angle == null ? 160 : bg.angle); ctx.fillRect(0, 0, w, h); }
    else if (bg.type === 'image') {
      ctx.fillStyle = bg.color || '#111'; ctx.fillRect(0, 0, w, h);
      const im = await C.loadImage(bg.url);
      if (im) {
        ctx.save();
        const f = []; if (fx.blur) f.push('blur(' + fx.blur + 'px)'); if (fx.gray) f.push('grayscale(1)');
        if (f.length) ctx.filter = f.join(' ');
        const s = Math.max(w / im.width, h / im.height), dw = im.width * s, dh = im.height * s;
        const pad = fx.blur ? fx.blur * 2 : 0;
        ctx.drawImage(im, (w - dw) / 2 - pad / 2, (h - dh) / 2 - pad / 2, dw + pad, dh + pad);
        ctx.restore();
      }
      if (bg.overlay) { ctx.fillStyle = bg.overlay; ctx.globalAlpha = bg.overlayAlpha == null ? 0.35 : bg.overlayAlpha; ctx.fillRect(0, 0, w, h); ctx.globalAlpha = 1; }
    } else { ctx.fillStyle = bg.color || '#0b1226'; ctx.fillRect(0, 0, w, h); }
  }
  function drawFxTop(ctx, d) {
    const fx = d.fx || {}, w = d.w, h = d.h;
    if (fx.tint && fx.tintAlpha > 0) { ctx.save(); ctx.globalAlpha = fx.tintAlpha; ctx.fillStyle = fx.tint; ctx.fillRect(0, 0, w, h); ctx.restore(); }
  }
  function drawVignette(ctx, d) {
    const v = (d.fx && d.fx.vignette) || 0; if (!v) return;
    const w = d.w, h = d.h, g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.max(w, h) * 0.75);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,' + Math.min(0.95, v) + ')');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  }

  /** Desenha a capa. opts.scale (omissão 1). Elementos em design.els, por ordem (último = topo). */
  C.render = async function (design, canvas, opts) {
    opts = opts || {};
    const sc = opts.scale || 1;
    canvas.width = Math.round(design.w * sc); canvas.height = Math.round(design.h * sc);
    const ctx = canvas.getContext('2d');
    ctx.setTransform(sc, 0, 0, sc, 0, 0);
    ctx.clearRect(0, 0, design.w, design.h);
    await drawBackground(ctx, design);
    drawFxTop(ctx, design);
    drawVignette(ctx, design);
    const imgs = await Promise.all(design.els.map((e) => (e.type === 'image' ? C.loadImage(e.url) : null)));
    design.els.forEach((e, i) => {
      if (e.hidden) return;
      ctx.save();
      ctx.translate(e.x + e.w / 2, e.y + e.h / 2); ctx.rotate((e.rot || 0) * Math.PI / 180); ctx.translate(-e.w / 2, -e.h / 2);
      if (e.type === 'text') drawText(ctx, e); else if (e.type === 'shape') drawShape(ctx, e); else if (e.type === 'image') drawImageEl(ctx, e, imgs[i]);
      ctx.restore();
    });
    return canvas;
  };

  C.toDataUrl = async function (design, type, quality, width) {
    const cv = document.createElement('canvas');
    await C.render(design, cv, { scale: width ? width / design.w : 1 });
    return cv.toDataURL(type || 'image/jpeg', quality == null ? 0.92 : quality);
  };

  /** Teste de acerto: devolve o índice do elemento mais acima em (x,y) (coordenadas do design). */
  C.hit = function (design, x, y) {
    for (let i = design.els.length - 1; i >= 0; i--) {
      const e = design.els[i]; if (e.hidden || e.locked) continue;
      const a = -(e.rot || 0) * Math.PI / 180, cx = e.x + e.w / 2, cy = e.y + e.h / 2;
      const dx = x - cx, dy = y - cy;
      const lx = dx * Math.cos(a) - dy * Math.sin(a), ly = dx * Math.sin(a) + dy * Math.cos(a);
      const pad = Math.max(0, 24 - Math.min(e.w, e.h) / 2);
      if (Math.abs(lx) <= e.w / 2 + pad && Math.abs(ly) <= e.h / 2 + pad) return i;
    }
    return -1;
  };

  /** Luminância relativa de uma cor CSS hex (para escolher texto claro/escuro). */
  C.isDark = function (hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return true;
    const n = parseInt(m[1], 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    return (0.299 * r + 0.587 * g + 0.114 * b) < 140;
  };
})();
