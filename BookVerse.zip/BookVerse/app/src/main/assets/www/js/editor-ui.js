/* BookVerse — ecrã do editor: capítulos, barra de ferramentas, estado */
(function () {
  'use strict';
  const BV = window.BV;
  const { h, icon, t } = { h: BV.h, icon: BV.icon, t: (s) => BV.t(s) };
  const store = BV.store;
  const E = (BV.editorScreen = {});

  let ed = null, cur = null, tab = 'format', els = {}, book = null;
  let pages = ['<p><br></p>'], pi = 0, titleVisible = true, animating = false;
  const PB = '<div class="pagebreak"></div>';
  const EXTRA_KEYS = ['dedication', 'acknowledgments', 'preface', 'intro', 'conclusion', 'references', 'about'];

  E.editor = () => ed;
  E.current = () => cur;

  /* ---------- abertura ---------- */
  E.open = async function (bookId) {
    const screen = BV.$('#screen-editor');
    BV.clear(screen);
    book = store.book && store.book.id === bookId ? store.book : await store.open(bookId);
    const doc = book.doc;
    if (!cur || cur.bookId !== bookId) {
      const last = doc.lastChapter && doc.chapters.find((c) => c.id === doc.lastChapter);
      cur = { bookId, kind: 'chapter', id: (last || doc.chapters[0]).id };
    }
    build(screen);
    loadItem(cur, true);
    renderDrawer();
    updateStatus();
  };
  store.on('saved', () => onSaved()); store.on('saving', () => onSaving()); store.on('save-error', () => onSaveError());

  E.close = async function () {
    if (ed) { writeBack(); ed.destroy(); ed = null; }
    await store.flush();
    cur = null;
  };

  /** Chamado ao voltar de ecrãs secundários (pré-visualização, capas). */
  E.refresh = function () { renderDrawer(); updateStatus(); };

  /* ---------- estrutura do ecrã ---------- */
  function build(screen) {
    els = {};
    const paperCss = () => {
      const L = book.doc.layout;
      els.paper.style.fontFamily = L.fontFamily; els.paper.style.fontSize = L.fontSizePt + 'pt';
      els.paper.style.lineHeight = L.lineHeight;
      els.paper.style.setProperty('--para', L.paraSpacingPt + 'pt');
      els.paper.style.setProperty('--indent', (L.firstLineIndentMm || 0) + 'mm');
    };
    E.applyLayoutCss = () => paperCss();

    els.title = h('span', { class: 'ed-title', onclick: () => BV.bookInfoDialog && BV.bookInfoDialog(book, () => { els.title.textContent = book.title; store.touch(); }) }, book.title);
    els.undo = h('button', { class: 'icon-btn', 'aria-label': 'Desfazer', onpointerdown: noFocus, onclick: () => ed.undo() }, icon('undo'));
    els.redo = h('button', { class: 'icon-btn', 'aria-label': 'Refazer', onpointerdown: noFocus, onclick: () => ed.redo() }, icon('redo'));
    els.saveState = h('span', { class: 'save-state' });

    const top = h('div', { class: 'topbar' },
      h('button', { class: 'icon-btn', 'aria-label': 'Voltar', onclick: () => BV.go('home') }, icon('back')),
      h('button', { class: 'icon-btn', 'aria-label': 'Capítulos', onclick: () => toggleDrawer() }, icon('chapters')),
      h('div', { class: 'ed-head' }, els.title, els.saveState),
      els.undo, els.redo,
      h('button', { class: 'icon-btn', 'aria-label': 'Pré-visualizar', onclick: () => preview() }, icon('eye')),
      h('button', { class: 'icon-btn', 'aria-label': 'Exportar', onclick: () => doExport() }, icon('share')),
      h('button', { class: 'icon-btn', 'aria-label': 'Mais', onclick: () => moreMenu() }, icon('more')));

    els.drawer = h('aside', { class: 'drawer' });
    els.scrim = h('div', { class: 'drawer-scrim', onclick: () => toggleDrawer(false) });
    els.titleInput = h('input', { class: 'chap-input', placeholder: t('Título do capítulo'), oninput: onTitleInput, enterkeyhint: 'next',
      onkeydown: (e) => { if (e.key === 'Enter') { e.preventDefault(); ed.focus(); } } });
    els.paper = h('div', { class: 'paper', 'data-placeholder': t('Comece a escrever…') });
    els.addHead = h('button', { class: 'chip head-btn', onpointerdown: noFocus, onclick: () => setHeading(true) }, '＋ ' + t('Adicionar título de capítulo'));
    els.rmHead = h('button', { class: 'chip head-btn', onpointerdown: noFocus, onclick: () => setHeading(false) }, '✕ ' + t('Remover título'));
    els.pageWrap = h('div', { class: 'page-wrap' }, els.addHead, els.titleInput, els.rmHead, els.paper);
    els.scroller = h('div', { class: 'ed-scroll' }, els.pageWrap);
    els.pgPrev = h('button', { class: 'pg-btn', 'aria-label': 'Página anterior', onpointerdown: noFocus, onclick: () => goPage(pi - 1, -1) }, '‹');
    els.pgNext = h('button', { class: 'pg-btn', 'aria-label': 'Página seguinte', onpointerdown: noFocus, onclick: () => goPage(pi + 1, 1) }, '›');
    els.pgLabel = h('span', { class: 'pg-label' });
    els.pgNew = h('button', { class: 'pg-btn pg-new', onpointerdown: noFocus, onclick: () => newPage(true) }, '＋ ' + t('Nova página'));
    els.pager = h('div', { class: 'pager' }, els.pgPrev, els.pgLabel, els.pgNext, els.pgNew);
    // deslizar para o lado: esquerda = página seguinte, direita = página anterior
    let sx = 0, sy = 0, st = 0, track = false;
    els.scroller.addEventListener('touchstart', (e) => { if (e.touches.length !== 1) { track = false; return; } sx = e.touches[0].clientX; sy = e.touches[0].clientY; st = Date.now(); track = true; }, { passive: true });
    els.scroller.addEventListener('touchend', (e) => {
      if (!track) return; track = false;
      const t0 = e.changedTouches[0], dx = t0.clientX - sx, dy = t0.clientY - sy;
      if (Date.now() - st > 800 || Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 1.8) return;
      const sel = window.getSelection(); if (sel && !sel.isCollapsed) return;
      if (dx < 0) goPage(pi + 1, 1); else goPage(pi - 1, -1);
    }, { passive: true });
    els.status = h('div', { class: 'ed-status' });
    els.tableChip = h('button', { class: 'chip on table-chip', style: { display: 'none' }, onpointerdown: noFocus, onclick: () => tableMenu() }, icon('table', 'sm'), t('Tabela'));
    els.tools = h('div', { class: 'tools' });
    els.tabs = h('div', { class: 'tabs' });
    els.dock = h('div', { class: 'dock glass' }, els.tableChip, els.status, els.tabs, els.tools);

    screen.append(top, h('div', { class: 'ed-body' }, els.drawer, els.scrim, h('div', { class: 'ed-main' }, els.scroller, els.pager, els.dock)));
    paperCss();

    ed = new BV.Editor(els.paper, {
      scroller: els.scroller,
      onChange: onEditorChange,
      onSelection: debouncedSel,
      onHistory: updateUndo
    });
    els.paper.addEventListener('click', onPaperClick);
    renderTabs(); renderTools();
  }
  const noFocus = (e) => e.preventDefault();

  /* ---------- itens (capítulos e páginas especiais) ---------- */
  function itemHtml(it) {
    const d = book.doc;
    return it.kind === 'chapter' ? (d.chapters.find((c) => c.id === it.id) || { html: '' }).html : (d.extras[it.key] || '');
  }
  function writeBack() {
    if (!ed || !cur) return;
    const d = book.doc;
    pages[pi] = ed.getHtml();
    const html = pages.join(PB);
    if (cur.kind === 'chapter') { const c = d.chapters.find((x) => x.id === cur.id); if (c) c.html = html; }
    else d.extras[cur.key] = html;
  }
  function loadItem(it, first) {
    if (!first) writeBack();
    cur = Object.assign({ bookId: book.id }, it);
    const d = book.doc;
    if (cur.kind === 'chapter') {
      if (!d.chapters.find((c) => c.id === cur.id)) cur.id = d.chapters[0].id;
      d.lastChapter = cur.id;
      const c = d.chapters.find((x) => x.id === cur.id);
      titleVisible = true; els.titleInput.value = c.title; els.titleInput.placeholder = t('Título do capítulo');
    } else {
      const showTitle = cur.key !== 'dedication';
      titleVisible = showTitle;
      els.titleInput.style.display = showTitle ? '' : 'none';
      els.titleInput.value = BV.model.titleOf(d, cur.key); els.titleInput.placeholder = t('Título');
    }
    pages = splitPages(itemHtml(cur)); pi = 0;
    ed.setHtml(pages[0]); applyTitleVis(); updatePager();
    els.scroller.scrollTop = 0;
    updateStatus(); updateUndo(); renderDrawer();
  }
  function onTitleInput() {
    const d = book.doc;
    if (cur.kind === 'chapter') { const c = d.chapters.find((x) => x.id === cur.id); if (c) c.title = els.titleInput.value; }
    else d.extraTitles[cur.key] = els.titleInput.value;
    store.touch(); renderDrawerDebounced();
  }
  const renderDrawerDebounced = BV.debounce(() => renderDrawer(), 400);

  /* ---------- gaveta de capítulos ---------- */
  function toggleDrawer(force) {
    const open = force == null ? !els.drawer.classList.contains('open') : force;
    els.drawer.classList.toggle('open', open); els.scrim.classList.toggle('open', open);
  }
  E.drawerOpen = () => !!(els.drawer && els.drawer.classList.contains('open'));
  E.closeDrawer = () => toggleDrawer(false);

  function renderDrawer() {
    if (!els.drawer) return;
    const d = book.doc, st = d.structure;
    BV.clear(els.drawer);
    const extras = EXTRA_KEYS.filter((k) => st[k] && ['dedication', 'acknowledgments', 'preface'].includes(k));
    const after = EXTRA_KEYS.filter((k) => st[k] && !['dedication', 'acknowledgments', 'preface'].includes(k));

    const extraRow = (k) => h('button', { class: 'ch-row extra' + (cur.kind === 'extra' && cur.key === k ? ' on' : ''), onclick: () => { loadItem({ kind: 'extra', key: k }); closeIfNarrow(); } },
      icon('file', 'sm'), h('span', { class: 'ch-name' }, BV.model.titleOf(d, k)));

    const list = h('div', { class: 'ch-list' });
    d.chapters.forEach((c, i) => {
      const words = BV.model.countWords(c.id === (cur && cur.id) && ed ? ed.root.innerHTML : c.html);
      const handle = h('span', { class: 'ch-handle', 'aria-label': 'Reordenar' }, icon('drag', 'sm'));
      const row = h('div', { class: 'ch-row' + (cur.kind === 'chapter' && cur.id === c.id ? ' on' : ''), 'data-id': c.id },
        handle,
        h('button', { class: 'ch-main', onclick: () => { loadItem({ kind: 'chapter', id: c.id }); closeIfNarrow(); } },
          h('span', { class: 'ch-name' }, c.heading === false ? (c.title || t('Secção') + ' ' + (i + 1)) : (c.title || (t('Capítulo') + ' ' + (i + 1)))), h('small', null, BV.fmtNum(words) + ' ' + t('palavras'))),
        h('button', { class: 'icon-btn sm', 'aria-label': 'Opções', onclick: () => chapterMenu(c) }, icon('more')));
      enableDrag(handle, row, list);
      list.appendChild(row);
    });

    els.drawer.append(
      h('div', { class: 'drawer-h' }, h('h3', null, t('Estrutura')),
        h('button', { class: 'icon-btn', onclick: () => toggleDrawer(false) }, icon('close'))),
      h('div', { class: 'drawer-b' },
        extras.length ? h('div', { class: 'grp' }, t('Páginas iniciais')) : null, ...extras.map(extraRow),
        h('div', { class: 'grp' }, t('Capítulos')), list,
        h('button', { class: 'btn sm block', style: { marginTop: '10px' }, onclick: addChapter }, icon('plus', 'sm'), t('Novo capítulo')),
        after.length ? h('div', { class: 'grp' }, t('Páginas finais')) : null, ...after.map(extraRow)),
      h('div', { class: 'drawer-f' },
        h('button', { class: 'btn sm block', onclick: () => BV.structureDialog(book, () => { store.touch(); const d2 = book.doc; if (cur.kind === 'extra' && !d2.structure[cur.key]) loadItem({ kind: 'chapter', id: d2.chapters[0].id }); renderDrawer(); }) }, icon('layers', 'sm'), t('Estrutura do livro'))));
  }
  function closeIfNarrow() { if (window.innerWidth < 900) toggleDrawer(false); }

  function enableDrag(handle, row, list) {
    handle.style.touchAction = 'none';
    handle.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      handle.setPointerCapture(e.pointerId);
      let startY = e.clientY;
      row.classList.add('dragging');
      const move = (ev) => {
        row.style.transform = 'translateY(' + (ev.clientY - startY) + 'px)';
        const next = row.nextElementSibling, prev = row.previousElementSibling;
        const rr = row.getBoundingClientRect(), mid = rr.top + rr.height / 2;
        if (next && next.classList.contains('ch-row') && mid > next.getBoundingClientRect().top + next.offsetHeight / 2) { const hh = next.offsetHeight; list.insertBefore(next, row); startY += hh; row.style.transform = 'translateY(' + (ev.clientY - startY) + 'px)'; }
        else if (prev && prev.classList.contains('ch-row') && mid < prev.getBoundingClientRect().top + prev.offsetHeight / 2) { const hh = prev.offsetHeight; list.insertBefore(row, prev); startY -= hh; row.style.transform = 'translateY(' + (ev.clientY - startY) + 'px)'; }
      };
      const up = () => {
        handle.removeEventListener('pointermove', move); handle.removeEventListener('pointerup', up); handle.removeEventListener('pointercancel', up);
        row.classList.remove('dragging'); row.style.transform = '';
        const order = Array.from(list.children).map((r) => r.getAttribute('data-id'));
        const d = book.doc;
        const map = new Map(d.chapters.map((c) => [c.id, c]));
        const next = order.map((id) => map.get(id)).filter(Boolean);
        if (next.length === d.chapters.length && next.some((c, i) => c !== d.chapters[i])) { d.chapters = next; store.touch(); }
        renderDrawer();
      };
      handle.addEventListener('pointermove', move); handle.addEventListener('pointerup', up); handle.addEventListener('pointercancel', up);
    });
  }

  function addChapter() {
    writeBack();
    const d = book.doc;
    const c = { id: BV.shortId(), title: t('Capítulo') + ' ' + (d.chapters.length + 1), heading: true, html: '<p><br></p>' };
    d.chapters.push(c); store.touch();
    loadItem({ kind: 'chapter', id: c.id }); closeIfNarrow();
    setTimeout(() => { els.titleInput.focus(); els.titleInput.select(); }, 80);
  }

  function chapterMenu(c) {
    const d = book.doc, i = d.chapters.indexOf(c);
    BV.menu(c.title || t('Capítulo'), [
      { icon: 'edit', label: t('Renomear'), onClick: async () => { const v = await BV.prompt(t('Nome do capítulo'), c.title); if (v != null) { c.title = v.trim() || c.title; c.heading = true; if (cur.id === c.id) els.titleInput.value = c.title; applyTitleVis(); store.touch(); renderDrawer(); } } },
      { icon: 'duplicate', label: t('Duplicar'), onClick: () => { writeBack(); const n = { id: BV.shortId(), title: c.title + ' (' + t('cópia') + ')', heading: c.heading !== false, html: c.html }; d.chapters.splice(i + 1, 0, n); store.touch(); loadItem({ kind: 'chapter', id: n.id }); } },
      i > 0 ? { icon: 'up', label: t('Mover para cima'), onClick: () => { writeBack(); d.chapters.splice(i, 1); d.chapters.splice(i - 1, 0, c); store.touch(); renderDrawer(); } } : null,
      i < d.chapters.length - 1 ? { icon: 'down', label: t('Mover para baixo'), onClick: () => { writeBack(); d.chapters.splice(i, 1); d.chapters.splice(i + 1, 0, c); store.touch(); renderDrawer(); } } : null,
      { icon: 'trash', label: t('Eliminar'), danger: true, onClick: async () => {
        if (d.chapters.length < 2) { BV.toast(t('O livro precisa de pelo menos um capítulo'), 'error'); return; }
        if (!(await BV.confirm(t('Eliminar este capítulo e todo o seu conteúdo?'), { danger: true, ok: t('Eliminar') }))) return;
        writeBack(); await store.saveNow();
        try { await BV.native('books.snapshot', { id: book.id, label: 'Antes de eliminar capítulo' }); } catch (e) { /* a eliminação continua recuperável pela cópia local */ }
        const wasCur = cur.kind === 'chapter' && cur.id === c.id;
        d.chapters.splice(i, 1); store.touch();
        if (wasCur) loadItem({ kind: 'chapter', id: d.chapters[Math.max(0, i - 1)].id }); else renderDrawer();
      } }
    ]);
  }

  /** Move a seleção atual para o fim de outro capítulo. */
  function moveSelection() {
    if (!ed.hasSelection() && !(ed.lastRange && !ed.lastRange.collapsed)) { BV.toast(t('Selecione o texto que quer mover'), 'error'); return; }
    const d = book.doc;
    const targets = d.chapters.filter((c) => !(cur.kind === 'chapter' && c.id === cur.id));
    if (!targets.length) { BV.toast(t('Não há outros capítulos'), 'error'); return; }
    BV.menu(t('Mover seleção para…'), targets.map((c) => ({ icon: 'forward', label: c.title || t('Capítulo'), onClick: () => {
      const html = ed.extractSelectionHtml(); if (!html) return;
      c.html = (c.html || '').replace(/<p><br><\/p>\s*$/, '') + html;
      writeBack(); store.touch(); renderDrawer(); BV.toast(t('Conteúdo movido para') + ' "' + c.title + '"', 'ok');
    } })));
  }

  /* ---------- barra de ferramentas ---------- */
  const TABS = [['format', 'Formatar'], ['para', 'Parágrafo'], ['insert', 'Inserir'], ['page', 'Página'], ['edit', 'Editar']];
  function renderTabs() {
    BV.clear(els.tabs);
    TABS.forEach(([k, label]) => els.tabs.appendChild(h('button', { class: 'tab' + (tab === k ? ' on' : ''), onpointerdown: noFocus, onclick: () => { tab = k; renderTabs(); renderTools(); } }, t(label))));
  }
  const tbtn = (ic, label, fn, key) => h('button', { class: 'icon-btn tb', 'data-k': key || '', title: t(label), 'aria-label': t(label), onpointerdown: noFocus, onclick: fn }, icon(ic));
  const sep = () => h('span', { class: 'tb-sep' });
  const pill = (label, fn, key) => h('button', { class: 'pill', 'data-k': key || '', onpointerdown: noFocus, onclick: fn }, label);

  function renderTools() {
    BV.clear(els.tools);
    const T = els.tools, add = (...n) => n.forEach((x) => T.appendChild(x));
    if (tab === 'format') {
      add(tbtn('bold', 'Negrito', () => ed.toggle('bold'), 'bold'), tbtn('italic', 'Itálico', () => ed.toggle('italic'), 'italic'),
        tbtn('underline', 'Sublinhado', () => ed.toggle('underline'), 'underline'), tbtn('strike', 'Rasurado', () => ed.toggle('strikeThrough'), 'strike'), sep(),
        (els.fontBtn = pill(t('Fonte'), () => BV.fontMenu(ed), 'font')),
        tbtn('minus', 'Diminuir fonte', () => stepSize(-1)), (els.sizeBtn = pill('12', () => BV.sizeDialog(ed), 'size')), tbtn('plus', 'Aumentar fonte', () => stepSize(1)), sep(),
        tbtn('font', 'Cor do texto', () => BV.colorDialog(t('Cor do texto'), '#000000', (c) => ed.setColor(c))),
        tbtn('highlight', 'Cor de fundo do texto', () => BV.colorDialog(t('Cor de fundo do texto'), '#ffff00', (c) => ed.setHighlight(c), true)),
        tbtn('close', 'Limpar formatação', () => ed.clearFormat()));
    } else if (tab === 'para') {
      add(tbtn('alignL', 'Alinhar à esquerda', () => ed.align('left'), 'al-left'), tbtn('alignC', 'Centrar', () => ed.align('center'), 'al-center'),
        tbtn('alignR', 'Alinhar à direita', () => ed.align('right'), 'al-right'), tbtn('alignJ', 'Justificar', () => ed.align('justify'), 'al-justify'), sep(),
        tbtn('ul', 'Lista com marcadores', () => ed.list('ul'), 'ul'), tbtn('ol', 'Lista numerada', () => ed.list('ol'), 'ol'), sep(),
        tbtn('indent', 'Aumentar recuo', () => ed.indent(true)), tbtn('outdent', 'Diminuir recuo', () => ed.indent(false)), sep(),
        pill(t('Estilo'), () => BV.blockMenu(ed)), pill(t('Entrelinha'), () => BV.spacingDialog(ed, 'line')),
        pill(t('Espaço entre parágrafos'), () => BV.spacingDialog(ed, 'para')), pill(t('Recuo da 1.ª linha'), () => BV.spacingDialog(ed, 'indent')));
    } else if (tab === 'page') {
      add(pill('＋ ' + t('Nova página aqui'), () => newPage(true)),
        pill('⤓ ' + t('No fim do capítulo'), newPageEnd),
        pill('🗑 ' + t('Apagar esta página'), deletePage), sep(),
        chapterOf() ? pill(chapterOf().heading !== false ? '✕ ' + t('Remover título do capítulo') : '＋ ' + t('Título de capítulo'), () => { setHeading(chapterOf().heading === false); renderTools(); }) : null,
        tbtn('heading', 'Cabeçalho e rodapé', () => BV.headerFooterDialog(book, () => { store.touch(); })));
    } else if (tab === 'insert') {
      add(tbtn('image', 'Imagem da galeria', () => insertImage(false)), tbtn('camera', 'Fotografia', () => insertImage(true)),
        tbtn('table', 'Tabela', () => BV.tableDialog(ed)), tbtn('quote', 'Citação', () => ed.insertQuote()),
        tbtn('minus', 'Separador', () => BV.separatorMenu(ed)), tbtn('link', 'Link', () => BV.linkDialog(ed)),
        tbtn('pagebreak', 'Nova página', () => newPage(true)), tbtn('heading', 'Cabeçalho e rodapé', () => BV.headerFooterDialog(book, () => { store.touch(); })));
    } else {
      add(tbtn('undo', 'Desfazer', () => ed.undo(), 'undo'), tbtn('redo', 'Refazer', () => ed.redo(), 'redo'), sep(),
        tbtn('selectall', 'Selecionar tudo', () => ed.selectAll()),
        tbtn('copy', 'Copiar', () => { ed.restore(); document.execCommand('copy'); BV.toast(t('Copiado'), 'ok'); }),
        tbtn('trash', 'Cortar', () => { ed.restore(); ed.commit(); document.execCommand('cut'); ed._onInput(); }),
        tbtn('paste', 'Colar', pasteFromClipboard), sep(),
        tbtn('search', 'Localizar e substituir', () => BV.findDialog(ed)), tbtn('forward', 'Mover seleção para outro capítulo', moveSelection));
    }
    updateToolState();
  }
  /* ---------- páginas: uma de cada vez, a anterior sai para a esquerda ---------- */
  function splitPages(html) {
    const box = document.createElement('div'); box.innerHTML = html || '';
    const out = []; let acc = [];
    for (const n of Array.from(box.childNodes)) {
      if (n.nodeType === 1 && n.classList.contains('pagebreak')) { out.push(acc); acc = []; }
      else if (n.nodeType === 1) acc.push(n.outerHTML);
      else if (n.nodeType === 3 && n.nodeValue.trim()) acc.push('<p>' + BV.esc(n.nodeValue) + '</p>');
    }
    out.push(acc);
    return out.map((a) => a.join('') || '<p><br></p>');
  }
  function chapterOf() { return cur && cur.kind === 'chapter' ? book.doc.chapters.find((c) => c.id === cur.id) : null; }
  function applyTitleVis() {
    const c = chapterOf(), first = pi === 0;
    const heading = c ? c.heading !== false : titleVisible;
    els.titleInput.style.display = heading && first ? '' : 'none';
    els.addHead.style.display = c && !heading && first ? '' : 'none';
    els.rmHead.style.display = c && heading && first ? '' : 'none';
  }
  /** Título de capítulo opcional: o utilizador decide se a página tem título ou fica em branco. */
  function setHeading(on) {
    const c = chapterOf(); if (!c) return;
    c.heading = !!on;
    if (on) { if (!c.title) c.title = t('Capítulo') + ' ' + (book.doc.chapters.indexOf(c) + 1); els.titleInput.value = c.title; }
    applyTitleVis(); store.touch(); renderDrawerDebounced();
    if (on) setTimeout(() => { els.titleInput.focus(); els.titleInput.select(); }, 60); else try { ed.focus(); } catch (e) { /* ignora */ }
  }
  function updatePager() {
    if (!els.pgLabel) return;
    els.pgLabel.textContent = t('Página') + ' ' + (pi + 1) + ' ' + t('de') + ' ' + pages.length;
    els.pgPrev.disabled = pi === 0; els.pgNext.disabled = pi >= pages.length - 1;
  }
  async function goPage(n, dir) {
    if (animating || !ed || n < 0 || n >= pages.length || n === pi) return;
    animating = true; closeImgPanel(); writeBack();
    const w = els.pageWrap, off = dir > 0 ? '-110%' : '110%', inn = dir > 0 ? '110%' : '-110%';
    w.style.transition = 'transform .16s ease-in, opacity .16s'; w.style.transform = 'translateX(' + off + ')'; w.style.opacity = '0';
    await new Promise((r) => setTimeout(r, 165));
    pi = n; ed.setHtml(pages[pi]); applyTitleVis(); els.scroller.scrollTop = 0;
    w.style.transition = 'none'; w.style.transform = 'translateX(' + inn + ')';
    void w.offsetWidth;
    w.style.transition = 'transform .2s ease-out, opacity .2s'; w.style.transform = 'translateX(0)'; w.style.opacity = '1';
    updatePager(); updateStatus(); updateUndo();
    setTimeout(() => { animating = false; w.style.transition = ''; w.style.transform = ''; w.style.opacity = ''; }, 220);
    if (dir > 0) try { ed.focus(); } catch (e) { /* ignora */ }
  }
  const blank = () => '<p><br></p>';
  /** Nova página a seguir à atual; se o cursor estiver a meio, o texto que fica depois dele passa para a nova página. */
  function newPage(atCursor) {
    if (animating || !ed) return;
    let rest = '';
    if (atCursor) {
      const sel = window.getSelection();
      if (sel.rangeCount && ed.root.contains(sel.anchorNode) && ed.root.lastChild) {
        try {
          const r = sel.getRangeAt(0).cloneRange(); r.collapse(false);
          const tail = document.createRange(); tail.setStart(r.endContainer, r.endOffset); tail.setEndAfter(ed.root.lastChild);
          const box = document.createElement('div'); box.appendChild(tail.extractContents());
          const first = box.firstElementChild;
          if (first && !first.textContent.trim() && !first.querySelector('img,table,hr') && box.children.length > 1) first.remove();
          rest = box.innerHTML;
          Array.from(ed.root.children).forEach((c) => { if (!c.textContent.trim() && !c.querySelector('img,br,table,hr,.pagebreak')) c.appendChild(document.createElement('br')); });
          ed._normalize();
        } catch (e) { rest = ''; }
      }
    }
    pages[pi] = ed.getHtml();
    pages.splice(pi + 1, 0, (rest && rest.replace(/<[^>]*>/g, '').trim() || /<img|<table/.test(rest)) ? rest : blank());
    onEditorChange();
    goPage(pi + 1, 1);
    BV.toast(t('Nova página') + ' ' + (pi + 2) + ' ' + t('criada'), 'ok');
  }
  function newPageEnd() {
    if (animating || !ed) return;
    writeBack(); pages.push(blank()); store.touch(); updatePager();
    goPage(pages.length - 1, 1);
  }
  async function deletePage() {
    if (animating || !ed) return;
    if (pages.length < 2) { BV.toast(t('Este capítulo só tem uma página.')); return; }
    const has = BV.model.textOf(ed.getHtml()).trim().length > 0 || /<img/.test(ed.getHtml());
    if (has && !(await BV.confirm(t('Apagar a página') + ' ' + (pi + 1) + '? ' + t('O texto desta página será perdido.'), { danger: true, ok: t('Apagar') }))) return;
    pages.splice(pi, 1); if (pi >= pages.length) pi = pages.length - 1;
    ed.setHtml(pages[pi]); applyTitleVis(); updatePager(); updateStatus(); updateUndo(); onEditorChange();
    BV.toast(t('Página apagada'), 'ok');
  }
  function stepSize(d) {
    const info = ed.stateInfo(); const base = info.size || book.doc.layout.fontSizePt;
    ed.setSizePt(Math.max(6, Math.min(96, Math.round(base + d))));
  }
  async function pasteFromClipboard() {
    ed.restore();
    try {
      const r = await BV.native('clipboard.get');
      if (r && r.html) { ed.commit(); document.execCommand('insertHTML', false, BV.model.sanitize(r.html)); ed._onInput(); }
      else if (r && r.text) { ed.commit(); ed.insertPlain(r.text); ed._onInput(); }
      else BV.toast(t('A área de transferência está vazia'));
    } catch (e) { BV.error(e); }
  }

  async function insertImage(camera) {
    try {
      ed.commit();
      const r = await BV.native('media.pick', { bookId: book.id, camera });
      if (r.cancelled) return;
      ed.insertImage(r.url, { width: 80, align: 'center' });
    } catch (e) { BV.error(e); }
  }

  function updateToolState() {
    if (!ed) return;
    const s = ed.stateInfo();
    const on = (k, v) => BV.$$('[data-k="' + k + '"]', els.tools).forEach((b) => b.classList.toggle('on', !!v));
    on('bold', s.bold); on('italic', s.italic); on('underline', s.underline); on('strike', s.strike); on('ul', s.ul); on('ol', s.ol);
    ['left', 'center', 'right', 'justify'].forEach((a) => on('al-' + a, s.align === a));
    if (els.sizeBtn) els.sizeBtn.textContent = String(s.size || book.doc.layout.fontSizePt);
    if (els.fontBtn) els.fontBtn.textContent = fontLabel(s.font);
    els.tableChip.style.display = s.inTable ? '' : 'none';
  }
  function fontLabel(css) {
    const f = (css || '').split(',')[0].replace(/["']/g, '').trim().toLowerCase();
    const hit = BV.model.FONTS.find(([k]) => k === f);
    return hit ? hit[1].split(' (')[0] : (f ? f.slice(0, 14) : t('Fonte'));
  }
  const debouncedSel = BV.debounce(() => { updateToolState(); }, 80);

  function updateUndo() {
    if (!els.undo || !ed) return;
    els.undo.style.opacity = ed.canUndo() ? 1 : .4; els.redo.style.opacity = ed.canRedo() ? 1 : .4;
    BV.$$('[data-k="undo"]', els.tools).forEach((b) => (b.style.opacity = ed.canUndo() ? 1 : .4));
    BV.$$('[data-k="redo"]', els.tools).forEach((b) => (b.style.opacity = ed.canRedo() ? 1 : .4));
  }

  /* ---------- imagens (painel de seleção) ---------- */
  function onPaperClick(e) {
    BV.$$('.bv-sel', els.paper).forEach((i) => i.classList.remove('bv-sel'));
    closeImgPanel();
    if (e.target.tagName === 'IMG') { e.target.classList.add('bv-sel'); openImgPanel(e.target); }
  }
  let imgPanel = null;
  function closeImgPanel() { if (imgPanel) { imgPanel.remove(); imgPanel = null; } }
  function openImgPanel(img) {
    const cur = parseInt(img.style.width, 10) || 80;
    const range = h('input', { type: 'range', min: 10, max: 100, value: cur, oninput: () => { img.style.width = range.value + '%'; lab.textContent = range.value + '%'; }, onchange: () => { ed.commit(); onEditorChange(); } });
    const lab = h('span', { class: 'chip' }, cur + '%');
    const al = (k) => () => { img.style.margin = k === 'left' ? '.7em auto .7em 0' : k === 'right' ? '.7em 0 .7em auto' : '.7em auto'; ed.commit(); onEditorChange(); };
    imgPanel = h('div', { class: 'img-panel glass' },
      h('div', { class: 'row', style: { alignItems: 'center' } }, range, lab),
      h('div', { class: 'row', style: { marginTop: '8px' } },
        h('button', { class: 'btn sm', onclick: al('left') }, icon('alignL', 'sm')), h('button', { class: 'btn sm', onclick: al('center') }, icon('alignC', 'sm')),
        h('button', { class: 'btn sm', onclick: al('right') }, icon('alignR', 'sm')),
        h('button', { class: 'btn sm danger', onclick: () => { ed.commit(); img.remove(); closeImgPanel(); ed._normalize(); ed._push(); onEditorChange(); } }, icon('trash', 'sm'))));
    els.dock.parentNode.appendChild(imgPanel);
  }

  /* ---------- tabela ---------- */
  function tableMenu() {
    const op = (x) => () => { ed.tableOp(x); updateToolState(); };
    BV.menu(t('Tabela'), [
      { icon: 'plus', label: t('Linha acima'), onClick: op('rowAbove') }, { icon: 'plus', label: t('Linha abaixo'), onClick: op('rowBelow') },
      { icon: 'plus', label: t('Coluna à esquerda'), onClick: op('colLeft') }, { icon: 'plus', label: t('Coluna à direita'), onClick: op('colRight') },
      { icon: 'minus', label: t('Eliminar linha'), onClick: op('delRow') }, { icon: 'minus', label: t('Eliminar coluna'), onClick: op('delCol') },
      { icon: 'trash', label: t('Eliminar tabela'), danger: true, onClick: op('delTable') }]);
  }

  /* ---------- estado ---------- */
  function onEditorChange() {
    writeBack();
    store.touch();
    els.saveState.textContent = t('A editar…'); els.saveState.className = 'save-state dirty';
    updateStatusDebounced(); updateUndo();
  }
  const updateStatusDebounced = BV.debounce(() => { updateStatus(); renderDrawerCounts(); schedulePageCount(); }, 350);
  function renderDrawerCounts() { if (E.drawerOpen()) renderDrawer(); }

  function updateStatus() {
    if (!ed || !els.status) return;
    const w = ed.wordCount(), c = ed.charCount();
    const total = BV.model.totalWords(book.doc);
    BV.clear(els.status);
    els.status.append(
      h('span', null, BV.fmtNum(w) + ' ' + t('palavras')), h('span', null, BV.fmtNum(c) + ' ' + t('caracteres')),
      h('span', { class: 'muted' }, t('Livro') + ': ' + BV.fmtNum(total)),
      els.pages = h('span', { class: 'muted' }, els.pagesText || ''));
    updateToolState();
  }
  const schedulePageCount = BV.debounce(() => {
    try {
      writeBack();
      const p = BV.paginate(book, { includeCovers: false });
      els.pagesText = p.total + ' ' + t('páginas');
      if (els.pages) els.pages.textContent = els.pagesText;
    } catch (e) { console.error(e); }
  }, 2200);

  function onSaved() { if (!els.saveState) return; els.saveState.textContent = '✓ ' + t('Guardado'); els.saveState.className = 'save-state ok'; }
  function onSaving() { if (!els.saveState) return; els.saveState.textContent = t('A guardar…'); els.saveState.className = 'save-state'; }
  function onSaveError() { if (!els.saveState) return; els.saveState.textContent = t('Erro ao guardar (cópia local mantida)'); els.saveState.className = 'save-state err'; }

  /* ---------- ações do topo ---------- */
  async function preview() { writeBack(); await store.saveNow(); BV.go('reader', { bookId: book.id }); }
  async function doExport() { writeBack(); await store.saveNow(); BV.exportDialog(book); }

  function moreMenu() {
    BV.menu(t('Livro'), [
      { icon: 'info', label: t('Informações do livro'), onClick: () => BV.bookInfoDialog(book, () => { els.title.textContent = book.title; store.touch(); }) },
      { icon: 'palette', label: t('Editor de capas'), sub: t('Capa, contracapa e lombada'), onClick: async () => { writeBack(); await store.saveNow(); BV.go('cover', { bookId: book.id }); } },
      { icon: 'layers', label: t('Estrutura do livro'), onClick: () => BV.structureDialog(book, () => { store.touch(); renderDrawer(); }) },
      { icon: 'header', label: t('Página, margens e tipografia'), onClick: () => BV.layoutDialog(book, () => { store.touch(); E.applyLayoutCss(); schedulePageCount(); }) },
      { icon: 'heading', label: t('Cabeçalho e rodapé'), onClick: () => BV.headerFooterDialog(book, () => store.touch()) },
      { icon: 'history', label: t('Versões anteriores'), onClick: () => BV.versionsDialog(book, async (nb) => { store.book = nb; cur = null; await E.open(nb.id); }) },
      { icon: 'star', label: t('Meta de palavras'), sub: BV.fmtNum(book.doc.goalWords) + ' ' + t('palavras'), onClick: async () => { const v = await BV.prompt(t('Meta de palavras do livro'), String(book.doc.goalWords), { type: 'number' }); const n = parseInt(v, 10); if (n > 0) { book.doc.goalWords = n; store.touch(); } } },
      { icon: 'check', label: book.status === 'completed' ? t('Marcar como rascunho') : t('Marcar como concluído'), onClick: () => { book.status = book.status === 'completed' ? 'draft' : 'completed'; store.touch(); BV.toast(book.status === 'completed' ? t('Livro concluído') : t('Livro em rascunho'), 'ok'); } },
      { icon: 'cloud', label: t('Marcar como publicado'), onClick: () => { book.status = 'published'; store.touch(); BV.toast(t('Livro marcado como publicado'), 'ok'); } }
    ]);
  }

  /* o botão "voltar" do Android: fecha painéis primeiro */
  E.back = function () {
    if (BV.closeTopModal()) return true;
    if (E.drawerOpen()) { toggleDrawer(false); return true; }
    if (imgPanel) { closeImgPanel(); return true; }
    return false;
  };
})();
