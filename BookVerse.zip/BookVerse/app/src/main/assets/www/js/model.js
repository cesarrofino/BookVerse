/* BookVerse — modelo do livro, estrutura interna, secções, utilitários de texto */
(function () {
  'use strict';
  const BV = window.BV;
  const M = (BV.model = {});

  M.CATEGORIES = ['Romance', 'Ficção', 'Fantasia', 'Terror', 'Suspense', 'Biografia', 'Educação', 'Tecnologia', 'Desenvolvimento pessoal', 'Poesia', 'História', 'Religião', 'Outros'];
  M.LANGUAGES = [['pt', 'Português'], ['en', 'English'], ['es', 'Español'], ['fr', 'Français'], ['de', 'Deutsch'], ['it', 'Italiano']];
  M.FONTS = [
    ['serif', 'Serifada (Noto Serif)'], ['sans-serif', 'Sem serifa (Roboto)'], ['monospace', 'Monoespaçada'],
    ['cursive', 'Manuscrita'], ['casual', 'Casual'], ['sans-serif-condensed', 'Condensada'], ['sans-serif-light', 'Leve'], ['serif-monospace', 'Máquina de escrever']
  ];
  M.PAGE_SIZES = { A4: [210, 297], A5: [148, 210], Letter: [215.9, 279.4] };

  /** Elementos da estrutura interna. fixed: gerado automaticamente; editable: página de texto editável. */
  M.STRUCTURE = [
    { key: 'cover', label: 'Capa', kind: 'auto', def: true },
    { key: 'title', label: 'Página de rosto', kind: 'auto', def: true },
    { key: 'copyright', label: 'Página de direitos autorais', kind: 'auto', def: true },
    { key: 'dedication', label: 'Dedicatória', kind: 'text', def: false },
    { key: 'acknowledgments', label: 'Agradecimentos', kind: 'text', def: false },
    { key: 'preface', label: 'Prefácio', kind: 'text', def: false },
    { key: 'toc', label: 'Índice', kind: 'auto', def: true },
    { key: 'intro', label: 'Introdução', kind: 'text', def: false },
    { key: 'chapters', label: 'Capítulos', kind: 'chapters', def: true },
    { key: 'conclusion', label: 'Conclusão', kind: 'text', def: false },
    { key: 'references', label: 'Referências', kind: 'text', def: false },
    { key: 'about', label: 'Sobre o autor', kind: 'text', def: false },
    { key: 'backcover', label: 'Contracapa', kind: 'auto', def: true }
  ];
  M.struct = (k) => M.STRUCTURE.find((s) => s.key === k);

  M.TEMPLATES = [
    { id: 'blank', name: 'Livro em branco', desc: 'Começar do zero com um capítulo vazio.', category: 'Outros', chapters: ['Capítulo 1'], structure: {} },
    { id: 'novel', name: 'Romance / Ficção', desc: 'Rosto, direitos, índice e 3 capítulos.', category: 'Romance', chapters: ['Capítulo 1', 'Capítulo 2', 'Capítulo 3'], structure: { dedication: true, about: true } },
    { id: 'nonfiction', name: 'Não-ficção', desc: 'Prefácio, introdução, capítulos, conclusão e referências.', category: 'Educação', chapters: ['Capítulo 1', 'Capítulo 2', 'Capítulo 3'], structure: { preface: true, intro: true, conclusion: true, references: true, about: true } },
    { id: 'poetry', name: 'Livro de poesia', desc: 'Dedicatória e poemas em páginas separadas.', category: 'Poesia', chapters: ['Poema I', 'Poema II', 'Poema III'], structure: { dedication: true, toc: true }, fontFamily: 'serif', lineHeight: 1.7 },
    { id: 'manual', name: 'Manual técnico', desc: 'Introdução, capítulos e referências.', category: 'Tecnologia', chapters: ['1. Primeiros passos', '2. Conceitos fundamentais', '3. Utilização avançada'], structure: { intro: true, references: true }, fontFamily: 'sans-serif' },
    { id: 'memoir', name: 'Biografia / Memórias', desc: 'Prefácio, agradecimentos e capítulos cronológicos.', category: 'Biografia', chapters: ['Infância', 'Juventude', 'Maturidade'], structure: { preface: true, acknowledgments: true, about: true } }
  ];

  M.defaultLayout = function (settings) {
    const s = settings || {};
    const sz = M.PAGE_SIZES[s.exportPageSize] ? s.exportPageSize : 'A5';
    return {
      fontFamily: s.defaultFont || 'serif',
      fontSizePt: parseFloat(s.defaultFontSize) || 12,
      lineHeight: parseFloat(s.lineHeight) || 1.5,
      paraSpacingPt: parseFloat(s.paragraphSpacing) || 8,
      firstLineIndentMm: 0,
      pageSize: sz,
      landscape: s.exportOrientation === 'landscape',
      margins: {
        top: parseFloat(s.marginTop) || 20, bottom: parseFloat(s.marginBottom) || 20,
        inner: parseFloat(s.marginInner) || 20, outer: parseFloat(s.marginOuter) || 20
      },
      header: { enabled: false, text: '', mode: 'title' },       // mode: title | author | custom
      footer: { enabled: true, text: '', pageNumbers: true }
    };
  };

  M.emptyDoc = function (settings, template) {
    const structure = {};
    for (const s of M.STRUCTURE) structure[s.key] = s.def;
    if (template && template.structure) Object.assign(structure, template.structure);
    const layout = M.defaultLayout(settings);
    if (template && template.fontFamily) layout.fontFamily = template.fontFamily;
    if (template && template.lineHeight) layout.lineHeight = template.lineHeight;
    const titles = (template && template.chapters) || ['Capítulo 1'];
    return {
      v: 1, structure, layout,
      chapters: titles.map((t) => ({ id: BV.shortId(), title: t, html: '<p><br></p>' })),
      extras: {},               // key -> html (dedicatória, prefácio, ...)
      extraTitles: {},          // key -> título personalizado
      cover: { front: null, back: null, spine: null, spineEnabled: false, spineWidthMm: 12 },
      goalWords: 20000,
      lastChapter: null
    };
  };

  M.normalizeDoc = function (doc, settings) {
    const d = doc && typeof doc === 'object' ? doc : {};
    const base = M.emptyDoc(settings);
    d.v = 1;
    d.structure = Object.assign({}, base.structure, d.structure || {});
    d.layout = Object.assign({}, base.layout, d.layout || {});
    d.layout.margins = Object.assign({}, base.layout.margins, (d.layout && d.layout.margins) || {});
    d.layout.header = Object.assign({}, base.layout.header, d.layout.header || {});
    d.layout.footer = Object.assign({}, base.layout.footer, d.layout.footer || {});
    if (!Array.isArray(d.chapters) || !d.chapters.length) d.chapters = base.chapters;
    d.chapters.forEach((c) => { if (!c.id) c.id = BV.shortId(); if (c.html == null) c.html = '<p><br></p>'; if (c.title == null) c.title = ''; });
    d.extras = d.extras || {}; d.extraTitles = d.extraTitles || {};
    d.cover = Object.assign({ front: null, back: null, spine: null, spineEnabled: false, spineWidthMm: 12 }, d.cover || {});
    if (!d.goalWords) d.goalWords = 20000;
    return d;
  };

  /* ---------- texto ---------- */
  M.textOf = function (html) {
    const d = document.createElement('div');
    d.innerHTML = html || '';
    d.querySelectorAll('script,style').forEach((e) => e.remove());
    d.querySelectorAll('p,div,h1,h2,h3,h4,li,tr,br,blockquote').forEach((e) => e.insertAdjacentText('afterend', ' '));
    return d.textContent.replace(/ /g, ' ');
  };
  M.countWords = function (html) {
    const t = M.textOf(html).trim();
    return t ? t.split(/\s+/).length : 0;
  };
  M.countChars = (html, spaces) => { const t = M.textOf(html).replace(/\s+/g, ' ').trim(); return spaces === false ? t.replace(/\s/g, '').length : t.length; };

  M.totalWords = function (doc) {
    let n = 0;
    doc.chapters.forEach((c) => (n += M.countWords(c.html)));
    ['dedication', 'acknowledgments', 'preface', 'intro', 'conclusion', 'references', 'about'].forEach((k) => {
      if (doc.structure[k]) n += M.countWords(doc.extras[k] || '');
    });
    return n;
  };
  M.progress = function (doc, status) {
    if (status === 'completed' || status === 'published') return 100;
    const goal = Math.max(100, doc.goalWords || 20000);
    return Math.min(99, Math.round((M.totalWords(doc) / goal) * 100));
  };

  /** Sanitiza HTML colado/importado: remove scripts, estilos perigosos e atributos de eventos. */
  M.sanitize = function (html) {
    const d = document.createElement('div');
    d.innerHTML = html;
    d.querySelectorAll('script,style,iframe,object,embed,link,meta,form,input,button,svg,video,audio').forEach((e) => e.remove());
    d.querySelectorAll('*').forEach((el) => {
      for (const a of Array.from(el.attributes)) {
        const n = a.name.toLowerCase();
        if (n.startsWith('on') || n === 'class' || n === 'id' || n.startsWith('data-') || n === 'contenteditable') el.removeAttribute(a.name);
        else if ((n === 'href' || n === 'src') && /^\s*javascript:/i.test(a.value)) el.removeAttribute(a.name);
        else if (n === 'style') {
          const keep = [];
          for (const rule of a.value.split(';')) {
            const [k, v] = rule.split(':'); if (!v) continue;
            const key = k.trim().toLowerCase();
            if (['font-weight', 'font-style', 'text-decoration', 'text-align', 'color', 'background-color', 'font-size', 'font-family', 'text-indent', 'margin-left', 'line-height'].includes(key) && !/url\(|expression/i.test(v)) keep.push(key + ':' + v.trim());
          }
          if (keep.length) el.setAttribute('style', keep.join(';')); else el.removeAttribute('style');
        }
      }
    });
    return d.innerHTML;
  };

  /* ---------- secções (usadas por paginação, leitor e exportação) ---------- */
  const esc = BV.esc;

  M.titleOf = function (doc, key) {
    const def = { dedication: 'Dedicatória', acknowledgments: 'Agradecimentos', preface: 'Prefácio', intro: 'Introdução', conclusion: 'Conclusão', references: 'Referências', about: 'Sobre o autor', toc: 'Índice' };
    return (doc.extraTitles && doc.extraTitles[key]) || def[key] || key;
  };

  /**
   * Constrói a lista ordenada de secções do livro com base na estrutura ativa.
   * Cada secção começa numa página nova. html já inclui o título da secção.
   */
  M.buildSections = function (book) {
    const doc = book.doc, st = doc.structure, out = [];
    const meta = book;
    if (st.cover) out.push({ id: 'cover', type: 'cover', title: 'Capa', html: '', inToc: false });
    if (st.title) {
      out.push({ id: 'title', type: 'title', title: 'Página de rosto', inToc: false, html:
        '<div class="front-title"><div class="ft-spacer"></div><h1 class="ft-title">' + esc(meta.title) + '</h1>' +
        (meta.subtitle ? '<p class="ft-sub">' + esc(meta.subtitle) + '</p>' : '') +
        '<div class="ft-rule"></div><p class="ft-author">' + esc(meta.author) + '</p><div class="ft-spacer"></div>' +
        (meta.publisher ? '<p class="ft-pub">' + esc(meta.publisher) + (meta.year ? ' · ' + esc(meta.year) : '') + '</p>' : '') + '</div>' });
    }
    if (st.copyright) {
      const lines = [];
      lines.push('<p><strong>' + esc(meta.title) + '</strong></p>');
      if (meta.copyright) lines.push('<p>' + esc(meta.copyright) + '</p>');
      else lines.push('<p>© ' + esc(meta.year || new Date().getFullYear()) + ' ' + esc(meta.author) + '. ' + BV.t('Todos os direitos reservados.') + '</p>');
      if (meta.publisher) lines.push('<p>' + BV.t('Editora') + ': ' + esc(meta.publisher) + '</p>');
      if (meta.isbn) lines.push('<p>ISBN: ' + esc(meta.isbn) + '</p>');
      lines.push('<p>' + BV.t('Criado com BookVerse.') + '</p>');
      out.push({ id: 'copyright', type: 'copyright', title: 'Direitos autorais', inToc: false, html: '<div class="front-copyright">' + lines.join('') + '</div>' });
    }
    const textSec = (key, inToc) => {
      if (!st[key]) return;
      const title = M.titleOf(doc, key);
      const body = doc.extras[key] || '<p><br></p>';
      if (key === 'dedication') out.push({ id: key, type: key, title, inToc: false, html: '<div class="front-dedication">' + body + '</div>' });
      else out.push({ id: key, type: key, title, inToc, html: '<h1 class="chap-title" data-toc="' + key + '">' + esc(title) + '</h1>' + body });
    };
    textSec('dedication'); textSec('acknowledgments', true); textSec('preface', true);
    if (st.toc) out.push({ id: 'toc', type: 'toc', title: M.titleOf(doc, 'toc'), html: '', inToc: false });
    textSec('intro', true);
    if (st.chapters !== false) doc.chapters.forEach((c, i) => {
      out.push({ id: c.id, type: 'chapter', title: c.title || (BV.t('Capítulo') + ' ' + (i + 1)), inToc: true,
        html: '<h1 class="chap-title" data-toc="' + c.id + '">' + esc(c.title || (BV.t('Capítulo') + ' ' + (i + 1))) + '</h1>' + (c.html || '') });
    });
    textSec('conclusion', true); textSec('references', true); textSec('about', true);
    if (st.backcover) out.push({ id: 'backcover', type: 'backcover', title: 'Contracapa', html: '', inToc: false });
    return out;
  };

  /** Entradas do índice a partir dos títulos de secção e subtítulos (h2/h3) dos capítulos. */
  M.buildToc = function (sections) {
    const toc = [];
    for (const s of sections) {
      if (!s.inToc) continue;
      toc.push({ title: s.title, sectionId: s.id, level: 1, anchor: s.id });
      if (s.type !== 'chapter' && s.type !== 'intro' && s.type !== 'preface') continue;
      const d = document.createElement('div'); d.innerHTML = s.html;
      let n = 0;
      d.querySelectorAll('h2,h3').forEach((h) => {
        const txt = h.textContent.trim(); if (!txt) return;
        toc.push({ title: txt, sectionId: s.id, level: h.tagName === 'H2' ? 2 : 3, anchor: s.id + ':h' + (n++) });
      });
    }
    return toc;
  };

  /** Dimensões da página em mm, com orientação. */
  M.pageMm = function (layout) {
    const [w, h] = M.PAGE_SIZES[layout.pageSize] || M.PAGE_SIZES.A5;
    return layout.landscape ? { w: h, h: w } : { w, h };
  };
  M.MM = 96 / 25.4;
})();
