/* BookVerse — painel inicial, criação de livro e componentes comuns */
(function () {
  'use strict';
  const BV = window.BV, store = BV.store;
  const h = BV.h, icon = BV.icon, t = (s) => BV.t(s);
  const Home = (BV.home = {});

  const CAT_COLORS = {
    'Romance': ['#be185d', '#fb7185'], 'Ficção': ['#1e3a8a', '#3b82f6'], 'Fantasia': ['#4c1d95', '#a78bfa'], 'Terror': ['#450a0a', '#b91c1c'],
    'Suspense': ['#111827', '#4b5563'], 'Biografia': ['#78350f', '#d6a55e'], 'Educação': ['#075985', '#38bdf8'], 'Tecnologia': ['#0f172a', '#06b6d4'],
    'Desenvolvimento pessoal': ['#c2410c', '#fbbf24'], 'Poesia': ['#374151', '#9ca3af'], 'História': ['#78350f', '#b45309'], 'Religião': ['#1e3a8a', '#fcd34d'], 'Infantil': ['#f59e0b', '#38bdf8'], 'Outros': ['#1d4ed8', '#60a5fa']
  };

  BV.statusLabel = (s) => ({ draft: t('Rascunho'), completed: t('Concluído'), published: t('Publicado') }[s] || s);

  /** Cartão de livro com capa, título, autor, data, estado e progresso. */
  BV.bookCard = function (b, o) {
    o = o || {};
    const c = CAT_COLORS[b.category] || CAT_COLORS['Outros'];
    const cover = b.coverUrl
      ? h('img', { class: 'bc-img', src: b.coverUrl, alt: '', loading: 'lazy' })
      : h('div', { class: 'bc-img placeholder', style: { background: 'linear-gradient(160deg,' + c[0] + ',' + c[1] + ')' } }, h('span', null, b.title));
    const sync = b.syncState && b.syncState !== 'local' ? h('i', { class: 'sync-dot ' + b.syncState, title: b.syncState }) : null;
    return h('div', { class: 'bcard' + (o.wide ? ' wide' : '') },
      h('button', { class: 'bc-open', onclick: () => o.onOpen && o.onOpen(b), 'aria-label': b.title },
        h('div', { class: 'bc-cover' }, cover, b.favorite ? h('span', { class: 'bc-fav' }, icon('star', 'sm')) : null, b.archived ? h('span', { class: 'bc-arch' }, icon('archive', 'sm')) : null),
        h('div', { class: 'bc-meta' },
          h('div', { class: 'bc-title' }, b.title), h('div', { class: 'bc-author' }, b.author || t('Autor desconhecido')),
          h('div', { class: 'bc-row' }, h('span', { class: 'badge ' + b.status }, BV.statusLabel(b.status)), sync, h('span', { class: 'bc-date' }, BV.fmtDate(b.updatedAt))),
          h('div', { class: 'progress' }, h('i', { style: { width: (b.progress || 0) + '%' } })), h('div', { class: 'bc-pct' }, (b.progress || 0) + '% · ' + BV.fmtNum(b.wordCount) + ' ' + t('palavras')))),
      o.onMenu ? h('button', { class: 'icon-btn bc-more', 'aria-label': 'Opções', onclick: (e) => { e.stopPropagation(); o.onMenu(b); } }, icon('more')) : null);
  };

  BV.greeting = function () {
    const hr = new Date().getHours();
    const g = hr < 12 ? t('Bom dia') : hr < 19 ? t('Boa tarde') : t('Boa noite');
    const n = (store.user.name || '').split(' ')[0];
    return n ? g + ', ' + n : g;
  };

  BV.logo = function (size) {
    return h('div', { class: 'logo' }, h('svg', { viewBox: '0 0 108 108', width: size || 34, height: size || 34 },
      h('rect', { width: 108, height: 108, rx: 26, fill: '#0b1226' }),
      (() => { const g = document.createElementNS('http://www.w3.org/2000/svg', 'g'); g.innerHTML = '<path fill="#3B82F6" d="M54,38 C46,32 36,31 28,33 L28,72 C36,70 46,71 54,77 Z"/><path fill="#60A5FA" d="M54,38 C62,32 72,31 80,33 L80,72 C72,70 62,71 54,77 Z"/><path fill="#fff" d="M54,45 L56.6,50.8 L62.8,51.4 L58.1,55.6 L59.5,61.8 L54,58.6 L48.5,61.8 L49.9,55.6 L45.2,51.4 L51.4,50.8 Z"/>'; return g; })()),
      h('span', { class: 'logo-t' }, 'BookVerse'));
  };

  BV.avatar = function (size) {
    const u = store.user;
    const initials = ((u.name || u.email || '?').trim()[0] || '?').toUpperCase();
    return u.photo ? h('img', { class: 'avatar', src: u.photo, style: { width: size + 'px', height: size + 'px' }, referrerpolicy: 'no-referrer', onerror: (e) => { e.target.replaceWith(h('div', { class: 'avatar txt', style: { width: size + 'px', height: size + 'px' } }, initials)); } })
      : h('div', { class: 'avatar txt', style: { width: size + 'px', height: size + 'px' } }, u.signedIn ? initials : icon('user'));
  };

  /** Barra de navegação inferior. */
  BV.navBar = function (active) {
    const item = (k, ic, label, fn) => h('button', { class: 'nav-i' + (active === k ? ' on' : ''), onclick: fn }, icon(ic), h('span', null, t(label)));
    return h('nav', { class: 'navbar glass' },
      item('home', 'home', 'Início', () => BV.go('home')), item('library', 'library', 'Biblioteca', () => BV.go('library')),
      h('button', { class: 'nav-fab', 'aria-label': 'Criar novo livro', onclick: () => BV.go('newbook') }, icon('plus', 'lg')),
      item('community', 'globe', 'Comunidade', () => BV.go('community')), item('settings', 'settings', 'Definições', () => BV.go('settings')));
  };

  /** Ações comuns sobre um livro (menu "⋮"). */
  BV.bookMenu = function (b, refresh) {
    BV.menu(b.title, [
      { icon: 'edit', label: t('Abrir no editor'), onClick: () => BV.go('editor', { bookId: b.id }) },
      { icon: 'star', label: b.favorite ? t('Remover dos favoritos') : t('Adicionar aos favoritos'), onClick: async () => { await BV.native('books.setFlag', { id: b.id, field: 'favorite', value: String(!b.favorite) }); refresh(); } },
      { icon: 'edit', label: t('Renomear'), onClick: async () => { const v = await BV.prompt(t('Novo título'), b.title); if (v && v.trim()) { await BV.native('books.rename', { id: b.id, title: v.trim() }); refresh(); } } },
      { icon: 'duplicate', label: t('Duplicar'), onClick: async () => { try { await BV.native('books.duplicate', { id: b.id }); BV.toast(t('Livro duplicado'), 'ok'); refresh(); } catch (e) { BV.error(e); } } },
      { icon: 'archive', label: b.archived ? t('Desarquivar') : t('Arquivar'), onClick: async () => { await BV.native('books.setFlag', { id: b.id, field: 'archived', value: String(!b.archived) }); refresh(); } },
      { icon: 'globe', label: t('Publicar na comunidade'), onClick: () => BV.publishBook(b) },
      { icon: 'close', label: t('Remover da comunidade'), onClick: () => BV.unpublishBook(b) },
      { icon: 'share', label: t('Exportar e partilhar'), onClick: () => BV.exportBookById(b.id) },
      { icon: 'trash', label: t('Eliminar'), danger: true, onClick: async () => {
        if (await BV.confirm(t('Eliminar') + ' "' + b.title + '"? ' + t('Esta ação não pode ser desfeita.'), { danger: true, ok: t('Eliminar') })) { await BV.native('books.delete', { id: b.id }); BV.toast(t('Livro eliminado')); refresh(); }
      } }]);
  };

  /* ---------- painel inicial ---------- */
  Home.render = async function () {
    const s = BV.clear(BV.$('#screen-home'));
    let books = [];
    try { books = await BV.native('books.list'); } catch (e) { BV.error(e); }
    const active = books.filter((b) => !b.archived);
    const open = (b) => BV.go('editor', { bookId: b.id });
    const refresh = () => Home.render();

    const search = h('input', { class: 'input search', type: 'search', placeholder: t('Pesquisar livros…'), enterkeyhint: 'search' });
    const results = h('div', { class: 'search-results' });
    const sections = h('div', { class: 'home-sections' });
    const doSearch = () => {
      const q = search.value.trim().toLowerCase();
      BV.clear(results); results.style.display = q ? '' : 'none'; sections.style.display = q ? 'none' : '';
      if (!q) return;
      const hits = books.filter((b) => (b.title + ' ' + b.subtitle + ' ' + b.author + ' ' + b.category).toLowerCase().includes(q));
      if (!hits.length) results.appendChild(h('div', { class: 'empty' }, icon('search'), h('div', null, t('Nenhum livro encontrado'))));
      else results.appendChild(h('div', { class: 'grid' }, hits.map((b) => BV.bookCard(b, { onOpen: open, onMenu: (x) => BV.bookMenu(x, refresh) }))));
    };
    search.addEventListener('input', BV.debounce(doSearch, 150));

    const section = (title, content, action) => h('section', { class: 'hs' }, h('div', { class: 'hs-h' }, h('h3', null, title), action ? h('button', { class: 'link', onclick: action.fn }, action.label) : null), content);
    const hscroll = (list) => h('div', { class: 'hscroll' }, list.map((b) => BV.bookCard(b, { onOpen: open, onMenu: (x) => BV.bookMenu(x, refresh) })));

    const last = active.slice().sort((a, b) => b.updatedAt - a.updatedAt)[0];
    const publ = active.filter((b) => b.status === 'published');

    if (books.length) {
      if (last) sections.appendChild(section(t('Continuar a escrever'), h('div', { class: 'continue card' }, BV.bookCard(last, { onOpen: open, wide: true }),
        h('button', { class: 'btn primary block', onclick: () => open(last) }, icon('edit'), t('Continuar a escrever')))));
      sections.appendChild(section(t('Livros recentes'), hscroll(active.slice().sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 8)), { label: t('Biblioteca'), fn: () => BV.go('library') }));
      sections.appendChild(section(t('Os meus livros'), h('div', { class: 'grid' }, active.slice(0, 6).map((b) => BV.bookCard(b, { onOpen: open, onMenu: (x) => BV.bookMenu(x, refresh) }))), { label: t('Ver todos'), fn: () => BV.go('library') }));
      if (publ.length) sections.appendChild(section(t('Publicados'), hscroll(publ)));
    }
    sections.appendChild(section(t('Modelos'), h('div', { class: 'hscroll tpls' }, BV.model.TEMPLATES.map((tp) =>
      h('button', { class: 'tpl-card', onclick: () => BV.go('newbook', { template: tp.id }) }, h('div', { class: 'tpl-ic' }, icon('book')), h('strong', null, t(tp.name)), h('small', null, t(tp.desc)))))));

    const syncBtn = h('button', { class: 'icon-btn', 'aria-label': 'Sincronização', onclick: () => BV.go('settings', { section: 'sync' }) }, icon('cloud'), h('i', { class: 'sync-dot', id: 'home-sync-dot', style: { position: 'absolute', marginTop: '14px', marginLeft: '12px' } }));
    s.append(
      h('div', { class: 'home-head' },
        BV.logo(36), h('div', { class: 'grow' }), syncBtn,
        h('button', { class: 'icon-btn', 'aria-label': 'Definições', onclick: () => BV.go('settings') }, icon('settings')),
        h('button', { class: 'avatar-btn', 'aria-label': 'Perfil', onclick: () => BV.go('account') }, BV.avatar(38))),
      h('div', { class: 'scroll home-scroll' },
        h('div', { class: 'hello' }, h('h1', null, BV.greeting()), h('p', null, books.length ? BV.fmtNum(books.length) + ' ' + (books.length === 1 ? t('livro') : t('livros')) + ' ' + t('na sua biblioteca') : t('O que vai criar hoje?'))),
        h('div', { class: 'search-wrap' }, icon('search'), search),
        results, sections, h('div', { style: { height: '96px' } })),
      BV.navBar('home'));
    BV.updateSyncDots && BV.updateSyncDots();
  };

  /* ---------- novo livro ---------- */
  Home.renderNew = async function (params) {
    params = params || {};
    const s = BV.clear(BV.$('#screen-newbook'));
    let tpl = BV.model.TEMPLATES.find((x) => x.id === params.template) || BV.model.TEMPLATES[0];
    const form = BV.bookForm({ author: store.user.name || '', category: tpl.category, year: String(new Date().getFullYear()), language: store.settings.language || 'pt' });
    const tplBox = h('div', { class: 'tpl-pick' });
    const drawTpls = () => {
      BV.clear(tplBox);
      BV.model.TEMPLATES.forEach((x) => tplBox.appendChild(h('button', { class: 'tpl-opt' + (x.id === tpl.id ? ' on' : ''), onclick: () => { tpl = x; form.fields.category.value = x.category; drawTpls(); } },
        h('strong', null, t(x.name)), h('small', null, t(x.desc)))));
    };
    drawTpls();
    const create = async (btn) => {
      const v = form.read();
      if (!v.title) { BV.toast(t('Escreva o título do livro'), 'error'); form.fields.title.focus(); return; }
      btn.disabled = true;
      try { const b = await store.create(v, tpl); BV.go('editor', { bookId: b.id, replace: true }); } catch (e) { btn.disabled = false; BV.error(e); }
    };
    const btn = h('button', { class: 'btn primary block', onclick: () => create(btn) }, icon('check'), t('Criar livro'));
    s.append(h('div', { class: 'topbar' }, h('button', { class: 'icon-btn', onclick: () => BV.go('home') }, icon('back')), h('h2', null, t('Novo livro'))),
      h('div', { class: 'scroll form-scroll' }, h('div', { class: 'form-wrap' },
        h('div', { class: 'grp-t', style: { marginTop: 0 } }, t('Modelo de partida')), tplBox, h('div', { style: { height: '14px' } }), form.el, btn, h('div', { style: { height: '40px' } }))));
    if (!params.pick) setTimeout(() => form.fields.title.focus(), 150);
  };
})();
