/* BookVerse — ecrã de boas-vindas (depois do splash) */
(function () {
  'use strict';
  const BV = window.BV, store = BV.store, h = BV.h, t = (s) => BV.t(s);
  const W = (BV.welcome = {});

  /** Mostra-se só na primeira abertura e só se ainda não houver sessão. */
  W.needed = () => store.settings.welcomeDone !== 'true' && !(store.user && store.user.signedIn);

  async function finish() {
    await store.setSetting('welcomeDone', 'true');
    BV.applyTheme();
    BV.go('home');
  }

  const googleG = () => {
    const d = document.createElement('div');
    d.innerHTML = '<svg width="20" height="20" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.9 2.4 30.4 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.2 5.5-4.7 7.2l7.6 5.9c4.4-4.1 6.9-10.1 6.9-17.6z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
    return d.firstChild;
  };

  W.render = async function () {
    const s = BV.clear(BV.$('#screen-welcome'));
    BV.native('app.setBars', { color: '#0a0e24', darkIcons: false }).catch(() => {});
    const gbtn = h('button', { class: 'wl-btn google' }, googleG(), t('Entrar com Google'));
    gbtn.addEventListener('click', async () => {
      gbtn.disabled = true;
      const b = BV.busy(t('Aguarde…'));
      try {
        const nu = await BV.native('auth.google', {});
        store.setUser(nu); b.done();
        BV.toast(t('Sessão iniciada'), 'ok');
        await finish();
      } catch (e) { b.done(); gbtn.disabled = false; BV.error(e); }
    });
    const skip = h('button', { class: 'wl-btn skip', onclick: finish }, t('Pular'));
    s.append(
      h('div', { class: 'wl-bg' }), h('div', { class: 'wl-scrim' }),
      h('div', { class: 'wl-content' },
        h('div', { class: 'wl-kicker' }, 'BookVerse'),
        h('h1', { class: 'wl-title' }, h('span', { class: 'wl-hi' }, t('Bem-vindo,')), h('span', { class: 'wl-name' }, t('Escritor'))),
        h('p', { class: 'wl-sub' }, t('Escreva, desenhe a capa e partilhe os seus livros com a comunidade.')),
        gbtn, skip,
        h('small', { class: 'wl-note' }, t('Ao pular, usa o BookVerse sem conta, offline. Pode entrar mais tarde nas Definições.'))));
  };
})();
