/* BookVerse — biblioteca pessoal */
(function () {
  'use strict';
  const BV = window.BV, store = BV.store;
  const h = BV.h, icon = BV.icon, t = (s) => BV.t(s);
  const Lib = (BV.library = {});
  const state = { filter: 'all', q: '', cat: '', sort: 'dateDesc' };

  const FILTERS = [['all', 'Todos'], ['favorites', 'Favoritos'], ['drafts', 'Rascunhos'], ['completed', 'Concluídos'], ['exported', 'Exportados'], ['recent', 'Recentes'], ['archived', 'Arquivados']];
  const SORTS = [['dateDesc', 'Mais recentes'], ['dateAsc', 'Mais antigos'], ['nameAsc', 'Nome (A–Z)'], ['nameDesc', 'Nome (Z–A)']];

  function apply(books) {
    let out = books.filter((b) => (state.filter === 'archived' ? b.archived : !b.archived));
    const week = Date.now() - 7 * 86400000;
    switch (state.filter) {
      case 'favorites': out = out.filter((b) => b.favorite); break;
      case 'drafts': out = out.filter((b) => b.status === 'draft'); break;
      case 'completed': out = out.filter((b) => b.status === 'completed' || b.status === 'published'); break;
      case 'exported': out = out.filter((b) => b.exported); break;
      case 'recent': out = out.filter((b) => b.updatedAt >= week); break;
    }
    if (state.cat) out = out.filter((b) => b.category === state.cat);
    if (state.q) { const q = state.q.toLowerCase(); out = out.filter((b) => (b.title + ' ' + b.subtitle + ' ' + b.author).toLowerCase().includes(q)); }
    const by = { dateDesc: (a, b) => b.updatedAt - a.updatedAt, dateAsc: (a, b) => a.updatedAt - b.updatedAt, nameAsc: (a, b) => a.title.localeCompare(b.title), nameDesc: (a, b) => b.title.localeCompare(a.title) }[state.sort];
    return out.sort(by);
  }

  Lib.render = async function () {
    const s = BV.clear(BV.$('#screen-library'));
    let books = [];
    try { books = await BV.native('books.list'); } catch (e) { BV.error(e); }
    const grid = h('div', { class: 'grid lib-grid' });
    const count = h('span', { class: 'chip' });
    const refresh = () => Lib.render();
    const draw = () => {
      const list = apply(books);
      BV.clear(grid); count.textContent = list.length + ' ' + (list.length === 1 ? t('livro') : t('livros'));
      if (!list.length) grid.appendChild(h('div', { class: 'empty', style: { gridColumn: '1/-1' } }, icon('book'), h('div', null, books.length ? t('Nenhum livro corresponde aos filtros') : t('A sua biblioteca está vazia')),
        books.length ? null : h('button', { class: 'btn primary', style: { marginTop: '14px' }, onclick: () => BV.go('newbook') }, icon('plus'), t('Criar livro'))));
      list.forEach((b) => grid.appendChild(BV.bookCard(b, { onOpen: (x) => BV.go('editor', { bookId: x.id }), onMenu: (x) => BV.bookMenu(x, refresh) })));
    };
    const chips = h('div', { class: 'chips' });
    const drawChips = () => { BV.clear(chips); FILTERS.forEach(([k, l]) => chips.appendChild(h('button', { class: 'chip' + (state.filter === k ? ' on' : ''), onclick: () => { state.filter = k; drawChips(); draw(); } }, t(l)))); };
    drawChips();
    const search = h('input', { class: 'input', type: 'search', placeholder: t('Pesquisar na biblioteca…'), value: state.q, oninput: BV.debounce(() => { state.q = search.value.trim(); draw(); }, 120) });
    const cat = BV.select([['', 'Todas as categorias']].concat(BV.model.CATEGORIES), state.cat, (v) => { state.cat = v; draw(); });
    const sort = BV.select(SORTS, state.sort, (v) => { state.sort = v; draw(); });
    s.append(
      h('div', { class: 'topbar' }, h('button', { class: 'icon-btn', onclick: () => BV.go('home') }, icon('back')), h('h2', null, t('Biblioteca')), count,
        h('button', { class: 'icon-btn', 'aria-label': 'Novo livro', onclick: () => BV.go('newbook') }, icon('plus'))),
      h('div', { class: 'scroll lib-scroll' }, h('div', { class: 'lib-tools' }, h('div', { class: 'search-wrap' }, icon('search'), search), chips, h('div', { class: 'row' }, cat, sort)), grid, h('div', { style: { height: '96px' } })),
      BV.navBar('library'));
    draw();
  };
})();
