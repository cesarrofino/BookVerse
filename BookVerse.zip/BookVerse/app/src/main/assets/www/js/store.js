/* BookVerse — estado, definições e gravação automática com cópia de segurança */
(function () {
  'use strict';
  const BV = window.BV;
  const S = (BV.store = {
    settings: {}, user: { signedIn: false }, book: null, dirty: false, saving: false, listeners: {}
  });

  S.on = (ev, fn) => { (S.listeners[ev] = S.listeners[ev] || []).push(fn); };
  S.emit = (ev, data) => (S.listeners[ev] || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } });

  /* ---- definições ---- */
  S.loadSettings = async function () {
    try { S.settings = await BV.native('settings.get'); } catch (e) { S.settings = {}; }
    return S.settings;
  };
  S.setSetting = async function (key, value) {
    S.settings[key] = String(value);
    try { await BV.native('settings.set', { key, value: String(value) }); } catch (e) { BV.error(e); }
    S.emit('settings', key);
  };

  /* ---- cópia de segurança em localStorage (proteção extra contra perda) ---- */
  const MIRROR = 'bv_mirror_';
  function mirrorWrite(book) {
    try { localStorage.setItem(MIRROR + book.id, JSON.stringify({ t: Date.now(), book })); } catch (e) { /* quota/indisponível */ }
  }
  function mirrorClear(id) { try { localStorage.removeItem(MIRROR + id); } catch (e) {} }
  S.mirrorFor = function (id) {
    try { const r = localStorage.getItem(MIRROR + id); return r ? JSON.parse(r) : null; } catch (e) { return null; }
  };

  /* ---- livro aberto ---- */
  S.open = async function (id) {
    let book = await BV.native('books.get', { id });
    book.doc = BV.model.normalizeDoc(book.doc, S.settings);
    // recuperar alterações não gravadas (ex.: fecho acidental antes da gravação)
    const m = S.mirrorFor(id);
    if (m && m.t > (book.updatedAt || 0) && m.book && m.book.doc) {
      book = m.book; book.doc = BV.model.normalizeDoc(book.doc, S.settings);
      S.dirty = true;
      BV.toast(BV.t('Alterações não gravadas recuperadas'), 'ok');
    } else mirrorClear(id);
    S.book = book;
    if (S.dirty) S.saveNow();
    return book;
  };

  S.create = async function (meta, template) {
    const doc = BV.model.emptyDoc(S.settings, template);
    const book = Object.assign({
      id: BV.uid(), title: 'Sem título', subtitle: '', author: S.user.name || '', description: '', category: 'Outros', language: 'pt',
      publisher: '', year: String(new Date().getFullYear()), copyright: '', isbn: '', status: 'draft'
    }, meta, { doc });
    book.progress = 0; book.wordCount = 0;
    const saved = await BV.native('books.save', book);
    book.createdAt = saved.createdAt; book.updatedAt = saved.updatedAt;
    S.book = book; S.dirty = false;
    return book;
  };

  S.touch = function () {
    if (!S.book) return;
    S.dirty = true;
    S.emit('dirty');
    mirrorWrite(S.book);
    S.autosave();
  };

  S.autosave = BV.debounce(function () {
    if (S.settings.autosave === 'false') return;
    S.saveNow();
  }, 3000);

  S.updateAutosaveDelay = function () {
    const sec = Math.max(1, parseInt(S.settings.autosaveSeconds, 10) || 3);
    S.autosave = BV.debounce(function () { if (S.settings.autosave !== 'false') S.saveNow(); }, sec * 1000);
  };

  /** Grava imediatamente (local primeiro). Nunca lança: em caso de erro mantém o estado sujo e a cópia de segurança. */
  S.saveNow = async function () {
    const book = S.book;
    if (!book) return false;
    if (S.saving) { S.pendingSave = true; return false; }
    S.saving = true;
    S.emit('saving');
    try {
      const doc = book.doc;
      book.wordCount = BV.model.totalWords(doc);
      book.progress = BV.model.progress(doc, book.status);
      const payload = Object.assign({}, book);
      const saved = await BV.native('books.save', payload);
      book.updatedAt = saved.updatedAt;
      if (!S.pendingSave) { S.dirty = false; mirrorClear(book.id); }
      S.emit('saved', book);
      return true;
    } catch (e) {
      console.error(e);
      S.emit('save-error', e);
      return false;
    } finally {
      S.saving = false;
      if (S.pendingSave) { S.pendingSave = false; S.saveNow(); }
    }
  };

  S.flush = async function () {
    S.autosave.cancel && S.autosave.cancel();
    if (S.dirty) await S.saveNow();
  };

  S.close = async function () {
    await S.flush();
    S.book = null;
  };

  /* Grava ao sair da aplicação, perder foco ou esconder a página */
  window.bvFlush = function () { if (S.dirty) S.saveNow(); };
  document.addEventListener('visibilitychange', () => { if (document.hidden && S.dirty) S.saveNow(); });
  window.addEventListener('pagehide', () => { if (S.dirty) S.saveNow(); });

  /* ---- estado de sessão ---- */
  S.loadUser = async function () {
    try { S.user = await BV.native('auth.state'); } catch (e) { S.user = { signedIn: false }; }
    return S.user;
  };

  S.setUser = function (u) { S.user = u; S.emit('user'); };
})();
