/* BookVerse — diálogo e fluxo de exportação (PDF, EPUB, DOCX, TXT) e partilha */
(function () {
  'use strict';
  const BV = window.BV, store = BV.store;
  const h = BV.h, icon = BV.icon, t = (s) => BV.t(s);

  const FORMATS = [
    { k: 'pdf', label: 'PDF', desc: 'Capa, páginas, índice e margens fiéis à pré-visualização' },
    { k: 'epub', label: 'EPUB', desc: 'Livro digital com índice navegável e capa' },
    { k: 'docx', label: 'DOCX', desc: 'Editável no Microsoft Word' },
    { k: 'txt', label: 'TXT', desc: 'Texto simples sem formatação' }
  ];
  const COVER_W = { low: 700, medium: 1000, high: 1500 };

  /** Constrói o pedido para o motor nativo. `layout` é o esquema escolhido para esta exportação. */
  BV.buildExportRequest = async function (book, format, opt) {
    const base = BV.model.PAGE_SIZES[opt.layout.pageSize] || BV.model.PAGE_SIZES.A5;
    const eb = { ...book, doc: { ...book.doc, layout: opt.layout } };
    const sections = BV.model.buildSections(eb);
    const toc = BV.model.buildToc(sections);
    const L = opt.layout, m = L.margins;
    const req = {
      format, bookId: book.id, title: book.title, subtitle: book.subtitle, author: book.author, language: book.language,
      publisher: book.publisher, year: book.year, copyright: book.copyright, isbn: book.isbn, description: book.description,
      fontFamily: L.fontFamily, fontSizePt: L.fontSizePt, lineHeight: L.lineHeight,
      pageWmm: base[0], pageHmm: base[1], landscape: !!L.landscape,
      marginTop: m.top, marginBottom: m.bottom, marginInner: m.inner, marginOuter: m.outer,
      imageQuality: opt.quality, includeBackCover: opt.backCover,
      sections: sections.map((s) => ({ id: s.id, type: s.type, title: s.title, html: s.html, inToc: s.inToc })),
      toc: toc.map((e) => ({ title: e.title, sectionId: e.sectionId, level: e.level }))
    };
    if (format !== 'txt') {
      const covers = await BV.coverImages(book, COVER_W[opt.quality] || 1000);
      req.coverFront = (eb.doc.structure.cover ? covers.front : '') || '';
      req.coverBack = (eb.doc.structure.backcover && opt.backCover ? covers.back : '') || '';
    }
    if (format === 'pdf') {
      const res = BV.paginate(eb, { includeCovers: false });
      // páginas de capa são adicionadas pelo motor nativo, só se ativas na estrutura
      req.pagesHtml = res.pages.map((p) => p.html).join('');
      req.pagesCss = res.css;
      req.pageCount = res.total;
    }
    return req;
  };

  BV.exportDialog = async function (book) {
    try { await store.flush(); } catch (e) { /* continua com a cópia local */ }
    const S = store.settings, L0 = book.doc.layout;
    const sel = new Set(['pdf']);
    const layoutSize = BV.model.PAGE_SIZES[L0.pageSize] ? L0.pageSize : (S.exportPageSize || 'A5');
    const opts = { size: layoutSize, orient: L0.landscape ? 'landscape' : (S.exportOrientation || 'portrait'), quality: S.exportImageQuality || 'high', backCover: S.exportIncludeBackCover !== 'false', custom: false, m: { ...L0.margins } };

    const formatCards = h('div', { class: 'fmt-grid' });
    const drawFormats = () => {
      BV.clear(formatCards);
      FORMATS.forEach((f) => formatCards.appendChild(h('button', { class: 'fmt' + (sel.has(f.k) ? ' on' : ''), onclick: () => { if (sel.has(f.k)) { if (sel.size > 1) sel.delete(f.k); } else sel.add(f.k); drawFormats(); } },
        h('strong', null, f.label), h('small', null, t(f.desc)))));
    };
    drawFormats();

    const size = BV.select(Object.keys(BV.model.PAGE_SIZES), opts.size, (v) => (opts.size = v));
    const orient = BV.select([['portrait', 'Vertical'], ['landscape', 'Horizontal']], opts.orient, (v) => (opts.orient = v));
    const quality = BV.select([['high', 'Alta'], ['medium', 'Média'], ['low', 'Baixa (ficheiro menor)']], opts.quality, (v) => (opts.quality = v));
    const back = BV.switchEl(opts.backCover, (v) => (opts.backCover = v));
    const mField = (k, label) => { const i = h('input', { class: 'input', type: 'number', min: 5, max: 60, value: opts.m[k], oninput: () => (opts.m[k] = +i.value || opts.m[k]) }); return BV.field(label, i); };
    const marginsBox = h('div', { style: { display: 'none' } }, h('div', { class: 'row' }, mField('top', t('Superior (mm)')), mField('bottom', t('Inferior (mm)'))), h('div', { class: 'row' }, mField('inner', t('Interior (mm)')), mField('outer', t('Exterior (mm)'))));
    const customSw = BV.switchEl(false, (v) => { opts.custom = v; marginsBox.style.display = v ? '' : 'none'; });

    const body = h('div', null,
      h('div', { class: 'grp-t', style: { marginTop: 0 } }, t('Formatos')), formatCards,
      h('div', { class: 'row' }, BV.field(t('Tamanho'), size), BV.field(t('Orientação'), orient)),
      BV.field(t('Qualidade das imagens'), quality),
      h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '4px 0 12px' } }, h('span', null, t('Incluir contracapa')), back),
      h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '4px 0 12px' } }, h('span', null, t('Margens personalizadas')), customSw), marginsBox,
      h('small', { style: { color: 'var(--muted)' } }, t('As exportações funcionam sem internet. O tamanho, orientação e margens aplicam-se ao PDF e DOCX.')));

    BV.modal({ title: t('Exportar livro'), body, actions: [{ label: t('Cancelar') }, { label: t('Exportar'), primary: true, keepOpen: true, onClick: async (close) => { close(); runExport(book, Array.from(sel), opts); return false; } }] });
  };

  async function runExport(book, formats, opts) {
    const L = JSON.parse(JSON.stringify(book.doc.layout));
    L.pageSize = opts.size; L.landscape = opts.orient === 'landscape';
    if (opts.custom) L.margins = { ...opts.m };
    const results = [];
    const b = BV.busy(t('A exportar…'));
    try {
      for (const f of formats) {
        b.update(t('A exportar') + ' ' + f.toUpperCase() + '…');
        await BV.nextFrame();
        const req = await BV.buildExportRequest(book, f, { layout: L, quality: opts.quality, backCover: opts.backCover });
        const r = await BV.native('export.run', req);
        results.push(Object.assign({ format: f }, r));
      }
    } catch (e) { b.done(); BV.error(e); if (!results.length) return; }
    b.done();
    showResults(book, results);
  }

  function showResults(book, results) {
    const rows = results.map((r) => h('div', { class: 'exp-row' },
      h('div', { class: 'exp-head' }, icon('file'), h('div', null, h('strong', null, r.fileName), h('small', { style: { display: 'block', color: 'var(--muted)' } }, BV.fmtBytes(r.size)))),
      h('div', { class: 'exp-actions' },
        h('button', { class: 'btn sm primary', onclick: () => act('export.share', r, book) }, icon('share', 'sm'), t('Partilhar') + ' ' + r.format.toUpperCase()),
        h('button', { class: 'btn sm', onclick: () => saveToDevice(r) }, icon('download', 'sm'), t('Guardar no dispositivo')),
        h('button', { class: 'btn sm', onclick: () => act('export.open', r, book) }, icon('eye', 'sm'), t('Abrir com…')))));
    BV.modal({ title: t('Exportação concluída'), body: h('div', null, rows, h('small', { style: { color: 'var(--muted)' } }, t('Ao partilhar, escolha a aplicação (WhatsApp, Telegram, Gmail, Bluetooth, Google Drive…).'))), actions: [{ label: t('Fechar'), primary: true }] });
  }
  async function act(method, r, book) {
    try { await BV.native(method, { path: r.path, mime: r.mime, subject: book.title }); } catch (e) { BV.error(e); }
  }
  async function saveToDevice(r) {
    try { const x = await BV.native('export.saveToDevice', { path: r.path, mime: r.mime }); if (!x.cancelled) BV.toast(t('Guardado no dispositivo'), 'ok'); } catch (e) { BV.error(e); }
  }

  /** Exportar um livro a partir da biblioteca (sem o abrir no editor). */
  BV.exportBookById = async function (id) {
    const b = BV.busy(t('A preparar…'));
    try { await store.flush(); const book = await store.open(id); b.done(); BV.exportDialog(book); } catch (e) { b.done(); BV.error(e); }
  };
})();
