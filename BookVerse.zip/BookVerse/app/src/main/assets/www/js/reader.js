/* BookVerse — leitor / pré-visualização (usa exatamente as mesmas páginas que o PDF) */
(function () {
  'use strict';
  const BV = window.BV, store = BV.store;
  const h = BV.h, icon = BV.icon, t = (s) => BV.t(s);
  const R = (BV.reader = {});
  const MM = BV.model.MM;

  let book, res, spreads = [], si = 0, mode = 'single', zoom = 1, reading = false, tone = 'paper', els = {}, busy = false, W = 0, H = 0;

  R.open = async function (bookId) {
    const b = BV.busy(t('A paginar o livro…'));
    try {
      await store.flush();
      book = store.book && store.book.id === bookId ? store.book : await store.open(bookId);
      await BV.nextFrame();
      const covers = await BV.coverImages(book, 900);
      res = BV.paginate(book, { covers });
    } catch (e) { b.done(); BV.error(e); BV.go('editor', { bookId }); return; }
    b.done();
    mode = (window.innerWidth >= 900 && window.innerWidth > window.innerHeight) ? 'double' : 'single';
    zoom = 1; reading = false; si = 0;
    W = res.geo.pageW * MM; H = res.geo.pageH * MM;
    buildSpreads(); build(); show(0, false);
  };

  R.leave = function () { document.removeEventListener('keydown', onKey); window.removeEventListener('resize', onResize); };

  function buildSpreads() {
    spreads = [];
    const P = res.pages;
    const inner = P.filter((p) => p.type !== 'cover' && p.type !== 'backcover');
    const cover = P.find((p) => p.type === 'cover'), back = P.find((p) => p.type === 'backcover');
    if (mode === 'single') {
      P.forEach((p) => spreads.push([p]));
      return;
    }
    if (cover) spreads.push([null, cover]);
    for (let i = 0; i < inner.length; i += (i === 0 ? 1 : 2)) {
      if (i === 0) spreads.push([null, inner[0]]);
      else spreads.push([inner[i], inner[i + 1] || null]);
    }
    if (back) spreads.push([back, null]);
  }
  const pageIndexOf = (sp) => { const p = sp.find(Boolean); return p ? p.index : 0; };
  function spreadFor(pageIdx) { const i = spreads.findIndex((s) => s.some((p) => p && p.index === pageIdx)); return i < 0 ? 0 : i; }

  /* ---------- estrutura ---------- */
  function build() {
    const s = BV.clear(BV.$('#screen-reader'));
    s.className = 'screen active reader tone-' + tone;
    els.top = h('div', { class: 'topbar' },
      h('button', { class: 'icon-btn', onclick: () => BV.go('editor', { bookId: book.id }) }, icon('back')),
      h('h2', null, book.title),
      h('button', { class: 'icon-btn', 'aria-label': 'Índice', onclick: tocMenu }, icon('chapters')),
      (els.modeBtn = h('button', { class: 'icon-btn', 'aria-label': 'Páginas', onclick: toggleMode }, icon(mode === 'single' ? 'pages2' : 'page1'))),
      h('button', { class: 'icon-btn', 'aria-label': 'Zoom -', onclick: () => setZoom(zoom - 0.5) }, icon('zoomOut')),
      h('button', { class: 'icon-btn', 'aria-label': 'Zoom +', onclick: () => setZoom(zoom + 0.5) }, icon('zoomIn')),
      h('button', { class: 'icon-btn', 'aria-label': 'Modo de leitura', onclick: () => setReading(true) }, icon('book2')),
      h('button', { class: 'icon-btn', 'aria-label': 'Exportar', onclick: () => BV.exportDialog(book) }, icon('share')));
    els.stage = h('div', { class: 'rd-stage' }, (els.holder = h('div', { class: 'rd-holder' })));
    els.range = h('input', { type: 'range', min: 0, max: Math.max(0, res.pages.length - 1), value: 0, oninput: () => { const i = spreadFor(+els.range.value); if (i !== si) show(i, false); }, });
    els.label = h('span', { class: 'rd-label' });
    els.bottom = h('div', { class: 'rd-bottom glass' },
      h('button', { class: 'icon-btn', onclick: () => go(-1) }, icon('back')), els.range, h('button', { class: 'icon-btn', onclick: () => go(1) }, icon('forward')), els.label);
    els.exit = h('button', { class: 'rd-exit chip', onclick: () => setReading(false) }, icon('close', 'sm'), t('Sair do modo de leitura'));
    s.append(els.top, els.stage, els.bottom, els.exit);
    els.stage.addEventListener('pointerdown', onPointerDown);
    document.addEventListener('keydown', onKey); window.addEventListener('resize', onResize);
  }
  const onKey = (e) => { if (!BV.$('#screen-reader.active')) return; if (e.key === 'ArrowRight') go(1); else if (e.key === 'ArrowLeft') go(-1); };
  const onResize = BV.debounce(() => { if (BV.$('#screen-reader.active')) show(si, false); }, 150);

  function pageEl(p) {
    const box = h('div', { class: 'rd-page', style: { width: W + 'px', height: H + 'px' } });
    if (p) { box.innerHTML = p.html; if (box.firstElementChild) { box.firstElementChild.classList.add('rd-sheet'); } }
    else box.classList.add('rd-blank');
    return box;
  }
  function fitScale(cols) {
    const r = els.stage.getBoundingClientRect();
    const aw = Math.max(100, r.width - (reading ? 8 : 24)), ah = Math.max(100, r.height - (reading ? 8 : 20));
    return Math.min(aw / (W * cols), ah / H);
  }

  /* ---------- apresentação ---------- */
  function show(i, animate, dir) {
    si = Math.max(0, Math.min(spreads.length - 1, i));
    const sp = spreads[si], cols = mode === 'double' && sp.length === 2 ? 2 : 1;
    const sc = fitScale(mode === 'double' ? 2 : 1) * zoom;
    const wrap = h('div', { class: 'rd-spread', style: { width: W * cols + 'px', height: H + 'px', transform: 'scale(' + sc + ')', transformOrigin: 'top left' } });
    sp.forEach((p) => { if (mode === 'double' || p) wrap.appendChild(pageEl(p)); });
    const outer = h('div', { class: 'rd-fit', style: { width: W * cols * sc + 'px', height: H * sc + 'px' } }, wrap);
    BV.clear(els.holder).appendChild(outer);
    els.stage.classList.toggle('zoomed', zoom > 1);
    wireToc(wrap);
    // indicadores
    const first = sp.find(Boolean), last = sp.slice().reverse().find(Boolean);
    const lab = (p) => (p.type === 'cover' ? t('Capa') : p.type === 'backcover' ? t('Contracapa') : p.label);
    els.label.textContent = first === last || !last ? lab(first) + ' / ' + res.total : lab(first) + '–' + lab(last) + ' / ' + res.total;
    els.range.value = pageIndexOf(sp);
  }

  function wireToc(wrap) {
    BV.$$('[data-goto]', wrap).forEach((el) => { el.style.cursor = 'pointer'; el.addEventListener('click', () => { const lbl = el.getAttribute('data-goto'); const p = res.pages.find((x) => x.label === lbl); if (p) show(spreadFor(p.index), false); }); });
  }

  /** Navega com efeito de folha a virar (3D). */
  function go(dir) {
    if (busy) return;
    const ni = si + dir; if (ni < 0 || ni >= spreads.length) return;
    if (zoom > 1 || matchMedia('(prefers-reduced-motion: reduce)').matches) { show(ni, false); return; }
    busy = true;
    const from = spreads[si], to = spreads[ni], dbl = mode === 'double';
    const sc = fitScale(dbl ? 2 : 1);
    const cols = dbl ? 2 : 1, wTot = W * cols;
    const box = h('div', { class: 'rd-turn', style: { width: wTot * sc + 'px', height: H * sc + 'px' } });
    const inner = h('div', { class: 'rd-turn-in', style: { width: wTot + 'px', height: H + 'px', transform: 'scale(' + sc + ')', transformOrigin: 'top left' } });
    box.appendChild(inner);
    const place = (el, x) => { el.style.position = 'absolute'; el.style.left = x + 'px'; el.style.top = '0'; inner.appendChild(el); return el; };
    let leaf;
    const face = (p) => pageEl(p);
    if (dbl) {
      if (dir > 0) {
        // por baixo: esquerda antiga + direita nova; folha: direita antiga (frente) → esquerda nova (verso)
        place(face(from[0]), 0); place(face(to[1]), W);
        leaf = h('div', { class: 'leaf', style: { position: 'absolute', left: W + 'px', top: 0, width: W + 'px', height: H + 'px', transformOrigin: 'left center' } },
          h('div', { class: 'leaf-f' }, face(from[1])), h('div', { class: 'leaf-b' }, face(to[0])));
        inner.appendChild(leaf); anim(leaf, 0, -180);
      } else {
        place(face(to[0]), 0); place(face(from[1]), W);
        leaf = h('div', { class: 'leaf', style: { position: 'absolute', left: 0, top: 0, width: W + 'px', height: H + 'px', transformOrigin: 'right center' } },
          h('div', { class: 'leaf-f' }, face(from[0])), h('div', { class: 'leaf-b' }, face(to[1])));
        inner.appendChild(leaf); anim(leaf, 0, 180);
      }
    } else {
      if (dir > 0) {
        place(face(to[0]), 0);
        leaf = h('div', { class: 'leaf', style: { position: 'absolute', left: 0, top: 0, width: W + 'px', height: H + 'px', transformOrigin: 'left center' } }, h('div', { class: 'leaf-f' }, face(from[0])), h('div', { class: 'leaf-b' }, h('div', { class: 'rd-page rd-blank', style: { width: W + 'px', height: H + 'px' } })));
        inner.appendChild(leaf); anim(leaf, 0, -180);
      } else {
        place(face(from[0]), 0);
        leaf = h('div', { class: 'leaf', style: { position: 'absolute', left: 0, top: 0, width: W + 'px', height: H + 'px', transformOrigin: 'left center' } }, h('div', { class: 'leaf-f' }, face(to[0])), h('div', { class: 'leaf-b' }, h('div', { class: 'rd-page rd-blank', style: { width: W + 'px', height: H + 'px' } })));
        inner.appendChild(leaf); anim(leaf, -180, 0);
      }
    }
    BV.clear(els.holder).appendChild(box);
    setTimeout(() => { busy = false; show(ni, false); }, 470);
  }
  function anim(leaf, a0, a1) {
    leaf.style.transform = 'rotateY(' + a0 + 'deg)';
    leaf.style.transition = 'none';
    requestAnimationFrame(() => requestAnimationFrame(() => { leaf.style.transition = 'transform .45s cubic-bezier(.45,.05,.25,1)'; leaf.style.transform = 'rotateY(' + a1 + 'deg)'; }));
  }

  /* ---------- gestos ---------- */
  const ptrs = new Map();
  let startX = 0, startY = 0, startT = 0, pinch0 = 0, zoom0 = 1, lastTap = 0;
  function onPointerDown(e) {
    ptrs.set(e.pointerId, e);
    if (ptrs.size === 1) { startX = e.clientX; startY = e.clientY; startT = Date.now(); }
    if (ptrs.size === 2) { const [a, b] = Array.from(ptrs.values()); pinch0 = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY); zoom0 = zoom; }
    const mv = (m) => { ptrs.set(m.pointerId, m); if (ptrs.size === 2 && pinch0) { const [a, b] = Array.from(ptrs.values()); const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY); setZoom(Math.round(zoom0 * d / pinch0 * 4) / 4, true); } };
    const up = (u) => {
      ptrs.delete(u.pointerId);
      if (ptrs.size === 0) {
        els.stage.removeEventListener('pointermove', mv); els.stage.removeEventListener('pointerup', up); els.stage.removeEventListener('pointercancel', up);
        const dx = u.clientX - startX, dy = u.clientY - startY, dt = Date.now() - startT;
        if (pinch0) { pinch0 = 0; return; }
        if (zoom <= 1 && Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) go(dx < 0 ? 1 : -1);
        else if (Math.abs(dx) < 10 && Math.abs(dy) < 10 && dt < 300) {
          if (u.target.closest && u.target.closest('[data-goto]')) return;
          const now = Date.now();
          if (now - lastTap < 300) { setZoom(zoom > 1 ? 1 : 2); lastTap = 0; return; }
          lastTap = now;
          const r = els.stage.getBoundingClientRect(), x = (u.clientX - r.left) / r.width;
          if (reading && zoom <= 1) { if (x > 0.66) go(1); else if (x < 0.34) go(-1); else toggleBars(); }
        }
      }
    };
    els.stage.addEventListener('pointermove', mv); els.stage.addEventListener('pointerup', up); els.stage.addEventListener('pointercancel', up);
  }
  function setZoom(z, silent) { zoom = Math.max(1, Math.min(4, z)); show(si, false); if (!silent) BV.toast(Math.round(zoom * 100) + '%'); }
  function toggleMode() {
    const keep = pageIndexOf(spreads[si]);
    mode = mode === 'single' ? 'double' : 'single'; buildSpreads(); si = spreadFor(keep);
    BV.clear(els.modeBtn).appendChild(icon(mode === 'single' ? 'pages2' : 'page1')); show(si, false);
  }
  function setReading(on) {
    reading = on; BV.$('#screen-reader').classList.toggle('reading', on); zoom = 1;
    if (on) { BV.toast(t('Toque nas margens para virar a página · no centro para mostrar os controlos')); const tones = ['paper', 'sepia', 'night']; tone = tones[(tones.indexOf(tone) + 0) % 3]; }
    setTimeout(() => show(si, false), 30);
  }
  function toggleBars() { BV.$('#screen-reader').classList.toggle('bars'); }

  function tocMenu() {
    const items = [];
    const cover = res.pages.find((p) => p.type === 'cover');
    if (cover) items.push({ icon: 'image', label: t('Capa'), onClick: () => show(spreadFor(cover.index), false) });
    res.toc.forEach((e) => {
      const idx = res.anchors[e.anchor];
      if (idx == null) return;
      const pg = res.pages[idx];
      items.push({ icon: e.level === 1 ? 'file' : 'minus', label: (e.level > 1 ? '   '.repeat(e.level - 1) : '') + e.title, sub: t('Página') + ' ' + pg.label, onClick: () => show(spreadFor(idx), false) });
    });
    const back = res.pages.find((p) => p.type === 'backcover');
    if (back) items.push({ icon: 'image', label: t('Contracapa'), onClick: () => show(spreadFor(back.index), false) });
    if (!items.length) items.push({ label: t('Sem entradas no índice'), onClick: () => {} });
    const tones = { paper: 'Papel', sepia: 'Sépia', night: 'Noite' };
    items.push({ icon: 'palette', label: t('Fundo de leitura') + ': ' + t(tones[tone]), onClick: () => { const k = Object.keys(tones); tone = k[(k.indexOf(tone) + 1) % 3]; BV.$('#screen-reader').className = 'screen active reader tone-' + tone + (reading ? ' reading' : ''); } });
    BV.menu(t('Índice navegável'), items);
  }

  R.back = function () {
    if (BV.closeTopModal()) return true;
    if (reading) { setReading(false); return true; }
    return false;
  };
  R.result = () => res;
})();
