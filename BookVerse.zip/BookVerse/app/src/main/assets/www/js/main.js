/* BookVerse — arranque, tema e navegação */
(function () {
  'use strict';
  const BV = window.BV, store = BV.store;
  let current = null;
  const PARENT = { editor: 'home', cover: 'editor', reader: 'editor', newbook: 'home', library: 'home', settings: 'home', account: 'settings', community: 'home', communityBook: 'community' };
  let editorOrigin = 'home';

  /* ---------- tema ---------- */
  BV.applyTheme = function () {
    const pref = store.settings.theme || 'auto';
    const dark = pref === 'dark' || (pref === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    const color = dark ? '#070b16' : '#ffffff';
    BV.native('app.setBars', { color, darkIcons: !dark }).catch(() => {});
  };
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if ((store.settings.theme || 'auto') === 'auto') BV.applyTheme(); });

  /* ---------- navegação ---------- */
  BV.go = async function (name, params) {
    params = params || {};
    const prev = current;
    // saída do ecrã anterior (grava, liberta recursos)
    try {
      if (prev === 'editor' && name !== 'editor') { await BV.editorScreen.close(); }
      if (prev === 'cover' && name !== 'cover') { await BV.coverScreen.leave(); }
      if (prev === 'reader' && name !== 'reader') BV.reader.leave();
    } catch (e) { console.error(e); }

    // fora do conjunto editor/capas/leitor o livro em memória é libertado (a próxima abertura lê da base de dados)
    if (!['editor', 'cover', 'reader'].includes(name) && store.book && !store.dirty) store.book = null;
    if (name === 'editor') {
      if (prev && prev !== 'cover' && prev !== 'reader' && prev !== 'editor') editorOrigin = prev;
      if (prev === 'cover' || prev === 'reader') { /* voltar ao editor mantendo o livro aberto */ }
    }
    BV.$$('.screen').forEach((s) => s.classList.remove('active'));
    const el = BV.$('#screen-' + name);
    current = name;
    el.classList.add('active');
    try {
      if (name === 'home') await BV.home.render();
      else if (name === 'library') await BV.library.render();
      else if (name === 'newbook') await BV.home.renderNew(params);
      else if (name === 'editor') { await BV.editorScreen.open(params.bookId); }
      else if (name === 'cover') await BV.coverScreen.open(params.bookId);
      else if (name === 'reader') await BV.reader.open(params.bookId);
      else if (name === 'settings') await BV.settingsScreen.render(params);
      else if (name === 'account') await BV.settingsScreen.renderAccount();
      else if (name === 'welcome') await BV.welcome.render();
      else if (name === 'community') await BV.community.render();
      else if (name === 'communityBook') await BV.community.openBook(params.id);
    } catch (e) {
      BV.error(e);
      if (name !== 'home') { current = null; BV.go('home'); }
    }
  };

  /* botão "voltar" do Android */
  window.bvBack = function () {
    if (BV.closeTopModal()) return true;
    if (current === 'editor' && BV.editorScreen.back()) return true;
    if (current === 'reader' && BV.reader.back()) return true;
    if (current === 'home' || current === 'welcome') return false;
    let target = PARENT[current] || 'home';
    if (current === 'editor') target = editorOrigin === 'library' ? 'library' : 'home';
    if (current === 'cover' || current === 'reader') BV.go('editor', { bookId: store.book && store.book.id });
    else BV.go(target);
    return true;
  };

  /* ---------- arranque ---------- */
  async function boot() {
    document.addEventListener('contextmenu', (e) => { if (!e.target.closest('[contenteditable],input,textarea,.selectable')) e.preventDefault(); });
    await store.loadSettings();
    BV.setLang(store.settings.language || 'pt');
    store.updateAutosaveDelay();
    BV.applyTheme();
    await store.loadUser();
    if (store.user && store.user.signedIn && store.settings.welcomeDone !== 'true') store.setSetting('welcomeDone', 'true');
    await BV.go(BV.welcome.needed() ? 'welcome' : 'home');
    // sincroniza ao abrir se existir sessão (não bloqueia a interface)
    BV.native('sync.status').then((st) => { if (st.signedIn && st.configured) BV.native('sync.now').then(() => BV.updateSyncDots && BV.updateSyncDots()).catch(() => {}); }).catch(() => {});
    window.addEventListener('online', () => { BV.native('sync.status').then((st) => { if (st.signedIn && st.configured) BV.native('sync.now').catch(() => {}); }).catch(() => {}); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
