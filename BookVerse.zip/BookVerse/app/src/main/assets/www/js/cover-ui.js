/* BookVerse — ecrã do editor de capas */
(function () {
  'use strict';
  const BV = window.BV, C = BV.cover, store = BV.store;
  const h = BV.h, icon = BV.icon, t = (s) => BV.t(s);
  const U = (BV.coverScreen = {});

  let book, which = 'front', sel = -1, tab = 'templates', els = {}, scale = 1, hist = {}, hi = {}, renderQueued = false, dirty = false;

  const designOf = (w) => book.doc.cover[w];
  const cur = () => designOf(which);

  U.open = async function (bookId) {
    book = store.book && store.book.id === bookId ? store.book : await store.open(bookId);
    which = 'front'; sel = -1; tab = 'templates'; hist = {}; hi = {}; dirty = false;
    const cv = book.doc.cover;
    if (!cv.front) {
      const size = C.size(book.doc.layout, 'front');
      cv.front = C.fromTemplate(C.templatesFor(book.category)[0], book, size);
    }
    ensure('back'); if (cv.spineEnabled) ensure('spine');
    build();
    pushHist(true);
    await BV.nextFrame();
    layoutStage(); draw();
  };

  /** Garante que contracapa/lombada existem e têm as dimensões corretas. */
  function ensure(w) {
    const cv = book.doc.cover, L = book.doc.layout;
    if (cv[w]) return;
    const size = C.size(L, w, cv.spineWidthMm);
    cv[w] = w === 'back' ? C.makeBack(cv.front, book) : C.makeSpine(cv.front, book, size.w, size.h);
    if (w === 'back') { cv.back.w = size.w; cv.back.h = size.h; }
  }

  /* ---------- estrutura ---------- */
  function build() {
    const s = BV.clear(BV.$('#screen-cover'));
    els = {};
    els.undo = h('button', { class: 'icon-btn', onclick: undo }, icon('undo'));
    els.redo = h('button', { class: 'icon-btn', onclick: redo }, icon('redo'));
    els.seg = h('div', { class: 'seg' });
    s.append(h('div', { class: 'topbar' },
      h('button', { class: 'icon-btn', onclick: () => BV.go('editor', { bookId: book.id }) }, icon('back')),
      h('h2', null, t('Capas')), els.undo, els.redo,
      h('button', { class: 'icon-btn', 'aria-label': 'Partilhar capa', onclick: shareMenu }, icon('share')),
      h('button', { class: 'icon-btn', 'aria-label': 'Mais', onclick: moreMenu }, icon('more'))),
      h('div', { class: 'cv-segwrap' }, els.seg),
      (els.stageWrap = h('div', { class: 'cv-stage-wrap' }, (els.stage = h('div', { class: 'cv-stage' }, (els.canvas = h('canvas', { class: 'cv-canvas' })), (els.overlay = h('div', { class: 'cv-overlay' })))))),
      (els.panel = h('div', { class: 'cv-panel glass' }, (els.ptabs = h('div', { class: 'tabs' })), (els.pbody = h('div', { class: 'cv-pbody' })))));
    renderSeg(); renderTabs(); renderPanel();
    els.overlay.addEventListener('pointerdown', onDown);
    window.addEventListener('resize', onResize);
  }
  const onResize = BV.debounce(() => { if (BV.$('#screen-cover.active')) { layoutStage(); syncFrame(); draw(); } }, 120);

  function renderSeg() {
    BV.clear(els.seg);
    [['front', 'Frente'], ['back', 'Contracapa']].concat(book.doc.cover.spineEnabled ? [['spine', 'Lombada']] : []).forEach(([k, l]) =>
      els.seg.appendChild(h('button', { class: which === k ? 'on' : '', onclick: () => switchTo(k) }, t(l))));
  }
  function switchTo(w) {
    which = w; sel = -1; ensure(w); if (!hist[w]) pushHist(true);
    renderSeg(); renderTabs(); renderPanel(); layoutStage(); syncFrame(); draw(); updateUndo();
  }

  function layoutStage() {
    const d = cur(); if (!d || !els.stageWrap) return;
    const r = els.stageWrap.getBoundingClientRect();
    const aw = Math.max(80, r.width - 24), ah = Math.max(80, r.height - 16);
    scale = Math.min(aw / d.w, ah / d.h);
    const W = Math.floor(d.w * scale), H = Math.floor(d.h * scale);
    els.stage.style.width = W + 'px'; els.stage.style.height = H + 'px';
  }
  function draw() {
    if (renderQueued) return;
    renderQueued = true;
    requestAnimationFrame(async () => {
      renderQueued = false;
      const d = cur(); if (!d) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      try { await C.render(d, els.canvas, { scale: Math.min(1, (d.w * scale * dpr) / d.w) }); } catch (e) { console.error(e); }
      els.canvas.style.width = '100%'; els.canvas.style.height = '100%';
    });
  }

  /* ---------- seleção e manipulação ---------- */
  function syncFrame() {
    BV.clear(els.overlay);
    const d = cur(); if (!d || sel < 0 || !d.els[sel]) return;
    const e = d.els[sel];
    const f = h('div', { class: 'cv-frame', style: { left: e.x * scale + 'px', top: e.y * scale + 'px', width: e.w * scale + 'px', height: e.h * scale + 'px', transform: 'rotate(' + (e.rot || 0) + 'deg)' } });
    [['nw', -1, -1], ['ne', 1, -1], ['sw', -1, 1], ['se', 1, 1]].forEach(([k, sx, sy]) => f.appendChild(h('i', { class: 'cv-h cv-h-' + k, 'data-h': k, 'data-sx': sx, 'data-sy': sy })));
    f.appendChild(h('i', { class: 'cv-h cv-rot', 'data-h': 'rot' }));
    els.overlay.appendChild(f);
  }
  const toDesign = (ev) => { const r = els.overlay.getBoundingClientRect(); return { x: (ev.clientX - r.left) / scale, y: (ev.clientY - r.top) / scale }; };

  function onDown(ev) {
    const d = cur(); if (!d) return;
    ev.preventDefault();
    els.overlay.setPointerCapture(ev.pointerId);
    const p0 = toDesign(ev);
    const handle = ev.target.getAttribute && ev.target.getAttribute('data-h');
    let mode = null, e = null;
    if (handle && sel >= 0) { mode = handle === 'rot' ? 'rot' : 'resize'; e = d.els[sel]; }
    else {
      const i = C.hit(d, p0.x, p0.y);
      if (i !== sel) { sel = i; renderTabs(); if (sel >= 0) tab = 'element'; else if (tab === 'element') tab = 'add'; renderTabs(); renderPanel(); }
      syncFrame();
      if (i < 0) return;
      mode = 'move'; e = d.els[i];
    }
    const start = { x: e.x, y: e.y, w: e.w, h: e.h, rot: e.rot || 0 };
    const hsx = handle ? +ev.target.getAttribute('data-sx') : 0, hsy = handle ? +ev.target.getAttribute('data-sy') : 0;
    const ctr = { x: start.x + start.w / 2, y: start.y + start.h / 2 };
    let moved = false;
    const move = (m) => {
      const p = toDesign(m); moved = true;
      if (mode === 'move') {
        let nx = start.x + (p.x - p0.x), ny = start.y + (p.y - p0.y);
        const cx = nx + e.w / 2, cy = ny + e.h / 2;
        if (Math.abs(cx - d.w / 2) < 12) nx = d.w / 2 - e.w / 2;
        if (Math.abs(cy - d.h / 2) < 12) ny = d.h / 2 - e.h / 2;
        e.x = nx; e.y = ny;
      } else if (mode === 'rot') {
        let a = Math.atan2(p.y - ctr.y, p.x - ctr.x) * 180 / Math.PI + 90;
        a = ((a % 360) + 540) % 360 - 180;
        for (const s of [0, 90, -90, 180, -180, 45, -45]) if (Math.abs(a - s) < 4) a = s;
        e.rot = Math.round(a * 10) / 10;
      } else {
        const a = start.rot * Math.PI / 180, cos = Math.cos(a), sin = Math.sin(a);
        const o = { x: ctr.x + (-hsx * start.w / 2) * cos - (-hsy * start.h / 2) * sin, y: ctr.y + (-hsx * start.w / 2) * sin + (-hsy * start.h / 2) * cos };
        const dx = p.x - o.x, dy = p.y - o.y;
        const lx = dx * cos + dy * sin, ly = -dx * sin + dy * cos;
        const nw = Math.max(24, Math.abs(lx)), nh = Math.max(24, Math.abs(ly));
        const nc = { x: (o.x + p.x) / 2, y: (o.y + p.y) / 2 };
        e.w = nw; e.h = nh; e.x = nc.x - nw / 2; e.y = nc.y - nh / 2;
      }
      syncFrame(); draw();
    };
    const up = () => {
      els.overlay.removeEventListener('pointermove', move); els.overlay.removeEventListener('pointerup', up); els.overlay.removeEventListener('pointercancel', up);
      if (moved) { changed(); if (tab === 'element') renderPanel(); }
    };
    els.overlay.addEventListener('pointermove', move); els.overlay.addEventListener('pointerup', up); els.overlay.addEventListener('pointercancel', up);
  }

  /* ---------- histórico ---------- */
  function pushHist(init) {
    const w = which, js = JSON.stringify(cur());
    hist[w] = hist[w] || []; hi[w] = hi[w] == null ? -1 : hi[w];
    if (init && hist[w].length) return;
    if (hist[w][hi[w]] === js) return;
    hist[w] = hist[w].slice(0, hi[w] + 1); hist[w].push(js); if (hist[w].length > 80) hist[w].shift(); hi[w] = hist[w].length - 1;
    updateUndo();
  }
  function changed() { pushHist(); dirty = true; store.touch(); }
  function undo() { const w = which; if (hi[w] > 0) { hi[w]--; book.doc.cover[w] = JSON.parse(hist[w][hi[w]]); sel = -1; afterHist(); } }
  function redo() { const w = which; if (hi[w] < hist[w].length - 1) { hi[w]++; book.doc.cover[w] = JSON.parse(hist[w][hi[w]]); sel = -1; afterHist(); } }
  function afterHist() { dirty = true; store.touch(); renderPanel(); syncFrame(); draw(); updateUndo(); }
  function updateUndo() { if (!els.undo) return; els.undo.style.opacity = hi[which] > 0 ? 1 : .4; els.redo.style.opacity = hist[which] && hi[which] < hist[which].length - 1 ? 1 : .4; }

  /* ---------- painel inferior ---------- */
  function renderTabs() {
    BV.clear(els.ptabs);
    const tabs = [['templates', 'Modelos'], ['add', 'Adicionar'], ['bg', 'Fundo'], ['fx', 'Efeitos'], ['layers', 'Camadas']];
    if (sel >= 0) tabs.unshift(['element', 'Elemento']);
    if (tab === 'element' && sel < 0) tab = 'add';
    tabs.forEach(([k, l]) => els.ptabs.appendChild(h('button', { class: 'tab' + (tab === k ? ' on' : ''), onclick: () => { tab = k; renderTabs(); renderPanel(); } }, t(l))));
  }
  function renderPanel() {
    BV.clear(els.pbody);
    ({ templates: panelTemplates, add: panelAdd, bg: panelBg, fx: panelFx, layers: panelLayers, element: panelElement }[tab] || panelAdd)();
  }

  const slider = (label, min, max, step, value, oninput, fmt) => {
    const out = h('span', { class: 'chip' }, fmt ? fmt(value) : value);
    const r = h('input', { type: 'range', min, max, step, value, oninput: () => { out.textContent = fmt ? fmt(+r.value) : r.value; oninput(+r.value); draw(); syncFrame(); }, onchange: () => changed() });
    return h('div', { class: 'ctl' }, h('label', null, label), h('div', { class: 'row', style: { alignItems: 'center' } }, r, out));
  };
  const color = (label, value, oninput) => {
    const i = h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(value) ? value : '#000000', oninput: () => { oninput(i.value); draw(); }, onchange: () => changed() });
    return h('div', { class: 'ctl inline' }, h('label', null, label), i);
  };
  const toggle = (label, value, on) => h('div', { class: 'ctl inline' }, h('label', null, label), BV.switchEl(value, (v) => { on(v); changed(); draw(); renderPanel(); }));
  const selectCtl = (label, opts, value, on) => h('div', { class: 'ctl' }, h('label', null, label), BV.select(opts, value, (v) => { on(v); changed(); draw(); renderPanel(); }));

  /* modelos */
  function panelTemplates() {
    const list = C.templatesFor(book.category);
    const head = which === 'front' ? null : h('div', { class: 'cv-note' }, h('p', null, which === 'spine' ? t('Escolha um modelo de lombada ou gere-a a partir da capa frontal.') : t('A contracapa e a lombada acompanham o estilo da capa frontal.')),
      h('button', { class: 'btn sm primary', onclick: regenFromFront }, icon('refresh', 'sm'), t('Gerar a partir da frente')));
    if (head) { els.pbody.appendChild(head); if (which === 'spine') els.pbody.appendChild(spineList()); return; }
    const grid = h('div', { class: 'tpl-grid' });
    const size = { w: cur().w, h: cur().h };
    list.forEach((tpl) => {
      const cv = h('canvas', { class: 'tpl-thumb' });
      const d = C.fromTemplate(tpl, book, size);
      C.render(d, cv, { scale: 180 / d.w });
      grid.appendChild(h('button', { class: 'tpl', onclick: () => applyTemplate(tpl) }, cv, h('span', null, tpl.name, h('small', null, tpl.category))));
    });
    els.pbody.append(h('div', { class: 'cv-note' }, h('button', { class: 'btn sm', onclick: blankCover }, icon('plus', 'sm'), t('Criar do zero')), h('button', { class: 'btn sm', onclick: () => fromBookCategory() }, icon('palette', 'sm'), t('Modelo da categoria'))), grid);
  }
  /** Modelos de lombada, mostrados deitados como numa estante. */
  function spineList() {
    const size = { w: cur().w, h: cur().h }, list = h('div', { class: 'sp-list' });
    C.SPINE_TEMPLATES.forEach((tpl) => {
      const row = h('button', { class: 'sp-row', onclick: () => applySpine(tpl) }, h('span', null, tpl.name));
      list.appendChild(row);
      (async () => {
        const d = tpl.make(book, size.w, size.h), tmp = document.createElement('canvas');
        await C.render(d, tmp, { scale: Math.min(1, 800 / d.h) });
        const out = document.createElement('canvas'); out.width = tmp.height; out.height = tmp.width; out.className = 'sp-thumb';
        const x = out.getContext('2d'); x.translate(0, tmp.width); x.rotate(-Math.PI / 2); x.drawImage(tmp, 0, 0);
        row.prepend(out);
      })().catch(() => {});
    });
    return h('div', null, h('div', { class: 'grp-t' }, t('Modelos de lombada')), list);
  }
  async function applySpine(tpl) {
    if (cur().els.length > 3 && !(await BV.confirm(t('Substituir o design atual da lombada por este modelo?')))) return;
    book.doc.cover.spine = tpl.make(book, cur().w, cur().h); sel = -1; changed(); renderPanel(); syncFrame(); draw();
    BV.toast(t('Lombada atualizada'), 'ok');
  }
  async function applyTemplate(tpl) {
    if (cur().els.length > 6 && !(await BV.confirm(t('Substituir o design atual por este modelo?')))) return;
    const size = { w: cur().w, h: cur().h };
    book.doc.cover.front = C.fromTemplate(tpl, book, size); sel = -1; changed(); renderPanel(); syncFrame(); draw();
  }
  function fromBookCategory() { applyTemplate(C.templatesFor(book.category)[0]); }
  async function blankCover() {
    if (!(await BV.confirm(t('Começar uma capa nova do zero? O design atual será substituído.')))) return;
    const d = C.newDesign(cur().w, cur().h); book.doc.cover[which] = d; sel = -1; changed(); renderPanel(); syncFrame(); draw();
  }
  function regenFromFront() {
    const cv = book.doc.cover, L = book.doc.layout;
    const size = C.size(L, which, cv.spineWidthMm);
    cv[which] = which === 'back' ? C.makeBack(cv.front, book) : C.makeSpine(cv.front, book, size.w, size.h);
    if (which === 'back') { cv.back.w = size.w; cv.back.h = size.h; }
    sel = -1; changed(); layoutStage(); syncFrame(); draw(); BV.toast(t('Design gerado'), 'ok');
  }

  /* imagem de capa com recorte */
  /** Janela de recorte: arrastar para mover, pinça/slider para ampliar. Devolve {zoom,ox,oy} ou null. */
  function cropDialog(o) {
    return new Promise(async (resolve) => {
      const im = await C.loadImage(o.url);
      if (!im) { BV.toast(t('Não foi possível abrir a imagem'), 'error'); return resolve(null); }
      const st = { zoom: o.zoom || 1, ox: o.ox == null ? 0.5 : o.ox, oy: o.oy == null ? 0.5 : o.oy };
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const maxW = Math.min(window.innerWidth - 72, 420), maxH = Math.max(160, Math.min(window.innerHeight * 0.5, 520));
      let fw = maxW, fh = fw / o.aspect; if (fh > maxH) { fh = maxH; fw = fh * o.aspect; }
      fw = Math.round(fw); fh = Math.round(fh);
      const cv = h('canvas', { width: Math.round(fw * dpr), height: Math.round(fh * dpr), style: { width: fw + 'px', height: fh + 'px', display: 'block' } });
      const ctx = cv.getContext('2d');
      const zr = h('input', { type: 'range', min: 1, max: 4, step: 0.01, value: st.zoom });
      const paint = () => {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#111'; ctx.fillRect(0, 0, fw, fh);
        const r = C.coverRect(im.width, im.height, fw, fh, st.zoom, st.ox, st.oy); ctx.drawImage(im, r.x, r.y, r.w, r.h);
      };
      const frame = h('div', { class: 'crop-frame', style: { width: fw + 'px', height: fh + 'px' } }, cv);
      const pts = new Map(); let pinch0 = 0, zoom0 = 1;
      frame.addEventListener('pointerdown', (ev) => { frame.setPointerCapture(ev.pointerId); pts.set(ev.pointerId, { x: ev.clientX, y: ev.clientY }); if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch0 = Math.hypot(a.x - b.x, a.y - b.y); zoom0 = st.zoom; } });
      frame.addEventListener('pointermove', (ev) => {
        const p = pts.get(ev.pointerId); if (!p) return;
        if (pts.size === 1) {
          const r = C.coverRect(im.width, im.height, fw, fh, st.zoom, st.ox, st.oy);
          const rx = r.w - fw, ry = r.h - fh, dx = ev.clientX - p.x, dy = ev.clientY - p.y;
          if (rx > 1) st.ox = Math.min(1, Math.max(0, st.ox - dx / rx));
          if (ry > 1) st.oy = Math.min(1, Math.max(0, st.oy - dy / ry));
        }
        p.x = ev.clientX; p.y = ev.clientY;
        if (pts.size === 2 && pinch0 > 0) { const [a, b] = [...pts.values()]; st.zoom = Math.min(4, Math.max(1, zoom0 * Math.hypot(a.x - b.x, a.y - b.y) / pinch0)); zr.value = st.zoom; }
        paint();
      });
      const end = (ev) => { pts.delete(ev.pointerId); };
      frame.addEventListener('pointerup', end); frame.addEventListener('pointercancel', end);
      frame.addEventListener('wheel', (ev) => { ev.preventDefault(); st.zoom = Math.min(4, Math.max(1, st.zoom - ev.deltaY * 0.002)); zr.value = st.zoom; paint(); }, { passive: false });
      zr.addEventListener('input', () => { st.zoom = +zr.value; paint(); });
      paint();
      BV.modal({
        title: o.title || t('Ajustar imagem'), persistent: true,
        body: h('div', { class: 'crop-wrap' }, frame, h('p', { class: 'crop-hint' }, t('Arraste para mover · pince ou use o controlo para ampliar')),
          h('div', { class: 'ctl' }, h('label', null, t('Ampliação')), zr)),
        actions: [
          { label: t('Cancelar'), value: null },
          { label: t('Centrar'), keepOpen: true, onClick: () => { st.zoom = 1; st.ox = 0.5; st.oy = 0.5; zr.value = 1; paint(); return false; } },
          { label: t('Aplicar'), primary: true, value: 'ok' }],
        onClose: (v) => resolve(v === 'ok' ? { zoom: Math.round(st.zoom * 100) / 100, ox: Math.round(st.ox * 1000) / 1000, oy: Math.round(st.oy * 1000) / 1000 } : null)
      });
    });
  }

  /** Escolhe uma imagem e usa-a como capa inteira (preenche e recorta), mantendo o texto por cima. */
  async function useAsCover(camera) {
    try {
      const r = await BV.native('media.pick', { bookId: book.id, camera });
      if (r.cancelled) return;
      const d = cur();
      const crop = await cropDialog({ url: r.url, aspect: d.w / d.h, title: t('Ajustar a imagem à capa') });
      if (!crop) return;
      d.bg = { type: 'image', url: r.url, color: '#111111', overlay: '#000000', overlayAlpha: 0.22, zoom: crop.zoom, ox: crop.ox, oy: crop.oy };
      d.els.forEach((e) => {
        if (e.type === 'shape') e.hidden = true;
        else if (e.type === 'text') { if (C.isDark(e.color)) e.color = '#ffffff'; e.shadow = true; }
      });
      sel = -1; changed(); renderTabs(); renderPanel(); syncFrame(); draw();
      BV.toast(t('Capa atualizada'), 'ok');
    } catch (e) { BV.error(e); }
  }
  async function recropBg() {
    const d = cur(), bg = d.bg; if (!bg || bg.type !== 'image' || !bg.url) return;
    const crop = await cropDialog({ url: bg.url, aspect: d.w / d.h, zoom: bg.zoom, ox: bg.ox, oy: bg.oy, title: t('Ajustar recorte') });
    if (!crop) return;
    bg.zoom = crop.zoom; bg.ox = crop.ox; bg.oy = crop.oy; changed(); renderPanel(); draw();
  }
  async function recropElement(e) {
    const crop = await cropDialog({ url: e.url, aspect: e.w / e.h, zoom: e.zoom, ox: e.ox, oy: e.oy, title: t('Ajustar recorte') });
    if (!crop) return;
    e.fit = 'cover'; e.zoom = crop.zoom; e.ox = crop.ox; e.oy = crop.oy; changed(); renderPanel(); draw();
  }

  /* adicionar */
  function addEl(e) { const d = cur(); d.els.push(e); sel = d.els.length - 1; tab = 'element'; changed(); renderTabs(); renderPanel(); syncFrame(); draw(); }
  function panelAdd() {
    const d = cur();
    const cx = (w) => (d.w - w) / 2;
    const tb = (label, fn) => h('button', { class: 'btn sm', onclick: fn }, label);
    const shapes = [['rect', 'Retângulo'], ['round', 'Arredondado'], ['circle', 'Círculo'], ['triangle', 'Triângulo'], ['diamond', 'Losango'], ['star', 'Estrela'], ['line', 'Linha'], ['ring', 'Anel']];
    els.pbody.append(
      h('div', { class: 'grp-t' }, t('Texto')),
      h('div', { class: 'btn-grid' },
        tb(t('Título'), () => addEl(C.newText({ role: 'title', x: cx(d.w * 0.8), y: d.h * 0.3, w: d.w * 0.8, h: d.h * 0.2, text: book.title, size: Math.round(d.w * 0.11), bold: true }))),
        tb(t('Subtítulo'), () => addEl(C.newText({ role: 'subtitle', x: cx(d.w * 0.7), y: d.h * 0.52, w: d.w * 0.7, h: d.h * 0.08, text: book.subtitle || 'Subtítulo', size: Math.round(d.w * 0.045), italic: true }))),
        tb(t('Autor'), () => addEl(C.newText({ role: 'author', x: cx(d.w * 0.8), y: d.h * 0.86, w: d.w * 0.8, h: d.h * 0.07, text: book.author || 'Nome do autor', size: Math.round(d.w * 0.05), upper: true, spacing: 5, bold: true, font: 'sans-serif' }))),
        tb(t('Texto livre'), () => addEl(C.newText({ x: cx(d.w * 0.6), y: d.h * 0.45, w: d.w * 0.6, h: d.h * 0.1, text: 'Texto', size: Math.round(d.w * 0.06) })))),
      h('div', { class: 'grp-t' }, t('Formas geométricas')),
      h('div', { class: 'btn-grid' }, shapes.map(([k, l]) => tb(t(l), () => { const s = Math.round(d.w * 0.4); addEl(C.newShape({ shape: k, x: cx(s), y: (d.h - s) / 2, w: k === 'line' ? Math.round(d.w * 0.6) : s, h: k === 'line' ? 24 : s, fill: '#3b82f6', strokeW: k === 'ring' ? 10 : 6 })); }))),
      h('div', { class: 'grp-t' }, t('Imagens')),
      h('div', { class: 'btn-grid' }, tb('📷 ' + t('Fotografia'), () => addImage(true)), tb('🖼 ' + t('Galeria'), () => addImage(false))));
  }
  async function addImage(camera, replaceIdx) {
    try {
      const r = await BV.native('media.pick', { bookId: book.id, camera });
      if (r.cancelled) return;
      const d = cur();
      if (replaceIdx != null) { d.els[replaceIdx].url = r.url; changed(); draw(); renderPanel(); return; }
      const w = Math.round(d.w * 0.8), ratio = r.height / r.width, hh = Math.round(Math.min(d.h * 0.7, w * ratio));
      addEl(C.newImage({ url: r.url, x: (d.w - w) / 2, y: (d.h - hh) / 2, w, h: hh }));
    } catch (e) { BV.error(e); }
  }

  /* fundo */
  function panelBg() {
    const d = cur(), bg = d.bg;
    const setType = (ty) => {
      if (ty === bg.type) return;
      if (ty === 'solid') d.bg = { type: 'solid', color: bg.color || bg.from || '#0b1226' };
      else if (ty === 'gradient') d.bg = { type: 'gradient', from: bg.color || bg.from || '#1d4ed8', to: bg.to || '#0b1226', angle: 160 };
      else d.bg = { type: 'image', url: bg.url || '', color: '#111111', overlay: '#000000', overlayAlpha: 0.3 };
      changed(); draw(); renderPanel();
    };
    els.pbody.append(h('div', { class: 'seg' }, [['solid', 'Cor'], ['gradient', 'Degradê'], ['image', 'Imagem']].map(([k, l]) => h('button', { class: bg.type === k ? 'on' : '', onclick: () => setType(k) }, t(l)))));
    if (bg.type === 'solid') els.pbody.append(color(t('Cor de fundo'), bg.color, (v) => (d.bg.color = v)));
    if (bg.type === 'gradient') els.pbody.append(color(t('Cor inicial'), bg.from, (v) => (d.bg.from = v)), color(t('Cor final'), bg.to, (v) => (d.bg.to = v)), slider(t('Ângulo'), 0, 360, 5, bg.angle == null ? 160 : bg.angle, (v) => (d.bg.angle = v), (v) => v + '°'));
    if (bg.type === 'image') els.pbody.append(
      h('div', { class: 'btn-grid' }, h('button', { class: 'btn sm', onclick: () => pickBg(false) }, '🖼 ' + t('Galeria')), h('button', { class: 'btn sm', onclick: () => pickBg(true) }, '📷 ' + t('Fotografia')), bg.url ? h('button', { class: 'btn sm', onclick: () => recropBg() }, '✂️ ' + t('Ajustar recorte')) : null),
      color(t('Cor de sobreposição'), bg.overlay || '#000000', (v) => (d.bg.overlay = v)), slider(t('Opacidade da sobreposição'), 0, 0.9, 0.05, bg.overlayAlpha == null ? 0.3 : bg.overlayAlpha, (v) => (d.bg.overlayAlpha = v), (v) => Math.round(v * 100) + '%'));
  }
  async function pickBg(camera) {
    try {
      const r = await BV.native('media.pick', { bookId: book.id, camera }); if (r.cancelled) return;
      const d = cur();
      const crop = await cropDialog({ url: r.url, aspect: d.w / d.h, title: t('Ajustar a imagem à capa') });
      if (!crop) return;
      d.bg.url = r.url; d.bg.zoom = crop.zoom; d.bg.ox = crop.ox; d.bg.oy = crop.oy; changed(); draw(); renderPanel();
    } catch (e) { BV.error(e); }
  }

  /* efeitos */
  function panelFx() {
    const d = cur(), fx = d.fx = d.fx || {};
    els.pbody.append(
      slider(t('Vinheta'), 0, 0.95, 0.05, fx.vignette || 0, (v) => (fx.vignette = v), (v) => Math.round(v * 100) + '%'),
      color(t('Cor de filtro'), fx.tint || '#3b82f6', (v) => { fx.tint = v; if (!fx.tintAlpha) fx.tintAlpha = 0.2; }),
      slider(t('Intensidade do filtro'), 0, 0.8, 0.05, fx.tintAlpha || 0, (v) => (fx.tintAlpha = v), (v) => Math.round(v * 100) + '%'));
    if (d.bg.type === 'image') els.pbody.append(slider(t('Desfoque do fundo'), 0, 30, 1, fx.blur || 0, (v) => (fx.blur = v), (v) => v + ' px'), toggle(t('Fundo a preto e branco'), !!fx.gray, (v) => (fx.gray = v)));
  }

  /* camadas */
  function panelLayers() {
    const d = cur();
    if (!d.els.length) { els.pbody.append(h('div', { class: 'empty' }, t('Ainda não há elementos. Use "Adicionar".'))); return; }
    const list = h('div', { class: 'layer-list' });
    for (let i = d.els.length - 1; i >= 0; i--) {
      const e = d.els[i], idx = i;
      const name = e.type === 'text' ? '“' + String(e.text).slice(0, 24) + '”' : e.type === 'shape' ? t('Forma') + ' · ' + e.shape : t('Imagem');
      list.appendChild(h('div', { class: 'layer' + (sel === idx ? ' on' : '') },
        h('button', { class: 'layer-name', onclick: () => { sel = idx; tab = 'element'; renderTabs(); renderPanel(); syncFrame(); } }, icon(e.type === 'text' ? 'text' : e.type === 'image' ? 'image' : 'shape', 'sm'), name),
        h('button', { class: 'icon-btn sm', onclick: () => { e.hidden = !e.hidden; changed(); draw(); renderPanel(); } }, icon('eye')),
        h('button', { class: 'icon-btn sm', onclick: () => moveLayer(idx, 1) }, icon('up')), h('button', { class: 'icon-btn sm', onclick: () => moveLayer(idx, -1) }, icon('down'))));
    }
    els.pbody.append(list);
  }
  function moveLayer(i, dir) {
    const d = cur(), j = i + dir; if (j < 0 || j >= d.els.length) return;
    [d.els[i], d.els[j]] = [d.els[j], d.els[i]]; if (sel === i) sel = j; else if (sel === j) sel = i;
    changed(); renderPanel(); syncFrame(); draw();
  }

  /* propriedades do elemento */
  function panelElement() {
    const d = cur(), e = d.els[sel]; if (!e) return;
    const P = els.pbody;
    if (e.type === 'text') {
      const ta = h('textarea', { class: 'input', rows: 2, oninput: () => { e.text = ta.value; draw(); }, onchange: () => changed() }, e.text);
      P.append(h('div', { class: 'ctl' }, h('label', null, t('Texto')), ta),
        h('div', { class: 'ctl' }, h('label', null, t('Tipo de letra')), BV.select(BV.model.FONTS, e.font, (v) => { e.font = v; changed(); draw(); })),
        slider(t('Tamanho'), 10, 400, 1, e.size, (v) => (e.size = v), (v) => v + ' px'),
        color(t('Cor do texto'), e.color, (v) => (e.color = v)),
        h('div', { class: 'btn-grid' },
          h('button', { class: 'btn sm' + (e.bold ? ' primary' : ''), onclick: () => { e.bold = !e.bold; changed(); draw(); renderPanel(); } }, icon('bold', 'sm')),
          h('button', { class: 'btn sm' + (e.italic ? ' primary' : ''), onclick: () => { e.italic = !e.italic; changed(); draw(); renderPanel(); } }, icon('italic', 'sm')),
          h('button', { class: 'btn sm' + (e.upper ? ' primary' : ''), onclick: () => { e.upper = !e.upper; changed(); draw(); renderPanel(); } }, 'Aa'),
          ['left', 'center', 'right'].map((a) => h('button', { class: 'btn sm' + (e.align === a ? ' primary' : ''), onclick: () => { e.align = a; changed(); draw(); renderPanel(); } }, icon({ left: 'alignL', center: 'alignC', right: 'alignR' }[a], 'sm')))),
        selectCtl(t('Alinhamento vertical'), [['top', 'Topo'], ['middle', 'Centro'], ['bottom', 'Base']], e.valign || 'middle', (v) => (e.valign = v)),
        slider(t('Espaçamento entre letras'), 0, 30, 1, e.spacing || 0, (v) => (e.spacing = v)), slider(t('Entrelinha'), 0.8, 2.2, 0.05, e.lineH || 1.15, (v) => (e.lineH = v)),
        toggle(t('Sombra'), !!e.shadow, (v) => (e.shadow = v)), toggle(t('Contorno'), !!e.outline, (v) => (e.outline = v)),
        e.outline ? color(t('Cor do contorno'), e.outlineColor || '#000000', (v) => (e.outlineColor = v)) : null);
    } else if (e.type === 'shape') {
      P.append(selectCtl(t('Forma'), [['rect', 'Retângulo'], ['round', 'Arredondado'], ['circle', 'Círculo'], ['triangle', 'Triângulo'], ['diamond', 'Losango'], ['star', 'Estrela'], ['line', 'Linha'], ['ring', 'Anel']], e.shape, (v) => (e.shape = v)),
        color(t('Cor de preenchimento'), e.fill && e.fill.startsWith('#') ? e.fill : '#3b82f6', (v) => (e.fill = v)),
        toggle(t('Degradê'), !!e.fill2, (v) => { e.fill2 = v ? '#0b1226' : ''; }),
        e.fill2 ? color(t('Cor final do degradê'), e.fill2, (v) => (e.fill2 = v)) : null,
        e.shape === 'rect' ? slider(t('Cantos'), 0, 300, 2, e.radius || 0, (v) => (e.radius = v)) : null,
        color(t('Cor do contorno'), e.stroke && e.stroke.startsWith('#') ? e.stroke : '#ffffff', (v) => { e.stroke = v; }), slider(t('Espessura do contorno'), 0, 40, 1, e.stroke ? e.strokeW || 4 : 0, (v) => { e.strokeW = v; if (!v) e.stroke = ''; else if (!e.stroke) e.stroke = '#ffffff'; }));
    } else {
      P.append(h('div', { class: 'btn-grid' }, h('button', { class: 'btn sm', onclick: () => addImage(false, sel) }, '🖼 ' + t('Trocar imagem')), h('button', { class: 'btn sm', onclick: () => addImage(true, sel) }, '📷 ' + t('Nova foto'))),
        e.fit !== 'contain' ? h('div', { class: 'btn-grid' }, h('button', { class: 'btn sm', onclick: () => recropElement(e) }, '✂️ ' + t('Recortar / ajustar'))) : null,
        selectCtl(t('Ajuste'), [['cover', 'Preencher'], ['contain', 'Conter']], e.fit, (v) => (e.fit = v)),
        selectCtl(t('Filtro'), [['none', 'Nenhum'], ['grayscale', 'Preto e branco'], ['bw', 'Alto contraste'], ['sepia', 'Sépia'], ['blur', 'Desfocado']], e.filter, (v) => (e.filter = v)),
        slider(t('Cantos'), 0, 600, 5, e.radius || 0, (v) => (e.radius = v)), slider(t('Moldura'), 0, 40, 1, e.border || 0, (v) => (e.border = v)));
    }
    P.append(slider(t('Opacidade'), 0.05, 1, 0.05, e.opacity == null ? 1 : e.opacity, (v) => (e.opacity = v), (v) => Math.round(v * 100) + '%'),
      slider(t('Rotação'), -180, 180, 1, e.rot || 0, (v) => (e.rot = v), (v) => v + '°'),
      h('div', { class: 'btn-grid' },
        h('button', { class: 'btn sm', onclick: () => { e.x = (d.w - e.w) / 2; changed(); draw(); syncFrame(); } }, t('Centrar H')),
        h('button', { class: 'btn sm', onclick: () => { e.y = (d.h - e.h) / 2; changed(); draw(); syncFrame(); } }, t('Centrar V')),
        h('button', { class: 'btn sm', onclick: () => { const c = JSON.parse(JSON.stringify(e)); c.id = BV.shortId(); c.x += 30; c.y += 30; d.els.push(c); sel = d.els.length - 1; changed(); renderPanel(); syncFrame(); draw(); } }, icon('duplicate', 'sm'), t('Duplicar')),
        h('button', { class: 'btn sm danger', onclick: () => { d.els.splice(sel, 1); sel = -1; tab = 'add'; changed(); renderTabs(); renderPanel(); syncFrame(); draw(); } }, icon('trash', 'sm'), t('Eliminar'))));
  }

  /* ---------- menus, guardar e partilhar ---------- */
  function moreMenu() {
    const cv = book.doc.cover;
    BV.menu(t('Capas'), [
      { icon: 'layers', label: cv.spineEnabled ? t('Remover lombada') : t('Adicionar lombada'), sub: t('Para livros impressos'), onClick: async () => {
        if (cv.spineEnabled) { cv.spineEnabled = false; if (which === 'spine') which = 'front'; }
        else {
          const v = await BV.prompt(t('Largura da lombada (mm)'), String(cv.spineWidthMm || 12), { type: 'number' }); const n = parseFloat(v); if (!(n >= 3 && n <= 80)) return;
          cv.spineWidthMm = n; cv.spineEnabled = true; cv.spine = null; ensure('spine'); which = 'spine'; sel = -1; hist.spine = null; pushHist(true);
        }
        dirty = true; store.touch(); renderSeg(); renderTabs(); renderPanel(); layoutStage(); syncFrame(); draw(); } },
      { icon: 'trash', label: t('Repor design desta capa'), danger: true, onClick: () => regenOrReset() }
    ]);
  }
  async function regenOrReset() {
    if (!(await BV.confirm(t('Repor o design desta capa? As alterações serão perdidas.'), { danger: true }))) return;
    if (which === 'front') fromBookCategoryForce(); else regenFromFront();
  }
  function fromBookCategoryForce() { const size = { w: cur().w, h: cur().h }; book.doc.cover.front = C.fromTemplate(C.templatesFor(book.category)[0], book, size); sel = -1; changed(); renderPanel(); syncFrame(); draw(); }

  function shareMenu() {
    const items = [{ icon: 'image', label: t('Partilhar capa frontal'), onClick: () => shareCover('front') }, { icon: 'image', label: t('Partilhar contracapa'), onClick: () => shareCover('back') }];
    if (book.doc.cover.spineEnabled) items.push({ icon: 'image', label: t('Partilhar lombada'), onClick: () => shareCover('spine') });
    items.push({ icon: 'download', label: t('Guardar capa frontal no dispositivo'), onClick: () => saveCover('front') });
    BV.menu(t('Capa como imagem'), items);
  }
  async function coverFile(w) {
    const d = book.doc.cover[w]; const dataUrl = await C.toDataUrl(d, 'image/png', 1, Math.min(2000, d.w));
    return BV.native('export.saveImage', { bookId: book.id, dataUrl, name: (book.title || 'livro') + '_' + { front: 'capa', back: 'contracapa', spine: 'lombada' }[w] });
  }
  async function shareCover(w) {
    const b = BV.busy(t('A preparar imagem…'));
    try { const f = await coverFile(w); b.done(); await BV.native('export.share', { path: f.path, mime: f.mime, subject: book.title }); } catch (e) { b.done(); BV.error(e); }
  }
  async function saveCover(w) {
    const b = BV.busy(t('A preparar imagem…'));
    try { const f = await coverFile(w); b.done(); const r = await BV.native('export.saveToDevice', { path: f.path, mime: f.mime }); if (!r.cancelled) BV.toast(t('Guardado no dispositivo'), 'ok'); } catch (e) { b.done(); BV.error(e); }
  }

  /** Renderiza as capas para ficheiros do livro (usados nos cartões, sincronização e backup). */
  U.persistFiles = async function () {
    const cv = book.doc.cover;
    const save = async (w, front) => {
      const d = cv[w]; if (!d) return;
      const dataUrl = await C.toDataUrl(d, 'image/jpeg', 0.9, Math.min(1000, d.w));
      await BV.native('media.saveDataUrl', { bookId: book.id, dataUrl, name: 'cover_' + w + '.jpg', isFrontCover: front });
    };
    await save('front', true); await save('back', false); if (cv.spineEnabled) await save('spine', false);
  };

  U.leave = async function () {
    window.removeEventListener('resize', onResize);
    if (dirty) {
      const b = BV.busy(t('A guardar capas…'));
      try { await U.persistFiles(); await store.saveNow(); } catch (e) { BV.error(e); }
      b.done();
    }
    dirty = false;
  };

  /** Imagens das capas para pré-visualização/exportação (data URLs JPEG). */
  BV.coverImages = async function (bk, widthPx) {
    const out = { front: null, back: null };
    const cv = bk.doc.cover, L = bk.doc.layout;
    const size = C.size(L, 'front');
    const front = cv.front || C.fromTemplate(C.templatesFor(bk.category)[0], bk, size);
    out.front = await C.toDataUrl(front, 'image/jpeg', 0.92, widthPx || 1000);
    const back = cv.back || C.makeBack(front, bk);
    back.w = size.w; back.h = size.h;
    out.back = await C.toDataUrl(back, 'image/jpeg', 0.92, widthPx || 1000);
    return out;
  };
})();
