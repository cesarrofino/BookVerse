/* BookVerse — motor de paginação. Fonte única de verdade para pré-visualização e PDF. */
(function () {
  'use strict';
  const BV = window.BV;
  const MM = BV.model.MM;
  const cache = new Map();     // chave de secção -> { pages:[html], anchors:{anchor:idx} }

  function hash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return h + ':' + s.length; }

  /** CSS das páginas — injetado no leitor e enviado ao exportador de PDF. */
  BV.pageCss = function (layout) {
    const ff = layout.fontFamily || 'serif';
    const p = layout.paraSpacingPt;
    return `
.bv-page{position:relative;background:#fff;color:#141414;font-family:${ff};font-size:${layout.fontSizePt}pt;line-height:${layout.lineHeight};overflow:hidden;box-sizing:border-box;-webkit-font-smoothing:antialiased}
.bv-page *{box-sizing:border-box}
.bv-body{position:absolute;overflow:hidden;word-wrap:break-word;overflow-wrap:break-word;hyphens:auto;-webkit-hyphens:auto}
.bv-body p{margin:0 0 ${p}pt;orphans:2;widows:2;text-indent:${layout.firstLineIndentMm || 0}mm}
.bv-body p.cont{text-indent:0}
.bv-body h1.chap-title{font-size:1.9em;line-height:1.2;margin:1.4em 0 1em;text-align:center;font-weight:700}
.bv-body h1{font-size:1.9em;line-height:1.2;margin:1em 0 .7em}
.bv-body h2{font-size:1.45em;line-height:1.25;margin:1.1em 0 .5em;font-weight:700}
.bv-body h3{font-size:1.2em;line-height:1.3;margin:1em 0 .4em;font-weight:700}
.bv-body blockquote{margin:1em 1.6em;padding-left:1em;border-left:3px solid #8a8a8a;font-style:italic}
.bv-body ul,.bv-body ol{margin:0 0 ${p}pt;padding-left:1.6em}
.bv-body li{margin:0 0 .25em}
.bv-body img{display:block;max-width:100%;max-height:var(--bvh);height:auto;object-fit:contain;margin:.7em auto}
.bv-body table{border-collapse:collapse;width:100%;margin:1em 0}
.bv-body td,.bv-body th{border:1px solid #999;padding:.3em .5em;vertical-align:top}
.bv-body th{background:#eee}
.bv-body hr{border:0;border-top:1px solid #999;margin:1.6em 20%}
.bv-body hr.orn{border:0;text-align:center;height:auto;margin:1.4em 0}
.bv-body hr.orn::after{content:"\\2217  \\2217  \\2217";letter-spacing:.4em;color:#666}
.bv-body a{color:#1d4ed8;text-decoration:underline}
.bv-body .front-title{height:var(--bvh);display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}
.bv-body .ft-spacer{flex:1}
.bv-body .ft-title{font-size:2.4em;line-height:1.15;margin:0 0 .3em;text-align:center}
.bv-body .ft-sub{font-size:1.2em;font-style:italic;margin:0 0 1em;text-indent:0}
.bv-body .ft-rule{width:3.5em;border-top:2px solid #444;margin:1.2em 0}
.bv-body .ft-author{font-size:1.3em;letter-spacing:.06em;text-transform:uppercase;text-indent:0}
.bv-body .ft-pub{font-size:.85em;color:#555;text-indent:0}
.bv-body .front-copyright{height:var(--bvh);display:flex;flex-direction:column;justify-content:flex-end;font-size:.82em;color:#333}
.bv-body .front-copyright p{text-indent:0;margin:0 0 .5em}
.bv-body .front-dedication{height:var(--bvh);display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;font-style:italic;font-size:1.1em}
.bv-body .front-dedication p{text-indent:0}
.bv-body .toc-row{display:flex;align-items:baseline;gap:.5em;margin:0 0 .45em}
.bv-body .toc-row.l1{font-weight:600;margin-top:.7em}
.bv-body .toc-row.l2{padding-left:1.2em}.bv-body .toc-row.l3{padding-left:2.4em;font-size:.92em}
.bv-body .toc-t{flex:none;max-width:84%}
.bv-body .toc-dots{flex:1;border-bottom:1.5px dotted #888;transform:translateY(-.25em);min-width:1em}
.bv-body .toc-n{flex:none;font-variant-numeric:tabular-nums}
.bv-hdr,.bv-ftr{position:absolute;text-align:center;font-size:.72em;color:#555;letter-spacing:.03em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bv-cover{display:block;width:100%;height:100%;object-fit:fill}
.bv-page.is-cover{background:#111}
`;
  };

  function geometry(layout) {
    const pg = BV.model.pageMm(layout), m = layout.margins;
    const bodyW = pg.w - m.inner - m.outer;
    const bodyH = pg.h - m.top - m.bottom;
    return { pageW: pg.w, pageH: pg.h, bodyW, bodyH, m };
  }

  /* ---------- clonagem parcial de um bloco por intervalo de caracteres ---------- */
  function cloneRange(node, start, end, st) {
    if (node.nodeType === 3) {
      const len = node.nodeValue.length, from = Math.max(0, start - st.pos), to = Math.min(len, end - st.pos);
      st.pos += len;
      if (to <= from) return null;
      return document.createTextNode(node.nodeValue.slice(from, to));
    }
    if (node.nodeType !== 1) return null;
    const tag = node.tagName;
    if (tag === 'BR' || tag === 'IMG') {
      const inside = st.pos >= start && st.pos < end;
      return inside ? node.cloneNode(true) : null;
    }
    const copy = node.cloneNode(false);
    let any = false;
    for (const c of Array.from(node.childNodes)) {
      const r = cloneRange(c, start, end, st);
      if (r) { copy.appendChild(r); any = true; }
    }
    return any ? copy : null;
  }
  const textLen = (el) => el.textContent.length;

  /** Divide um bloco de texto para que o início caiba em `holder`. Devolve {first, rest} (first pode ser null). */
  function splitInline(block, holder, fits) {
    const total = textLen(block);
    if (total < 2) return { first: null, rest: block };
    const test = (n) => {
      const head = cloneRange(block, 0, n, { pos: 0 });
      if (!head) return null;
      holder.appendChild(head);
      const ok = fits();
      holder.removeChild(head);
      return ok ? head : null;
    };
    let lo = 0, hi = total - 1, best = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (test(mid)) { best = mid; lo = mid + 1; } else hi = mid - 1;
    }
    if (best <= 0) return { first: null, rest: block };
    const text = block.textContent;
    let n = best;
    if (text[n] !== ' ' && text[n] !== '\n') {
      const p = text.lastIndexOf(' ', n - 1);
      if (p > 0) n = p;
    }
    // evita deixar uma única palavra órfã
    if (n < 8) return { first: null, rest: block };
    const first = cloneRange(block, 0, n, { pos: 0 });
    let restStart = n;
    while (restStart < total && /\s/.test(text[restStart])) restStart++;
    const rest = restStart >= total ? null : cloneRange(block, restStart, total, { pos: 0 });
    if (rest && rest.tagName === 'P') rest.classList.add('cont');
    return { first, rest };
  }

  function splitList(list, box, fits) {
    const items = Array.from(list.children).filter((c) => c.tagName === 'LI');
    const first = list.cloneNode(false);
    box.appendChild(first);
    let k = 0;
    for (; k < items.length; k++) {
      const li = items[k].cloneNode(true);
      first.appendChild(li);
      if (!fits()) { first.removeChild(li); break; }
    }
    let partialRest = null;
    if (k < items.length && !items[k].querySelector('ul,ol')) {
      const sp = splitInline(items[k], first, fits);
      if (sp.first) { first.appendChild(sp.first); partialRest = sp.rest; if (partialRest) partialRest.style.listStyleType = 'none'; k++; }
    }
    box.removeChild(first);
    if (!first.children.length) return { first: null, rest: list };
    const remaining = items.slice(k);
    if (partialRest) remaining.unshift(partialRest);
    if (!remaining.length) return { first, rest: null };
    const rest = list.cloneNode(false);
    if (list.tagName === 'OL') rest.setAttribute('start', String((parseInt(list.getAttribute('start') || '1', 10)) + k - (partialRest ? 1 : 0)));
    remaining.forEach((li) => rest.appendChild(li));
    return { first, rest };
  }

  function splitTable(table, box, fits) {
    const rows = Array.from(table.rows);
    const first = table.cloneNode(false);
    const tb = document.createElement('tbody');
    first.appendChild(tb);
    box.appendChild(first);
    let k = 0;
    for (; k < rows.length; k++) {
      const r = rows[k].cloneNode(true);
      tb.appendChild(r);
      if (!fits()) { tb.removeChild(r); break; }
    }
    box.removeChild(first);
    if (!tb.children.length) return { first: null, rest: table };
    if (k >= rows.length) return { first, rest: null };
    const rest = table.cloneNode(false);
    const tb2 = document.createElement('tbody');
    rest.appendChild(tb2);
    rows.slice(k).forEach((r) => tb2.appendChild(r.cloneNode(true)));
    return { first, rest };
  }

  const TEXT_BLOCKS = new Set(['P', 'BLOCKQUOTE', 'DIV', 'PRE']);

  /* ---------- fluxo de uma secção para páginas ---------- */
  function normalizeBlocks(html, secId, anchorHeadings) {
    const root = document.createElement('div');
    root.innerHTML = html;
    const blocks = [];
    let h = 0;
    const push = (el) => blocks.push(el);
    const wrapLoose = [];
    const flushLoose = () => { if (wrapLoose.length) { const p = document.createElement('p'); wrapLoose.forEach((n) => p.appendChild(n)); if (p.textContent.trim() || p.querySelector('img,br')) push(p); wrapLoose.length = 0; } };
    const walk = (parent) => {
      for (const n of Array.from(parent.childNodes)) {
        if (n.nodeType === 3) { if (n.nodeValue.trim()) wrapLoose.push(n); continue; }
        if (n.nodeType !== 1) continue;
        const tag = n.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE') continue;
        const inlineTags = ['SPAN', 'B', 'I', 'U', 'S', 'STRONG', 'EM', 'A', 'FONT', 'SUB', 'SUP', 'MARK', 'STRIKE', 'CODE', 'BR'];
        if (inlineTags.includes(tag)) { wrapLoose.push(n); continue; }
        flushLoose();
        if ((tag === 'DIV' || tag === 'SECTION') && !n.classList.contains('pagebreak') && !/^front-|^toc$/.test(n.className) && n.querySelector('p,div,h1,h2,h3,ul,ol,table,blockquote')) { walk(n); continue; }
        if (tag === 'FIGURE') { const img = n.querySelector('img'); if (img) { push(img); continue; } }
        if (anchorHeadings && (tag === 'H2' || tag === 'H3') && n.textContent.trim()) n.setAttribute('data-anchor', secId + ':h' + (h++));
        push(n);
      }
      flushLoose();
    };
    walk(root);
    return blocks;
  }

  function flowSection(sec, ctx) {
    const key = ctx.layoutKey + '|' + sec.id + '|' + hash(sec.html);
    if (cache.has(key)) return cache.get(key);

    const { box } = ctx;
    const anchorHeadings = sec.type === 'chapter' || sec.type === 'intro' || sec.type === 'preface';
    const queue = normalizeBlocks(sec.html, sec.id, anchorHeadings);
    const pages = [], anchors = {};
    const fits = () => box.scrollHeight <= box.clientHeight + 1;

    const record = () => {
      box.querySelectorAll('[data-toc],[data-anchor]').forEach((e) => { const a = e.getAttribute('data-toc') || e.getAttribute('data-anchor'); if (!(a in anchors)) anchors[a] = pages.length; });
    };
    /** Fecha a página atual. Devolve um título "órfão" no fim da página para ir para a seguinte. */
    const flush = () => {
      let carry = null;
      const last = box.lastElementChild;
      if (last && /^H[1-3]$/.test(last.tagName) && box.children.length > 1) { carry = last; box.removeChild(last); }
      record();
      pages.push(box.innerHTML);
      box.innerHTML = '';
      return carry;
    };

    let guard = 0;
    while (queue.length && guard++ < 20000) {
      const block = queue.shift();
      if (block.nodeType === 1 && block.classList && block.classList.contains('pagebreak')) {
        if (box.childNodes.length) { const c = flush(); if (c) queue.unshift(c); }
        continue;
      }
      box.appendChild(block);
      if (fits()) continue;
      box.removeChild(block);

      let sp = { first: null, rest: block };
      const tag = block.tagName;
      if (tag === 'UL' || tag === 'OL') sp = splitList(block, box, fits);
      else if (tag === 'TABLE') sp = splitTable(block, box, fits);
      else if (TEXT_BLOCKS.has(tag) && !block.querySelector('p,div,ul,ol,table,img')) sp = splitInline(block, box, fits);

      if (sp.first) {
        box.appendChild(sp.first);
        const carry = flush();
        if (sp.rest) queue.unshift(sp.rest);
        if (carry) queue.unshift(carry);
      } else if (box.childNodes.length) {
        const carry = flush();
        queue.unshift(block);
        if (carry) queue.unshift(carry);
      } else {
        // bloco que não cabe numa página vazia e não pode ser dividido: força a colocação
        box.appendChild(block);
        flush();
      }
    }
    if (box.childNodes.length) flush();
    if (!pages.length) pages.push('');

    const res = { pages, anchors };
    cache.set(key, res);
    if (cache.size > 400) cache.delete(cache.keys().next().value);
    return res;
  }

  /* ---------- API ---------- */
  function tocHtml(toc, title, labels) {
    const rows = toc.map((t) => {
      const n = labels ? labels[t.anchor] : '00';
      return '<div class="toc-row l' + t.level + '"' + (n != null && labels ? ' data-goto="' + n + '"' : '') + '><span class="toc-t">' + BV.esc(t.title) + '</span><span class="toc-dots"></span><span class="toc-n">' + (n == null ? '' : n) + '</span></div>';
    }).join('');
    return '<h1 class="chap-title toc-h">' + BV.esc(title) + '</h1><div class="toc">' + rows + '</div>';
  }

  /**
   * Pagina o livro inteiro.
   * opts.covers: { front, back } (URL/data URL) · opts.includeCovers (omissão true)
   * Devolve { pages:[{html,type,sectionId,label,index}], sections, toc, geo, css, total }
   */
  BV.paginate = function (book, opts) {
    opts = opts || {};
    const layout = book.doc.layout;
    const geo = geometry(layout);
    const css = BV.pageCss(layout);
    const layoutKey = hash(JSON.stringify(layout) + '|' + book.title + book.subtitle + book.author + book.publisher + book.year + book.copyright + book.isbn);

    // contentor de medição fora do ecrã, com as mesmas regras de CSS das páginas
    let style = document.getElementById('bv-page-css');
    if (!style) { style = document.createElement('style'); style.id = 'bv-page-css'; document.head.appendChild(style); }
    style.textContent = css;
    const frame = document.createElement('div');
    frame.className = 'bv-page';
    frame.style.cssText = 'position:fixed;left:-20000px;top:0;visibility:hidden;width:' + geo.pageW + 'mm;height:' + geo.pageH + 'mm';
    const box = document.createElement('div');
    box.className = 'bv-body';
    box.style.cssText = 'left:' + geo.m.inner + 'mm;top:' + geo.m.top + 'mm;width:' + geo.bodyW + 'mm;height:' + geo.bodyH + 'mm;--bvh:' + geo.bodyH + 'mm';
    frame.appendChild(box);
    document.body.appendChild(frame);

    try {
      const sections = BV.model.buildSections(book);
      const toc = BV.model.buildToc(sections);
      const ctx = { box, layoutKey };
      const withCovers = opts.includeCovers !== false;

      // 1.ª passagem: tudo exceto o índice
      const flows = {};
      for (const s of sections) {
        if (s.type === 'cover' || s.type === 'backcover' || s.type === 'toc') continue;
        flows[s.id] = flowSection(s, ctx);
      }
      let tocFlow = null, labels = null, anchorsGlobal = {};
      const tocSec = sections.find((s) => s.type === 'toc');
      const frontCount = (s) => (s.type === 'cover' ? 0 : 1);

      const assemble = (tocFl) => {
        const list = [];
        for (const s of sections) {
          if (s.type === 'cover' || s.type === 'backcover') { list.push({ sec: s, kind: s.type, html: '' }); continue; }
          const fl = s.type === 'toc' ? tocFl : flows[s.id];
          fl.pages.forEach((html, i) => list.push({ sec: s, kind: s.type, html, local: i, anchors: fl.anchors }));
        }
        return list;
      };

      if (tocSec) {
        const title = tocSec.title;
        tocFlow = flowSection({ id: 'toc', type: 'toc', html: tocHtml(toc, title, null) }, ctx);
        for (let pass = 0; pass < 3; pass++) {
          const list = assemble(tocFlow);
          // numeração: capa não conta; 1.ª página interior = 1
          let n = 0; labels = {}; anchorsGlobal = {};
          list.forEach((p, idx) => {
            if (p.kind === 'cover' || p.kind === 'backcover') return;
            n++;
            p.number = n;
            if (p.anchors) for (const a in p.anchors) if (p.anchors[a] === p.local) { if (!(a in labels)) { labels[a] = n; anchorsGlobal[a] = idx; } }
          });
          const next = flowSection({ id: 'toc', type: 'toc', html: tocHtml(toc, title, labels) }, ctx);
          const same = next.pages.length === tocFlow.pages.length;
          tocFlow = next;
          if (same) break;
        }
      }
      const list = assemble(tocFlow);
      let n = 0; const anchorsOut = {};
      const pages = [];
      const hiddenFooter = new Set(['title', 'copyright', 'dedication']);
      const H = layout.header, F = layout.footer;
      list.forEach((p) => {
        const isCover = p.kind === 'cover' || p.kind === 'backcover';
        if (isCover) {
          const src = p.kind === 'cover' ? (opts.covers && opts.covers.front) : (opts.covers && opts.covers.back);
          if (!withCovers || !src) return;
          pages.push({ html: '<div class="bv-page is-cover" style="width:' + geo.pageW + 'mm;height:' + geo.pageH + 'mm"><img class="bv-cover" src="' + src + '"></div>', type: p.kind, sectionId: p.sec.id, label: '', index: pages.length });
          return;
        }
        n++;
        const odd = n % 2 === 1;
        const left = odd ? geo.m.inner : geo.m.outer;
        const right = odd ? geo.m.outer : geo.m.inner;
        const bodyHtml = p.html;
        const startsChapter = /^<h1 class="chap-title/.test(bodyHtml);
        let hdr = '', ftr = '';
        if (H.enabled && !hiddenFooter.has(p.kind) && !startsChapter && p.kind !== 'toc') {
          const t = H.mode === 'author' ? book.author : H.mode === 'custom' ? H.text : book.title;
          if (t) hdr = '<div class="bv-hdr" style="left:' + left + 'mm;right:' + right + 'mm;top:' + Math.max(4, geo.m.top / 2 - 2) + 'mm">' + BV.esc(t) + '</div>';
        }
        if (F.enabled && !hiddenFooter.has(p.kind)) {
          const parts = [];
          if (F.text) parts.push(BV.esc(F.text));
          if (F.pageNumbers) parts.push(String(n));
          if (parts.length) ftr = '<div class="bv-ftr" style="left:' + left + 'mm;right:' + right + 'mm;bottom:' + Math.max(4, geo.m.bottom / 2 - 2) + 'mm">' + parts.join(' &nbsp;·&nbsp; ') + '</div>';
        }
        const html = '<div class="bv-page" style="width:' + geo.pageW + 'mm;height:' + geo.pageH + 'mm">' + hdr +
          '<div class="bv-body" style="left:' + left + 'mm;top:' + geo.m.top + 'mm;width:' + geo.bodyW + 'mm;height:' + geo.bodyH + 'mm;--bvh:' + geo.bodyH + 'mm">' + bodyHtml + '</div>' + ftr + '</div>';
        const idx = pages.length;
        if (p.anchors) for (const a in p.anchors) if (p.anchors[a] === p.local && !(a in anchorsOut)) anchorsOut[a] = idx;
        pages.push({ html, type: p.kind, sectionId: p.sec.id, label: String(n), number: n, index: idx });
      });
      return { pages, sections, toc, geo, css, layout, anchors: anchorsOut, total: n, totalPages: pages.length };
    } finally {
      frame.remove();
    }
  };

  BV.paginateClearCache = () => cache.clear();
})();
