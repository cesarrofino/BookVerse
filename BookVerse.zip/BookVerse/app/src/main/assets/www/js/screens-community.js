/* BookVerse — comunidade: livros publicados, leitura e reações */
(function () {
  'use strict';
  const BV = window.BV, store = BV.store, h = BV.h, icon = BV.icon, t = (s) => BV.t(s);
  const C = (BV.community = {});
  const REACTIONS = [['like', '👍', 'Gostei'], ['love', '❤️', 'Adorei'], ['wow', '😮', 'Uau'], ['clap', '👏', 'Aplausos'], ['inspire', '✨', 'Inspirador']];
  const num = (c, k) => Math.max(0, (c && c[k]) || 0);
  const total = (c) => REACTIONS.reduce((n, r) => n + num(c, r[0]), 0);
  const CAT = { Romance: ['#be185d', '#fb7185'], 'Ficção': ['#1e3a8a', '#3b82f6'], Fantasia: ['#4c1d95', '#a78bfa'], Terror: ['#450a0a', '#b91c1c'], Suspense: ['#111827', '#4b5563'], Biografia: ['#78350f', '#d6a55e'], 'Educação': ['#075985', '#38bdf8'], Tecnologia: ['#0f172a', '#06b6d4'], Poesia: ['#374151', '#9ca3af'] };
  const grad = (cat) => { const c = CAT[cat] || ['#1d4ed8', '#60a5fa']; return 'linear-gradient(160deg,' + c[0] + ',' + c[1] + ')'; };

  async function signIn() {
    const b = BV.busy(t('Aguarde…'));
    try { const nu = await BV.native('auth.google', {}); store.setUser(nu); b.done(); BV.toast(t('Sessão iniciada'), 'ok'); return true; }
    catch (e) { b.done(); BV.error(e); return false; }
  }

  const gate = () => h('div', { class: 'card pad comm-gate' },
    h('div', { class: 'comm-gate-ic' }, icon('globe', 'lg')),
    h('h3', null, t('Comunidade de escritores')),
    h('p', null, t('Entre com a sua conta Google para ler livros publicados por outros escritores, reagir e publicar os seus.')),
    h('button', { class: 'btn primary block', onclick: async () => { if (await signIn()) C.render(); } }, h('b', null, 'G'), t('Entrar com Google')));

  const topEmojis = (c) => {
    const used = REACTIONS.filter((r) => num(c, r[0]) > 0).sort((a, b) => num(c, b[0]) - num(c, a[0])).slice(0, 3).map((r) => r[1]).join('');
    return total(c) ? used + ' ' + total(c) : t('Sem reações ainda');
  };

  function card(b) {
    const cover = b.cover ? h('img', { class: 'pc-img', src: b.cover, alt: '', loading: 'lazy' }) : h('div', { class: 'pc-img ph', style: { background: grad(b.category) } }, h('span', null, b.title));
    return h('button', { class: 'pub-card', onclick: () => BV.go('communityBook', { id: b.id }) },
      h('div', { class: 'pc-cover' }, cover),
      h('div', { class: 'pc-title' }, b.title),
      h('div', { class: 'pc-author' }, b.author || b.ownerName || ''),
      h('div', { class: 'pc-react' }, topEmojis(b.counts) + (b.commentCount ? '  💬 ' + b.commentCount : '')));
  }

  C.render = async function () {
    const s = BV.clear(BV.$('#screen-community'));
    const body = h('div', { class: 'scroll form-scroll' });
    s.append(h('div', { class: 'topbar' }, h('button', { class: 'icon-btn', onclick: () => BV.go('home') }, icon('back')), h('h2', null, t('Comunidade')),
      h('div', { class: 'grow' }), h('button', { class: 'icon-btn', 'aria-label': 'Atualizar', onclick: () => C.render() }, icon('refresh'))), body, BV.navBar('community'));
    if (!store.user.signedIn) { body.append(h('div', { class: 'form-wrap' }, gate())); return; }
    body.append(h('div', { class: 'comm-load' }, t('A carregar…')));
    try {
      const list = await BV.native('community.list', { limit: 40 });
      BV.clear(body);
      const wrap = h('div', { class: 'form-wrap' }, h('p', { class: 'comm-intro' }, t('Livros publicados por escritores do BookVerse. Toque num livro para ler e reagir.')));
      if (!list.length) wrap.append(h('div', { class: 'empty' }, icon('globe'), h('div', null, t('Ainda não há livros publicados.')), h('small', null, t('Seja o primeiro: no menu ⋮ de um livro, escolha "Publicar na comunidade".'))));
      else wrap.append(h('div', { class: 'pub-grid' }, list.map(card)));
      body.append(wrap, h('div', { style: { height: '110px' } }));
    } catch (e) {
      BV.clear(body);
      body.append(h('div', { class: 'form-wrap' }, h('div', { class: 'card pad' }, h('h3', null, t('Não foi possível carregar')), h('p', { style: { color: 'var(--text-2)' } }, e.message || String(e)),
        h('button', { class: 'btn block', onclick: () => C.render() }, icon('refresh'), t('Tentar de novo')))));
    }
  };

  /** Detalhe de um livro publicado: capa, reações e leitura. */
  C.openBook = async function (id) {
    const s = BV.clear(BV.$('#screen-communityBook'));
    const body = h('div', { class: 'scroll form-scroll' }, h('div', { class: 'comm-load' }, t('A carregar…')));
    s.append(h('div', { class: 'topbar' }, h('button', { class: 'icon-btn', onclick: () => BV.go('community') }, icon('back')), h('h2', null, t('Livro'))), body);
    let b;
    try { b = await BV.native('community.get', { id }); }
    catch (e) { BV.error(e); BV.go('community'); return; }
    BV.clear(body);

    const bar = h('div', { class: 'react-bar' });
    const drawBar = () => {
      BV.clear(bar);
      REACTIONS.forEach(([k, em, label]) => bar.appendChild(h('button', { class: 'react' + (b.mine === k ? ' on' : ''), onclick: () => react(k) },
        h('span', { class: 're' }, em), h('b', null, String(num(b.counts, k))), h('small', null, t(label)))));
    };
    let busy = false;
    const react = async (type) => {
      if (busy) return; busy = true;
      try { const r = await BV.native('community.react', { id, type }); b.counts = r.counts; b.mine = r.mine; drawBar(); }
      catch (e) { BV.error(e); } finally { busy = false; }
    };
    drawBar();

    const cover = b.cover ? h('img', { src: b.cover, alt: '' }) : h('div', { class: 'ph', style: { background: grad(b.category) } }, h('span', null, b.title));
    const meta = [b.category, BV.fmtNum(b.wordCount) + ' ' + t('palavras'), b.publishedAt ? BV.fmtDate(b.publishedAt) : ''].filter(Boolean).join(' · ');
    const reader = h('div', { class: 'pub-read', style: { display: 'none' } });
    let size = 17;
    const applySize = () => { reader.style.fontSize = size + 'px'; };
    const readBtn = h('button', { class: 'btn primary block' }, icon('book'), t('Ler livro'));
    readBtn.addEventListener('click', () => {
      if (!reader.childNodes.length) {
        const ctl = h('div', { class: 'read-ctl' }, h('button', { class: 'btn sm', onclick: () => { size = Math.max(13, size - 1); applySize(); } }, 'A−'), h('button', { class: 'btn sm', onclick: () => { size = Math.min(26, size + 1); applySize(); } }, 'A+'));
        reader.append(ctl);
        (b.parts || []).forEach((p) => { const d = h('div', { class: 'pub-part' }); d.innerHTML = BV.model.sanitize(p.html || ''); reader.append(d); });
        applySize();
      }
      const show = reader.style.display === 'none';
      reader.style.display = show ? '' : 'none';
      readBtn.lastChild.textContent = show ? t('Fechar leitura') : t('Ler livro');
      if (show) reader.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    const wrap = h('div', { class: 'form-wrap' },
      h('div', { class: 'pub-head' }, h('div', { class: 'pub-cover' }, cover),
        h('div', { class: 'pub-info' }, h('h2', null, b.title), b.subtitle ? h('div', { class: 'pub-sub' }, b.subtitle) : null,
          h('div', { class: 'pub-by' }, t('por') + ' ' + (b.author || b.ownerName || '')), h('div', { class: 'pub-meta' }, meta))),
      b.description ? h('p', { class: 'pub-desc' }, b.description) : null,
      h('div', { class: 'grp-t' }, t('Reações')), bar,
      h('div', { style: { height: '14px' } }), readBtn, reader);
    if (b.ownerUid && store.user.uid === b.ownerUid) {
      wrap.append(h('div', { style: { height: '14px' } }), h('button', { class: 'btn danger block', onclick: async () => {
        if (!(await BV.confirm(t('Remover este livro da comunidade? As reações também serão apagadas.'), { danger: true, ok: t('Remover') }))) return;
        const bz = BV.busy(t('Aguarde…'));
        try { await BV.native('community.unpublish', { id }); bz.done(); BV.toast(t('Publicação removida'), 'ok'); BV.go('community'); } catch (e) { bz.done(); BV.error(e); }
      } }, icon('trash'), t('Remover da comunidade')));
    }
    wrap.append(h('div', { class: 'grp-t' }, t('Comentários')), commentsBox(id, b));
    body.append(wrap, h('div', { style: { height: '60px' } }));
  };

  const ago = (ms) => {
    if (!ms) return '';
    const m = Math.max(0, Math.round((Date.now() - ms) / 60000));
    if (m < 1) return t('agora');
    if (m < 60) return m + ' min';
    if (m < 1440) return Math.round(m / 60) + ' h';
    return BV.fmtDate(ms);
  };

  /** Lista de comentários com caixa para escrever; o autor do comentário e o autor do livro podem apagar. */
  function commentsBox(id, book) {
    const list = h('div', { class: 'cm-list' }, h('div', { class: 'comm-load' }, t('A carregar…')));
    const input = h('textarea', { class: 'input cm-input', rows: 2, maxlength: 1000, placeholder: t('Escreva um comentário…') });
    const send = h('button', { class: 'btn primary cm-send' }, icon('forward'), t('Enviar'));
    const me = store.user.uid, isOwner = book.ownerUid && book.ownerUid === me;
    let items = [];
    const draw = () => {
      BV.clear(list);
      if (!items.length) { list.append(h('div', { class: 'cm-empty' }, t('Ainda sem comentários. Seja o primeiro!'))); return; }
      items.forEach((c) => list.append(h('div', { class: 'cm-item' },
        h('div', { class: 'cm-av' }, ((c.name || '?').trim()[0] || '?').toUpperCase()),
        h('div', { class: 'cm-main' },
          h('div', { class: 'cm-head' }, h('b', null, c.name || t('Leitor')), h('small', null, ago(c.at))),
          h('div', { class: 'cm-text' }, c.text)),
        (c.uid === me || isOwner) ? h('button', { class: 'icon-btn cm-del', 'aria-label': t('Apagar'), onclick: async () => {
          if (!(await BV.confirm(t('Apagar este comentário?'), { danger: true, ok: t('Apagar') }))) return;
          try { await BV.native('community.deleteComment', { id, commentId: c.id }); items = items.filter((x) => x.id !== c.id); draw(); } catch (e) { BV.error(e); }
        } }, icon('trash', 'sm')) : null)));
    };
    send.addEventListener('click', async () => {
      const text = input.value.trim(); if (!text) return;
      send.disabled = true;
      try { const c = await BV.native('community.comment', { id, text }); items.push(c); input.value = ''; draw(); }
      catch (e) { BV.error(e); } finally { send.disabled = false; }
    });
    BV.native('community.comments', { id }).then((r) => { items = r; draw(); }).catch((e) => { BV.clear(list); list.append(h('div', { class: 'cm-empty' }, e.message || String(e))); });
    return h('div', { class: 'cm-box' }, list, h('div', { class: 'cm-write' }, input, send));
  }

  /** Reduz uma imagem do livro (JPEG, máx. 1280 px) para a enviar para a nuvem. */
  function shrink(src, max) {
    return new Promise((res) => {
      const im = new Image();
      im.onload = () => {
        try {
          const k = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight));
          const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
          const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
          res(c.toDataURL('image/jpeg', 0.82));
        } catch (e) { res(null); }
      };
      im.onerror = () => res(null);
      im.src = src;
    });
  }

  /** Envia as imagens do texto para a nuvem e troca os endereços locais pelos publicados. */
  async function packImages(html, bookId, cache, counter) {
    const d = document.createElement('div'); d.innerHTML = html;
    for (const im of Array.from(d.querySelectorAll('img'))) {
      const src = im.getAttribute('src') || '';
      if (!src) { im.remove(); continue; }
      if (/^https:\/\/firebasestorage\.googleapis\.com\//.test(src)) continue;
      let url = cache.get(src);
      if (!url) {
        const data = await shrink(src, 1280);
        if (!data) { im.remove(); continue; }
        url = await BV.native('community.uploadImage', { id: bookId, name: 'img' + (++counter.n) + '.jpg', data });
        cache.set(src, url);
      }
      im.setAttribute('src', url);
      if (!im.getAttribute('alt')) im.setAttribute('alt', '');
    }
    return d.innerHTML;
  }

  /** Publica (ou atualiza) um livro da biblioteca na comunidade, com as imagens. */
  BV.publishBook = async function (bk) {
    if (!store.user.signedIn) { BV.toast(t('Entre com a sua conta Google para publicar'), 'error'); BV.go('account'); return; }
    if (!(await BV.confirm(t('Qualquer utilizador do BookVerse com conta poderá ler "') + bk.title + t('" com as suas imagens, reagir e comentar. Publicar?'), { ok: t('Publicar') }))) return;
    const b = BV.busy(t('A publicar…'));
    try {
      await store.flush();
      const book = await store.open(bk.id);
      const skip = ['cover', 'title', 'copyright', 'backcover'];
      const raw = BV.model.buildSections(book).filter((x) => !skip.includes(x.type))
        .map((x) => ({ title: x.title, html: BV.model.sanitize(x.html || '') }))
        .filter((x) => x.html.replace(/<(?!img)[^>]*>/gi, '').trim().length);
      if (!raw.length) throw new Error(t('Escreva algum texto antes de publicar.'));
      await BV.native('community.clearImages', { id: book.id }).catch(() => {});
      const cache = new Map(), counter = { n: 0 }, sections = [];
      for (const x of raw) sections.push({ title: x.title, html: await packImages(x.html, book.id, cache, counter) });
      let cover = '';
      try { const c = await BV.coverImages(book, 420); cover = c.front || ''; } catch (e) { cover = ''; }
      await BV.native('community.publish', {
        id: book.id, title: book.title, subtitle: book.subtitle || '', author: book.author || store.user.name || '', category: book.category || '',
        language: book.language || 'pt', description: book.description || '', cover, wordCount: BV.model.totalWords(book.doc), sections
      });
      b.done(); BV.toast(t('Livro publicado na comunidade'), 'ok');
    } catch (e) { b.done(); BV.error(e); }
  };
  BV.unpublishBook = async function (bk) {
    const b = BV.busy(t('Aguarde…'));
    try { await BV.native('community.unpublish', { id: bk.id }); b.done(); BV.toast(t('Publicação removida'), 'ok'); } catch (e) { b.done(); BV.error(e); }
  };
})();
